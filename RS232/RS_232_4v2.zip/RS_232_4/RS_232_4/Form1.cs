﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RS_232_4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            tekst_nadany = "";
            informacja = new byte[32];
            bity = new string[256];
            okno_wyswietlenia = new Form2();
            //odbiornik = new Form3();
            dlugosc = 0;
            
            InitializeComponent();
        }

        private void button_nadanie_Click(object sender, EventArgs e)
        {
            tekst_nadany = this.textBox_nadanie.Text;
            informacja = Encoding.ASCII.GetBytes(tekst_nadany);
            dlugosc = 0;
            dlugosc_tekstu();
            if (dlugosc == 0)
            {
                MessageBox.Show("Zbyt długi tekst");
            }
            else
            {
                konwersja();
                this.okno_wyswietlenia.Show();
                //this.odbiornik.Show();
                for (int i = 0; i < 256; i++)
                {
                    this.okno_wyswietlenia.textBox_informacja.Text += bity[i];
                }
            }
        }
        public void konwersja()
        {
            for (int i = 0; i < dlugosc; i++)
            {
                int liczba = Convert.ToInt32(informacja[i]);
                int wynik_dzielenia = liczba;
                int[] bits = new int[8] { 0, 0, 0, 0, 0, 0, 0, 0 };
                int j = 7;
                while (wynik_dzielenia > 0)
                {
                    if (wynik_dzielenia % 2 == 1)
                    {
                        bits[j] = 1;
                    }
                    else bits[j] = 0;
                    wynik_dzielenia = wynik_dzielenia / 2;
                    j--;
                }
                string liczba1 = "0"; // bit startu
                for (int k = 7; k > -1; k--)
                {
                    liczba1 += Convert.ToString(bits[k]);
                }
                bity[i] = liczba1 + "11"; // bity stopu
            }
        }
        public void dlugosc_tekstu()
        {
            for (int i = 0; i < 32; i++)
            {
                try
                {
                    if (informacja[i] == 0)
                    {
                        dlugosc = i;
                        break;
                    }
                }
                catch (IndexOutOfRangeException)
                {
                    dlugosc = i;
                    break;
                }
            }
        }
    }
}
