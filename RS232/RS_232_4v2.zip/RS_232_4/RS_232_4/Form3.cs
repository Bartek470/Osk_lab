﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RS_232_4
{
    public partial class Form3 : Form
    {
        
        private List<string> grubianstw;
        public Form3(Form2 okno_dane)
        {
            odebrane = "";
            informacja = new byte[32];
            dlugosc_danych = 0;
            dane = new string[256];
            this.okno_danych = okno_dane;
            grubianstw = new List<string>() { "bla","lala","bable","kot","pies","rzyrafa","malpa","lew","lama","alpaka" };
           
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            odebrane = this.okno_danych.textBox_informacja.Text;
            ilosc_danych();
            konwersja();
            wypisanie();
        }
        public void ilosc_danych()
        {
            dlugosc_danych = odebrane.Length / 11;
            for (int i = 0; i < dlugosc_danych; i++)
            {
                for (int j = 0; j < 11; j++)
                {
                    if (j >= 1 && j <= 8)
                    {
                        dane[i] += odebrane[i * 11 + j];
                    }
                }
                char[] chararray = dane[i].ToCharArray();
                Array.Reverse(chararray);
                dane[i] = new string(chararray);
            }
        }

        public void konwersja()
        {
            for (int i = 0; i < dlugosc_danych; i++)
            {
                for (int j = 0; j < 8; j++)
                {
                    if (dane[i][j] == '1')
                    {
                        informacja[i] += Convert.ToByte(Math.Pow(2, 7 - j));
                    }
                }
            }
        }

        public void wypisanie()
        {
           
            for (int i = 0; i < dlugosc_danych; i++)
            {
                char znak = Convert.ToChar(informacja[i]);
                string wiadomsc = Convert.ToString(znak);
               

                this.textBox_odebrane.Text += wiadomsc;


            }
            string jakas=this.textBox_odebrane.Text;

             for (int j = 0; j < grubianstw.Count; j++)
                {
                    if (jakas == grubianstw[j]) 
                    {
                        char zastap = '*';
                        this.textBox_odebrane.Text = zastap.ToString();
                    }
                    
                        
                }
            
        }
    }
}
