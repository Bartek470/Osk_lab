﻿
namespace RS_232_4
{
    partial class Form1
    {
        /// <summary>
        /// Wymagana zmienna projektanta.
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        public string tekst_nadany;
        public byte[] informacja;
        public string[] bity;
        public int dlugosc;
        public Form2 okno_wyswietlenia;
        //public Form3 odbiornik;

        /// <summary>
        /// Wyczyść wszystkie używane zasoby.
        /// </summary>
        /// <param name="disposing">prawda, jeżeli zarządzane zasoby powinny zostać zlikwidowane; Fałsz w przeciwnym wypadku.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kod generowany przez Projektanta formularzy systemu Windows

        /// <summary>
        /// Metoda wymagana do obsługi projektanta — nie należy modyfikować
        /// jej zawartości w edytorze kodu.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.textBox_nadanie = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.button_nadanie = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(105, 41);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(167, 24);
            this.label1.TabIndex = 0;
            this.label1.Text = "RS232 - nadajnik";
            // 
            // textBox_nadanie
            // 
            this.textBox_nadanie.Location = new System.Drawing.Point(33, 107);
            this.textBox_nadanie.Name = "textBox_nadanie";
            this.textBox_nadanie.Size = new System.Drawing.Size(367, 20);
            this.textBox_nadanie.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(30, 91);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(155, 16);
            this.label2.TabIndex = 2;
            this.label2.Text = "Wiadomość do nadania:";
            // 
            // button_nadanie
            // 
            this.button_nadanie.Location = new System.Drawing.Point(524, 106);
            this.button_nadanie.Name = "button_nadanie";
            this.button_nadanie.Size = new System.Drawing.Size(75, 23);
            this.button_nadanie.TabIndex = 3;
            this.button_nadanie.Text = "Nadaj";
            this.button_nadanie.UseVisualStyleBackColor = true;
            this.button_nadanie.Click += new System.EventHandler(this.button_nadanie_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button_nadanie);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBox_nadanie);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Nadajnik";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox_nadanie;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button_nadanie;
    }
}

