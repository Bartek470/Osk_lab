﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SalaKonferencyjna3
{
    public partial class Form2 : Form
    {
        public Form2(Form1 rodzic)
        {
            this.Form1 = rodzic;
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            poziom_wody = 3; // 3 - wysoki, 2 - sredni, 1 - niski, 0 - brak
            rozstawienie_rzutnika = 0; // 0 - nierozstawiony, 1 - chowa się, 2 - rozwija się, 3 - rozstawiony
            projektor = false;
            ilosc_flamastrow = 3; // jak przy poziomie wody
            siec_wifi = false;
            progres_flamastrow = 100;
            progres_wody = 100;
            sala_zajeta = false;
            czas_rzutnika = 10;
            czas_nieaktywnosci = 30;
            ile_osob = 0;
            Label_Update();
        }

        public void Label_Update()
        {
            switch (poziom_wody)
            {
                case 0:
                    this.label_poziomwody.Text = "Poziom wody: brak";
                    break;
                case 1:
                    this.label_poziomwody.Text = "Poziom wody: niski";
                    break;
                case 2:
                    this.label_poziomwody.Text = "Poziom wody: średni";
                    break;
                case 3:
                    this.label_poziomwody.Text = "Poziom wody: wysoki";
                    break;
                default:
                    break;
            }

            switch (rozstawienie_rzutnika)
            {
                case 0:
                    this.label_stanrzutnika.Text = "Stan rzutnika: zamknięty";
                    break;
                case 1:
                    this.label_stanrzutnika.Text = "Stan rzutnika: zamyka się";
                    break;
                case 2:
                    this.label_stanrzutnika.Text = "Stan rzutnika: otwiera się";
                    break;
                case 3:
                    this.label_stanrzutnika.Text = "Stan rzutnika: otwarty";
                    break;
            }

            if (projektor)
            {
                this.label_projektor.Text = "Projektor: ON";
            }
            else this.label_projektor.Text = "Projektor: OFF";

            switch (ilosc_flamastrow)
            {
                case 0:
                    this.label_flamastry.Text = "Poziom flamastrów: brak";
                    break;
                case 1:
                    this.label_flamastry.Text = "Poziom flamastrów: niski";
                    break;
                case 2:
                    this.label_flamastry.Text = "Poziom flamastrów: średni";
                    break;
                case 3:
                    this.label_flamastry.Text = "Poziom flamastrów: wysoki";
                    break;
            }
            if (siec_wifi)
            {
                this.label_wifi.Text = "Sieć WiFi: ON";
            }
            else this.label_wifi.Text = "Sieć WiFi: OFF";

            progressBar_flamastry.Value = progres_flamastrow;
            progressBar_poziomwody.Value = progres_wody;
        }

        private void progressBar_poziomwody_Click(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            Random rnd = new Random();
            int random_woda = rnd.Next(10);
            int random_flamastry = rnd.Next(10);
            if (random_woda < 2)
            {
                progres_wody -= 2;
            }
            if (random_flamastry < 2)
            {
                progres_flamastrow -= 2;
            }
            if (progres_wody > 70 && ile_osob < 7)
            {
                poziom_wody = 3;
            }
            else if (progres_wody > 40 && ile_osob < 4)
            {
                poziom_wody = 2;
            }
            else if (progres_wody > 10 && ile_osob >=7)
            {
                poziom_wody = 1;
            }
            else poziom_wody = 0;

            if (progres_flamastrow > 70)
            {
                ilosc_flamastrow = 3;
            }
            else if (progres_flamastrow > 40)
            {
                ilosc_flamastrow = 2;
            }
            else if (progres_flamastrow > 10)
            {
                ilosc_flamastrow = 1;
            }
            else ilosc_flamastrow = 0;
            Label_Update();
        }

        private void button1_Click(object sender, EventArgs e) // woda
        {
            poziom_wody = 3;
            progres_wody = 100;
            czas_nieaktywnosci = 30;
        }

        private void button_rzutnik_Click(object sender, EventArgs e)
        {
            if (rozstawienie_rzutnika == 0)
            {
                rozstawienie_rzutnika = 2;
            }
            else if (rozstawienie_rzutnika == 3)
            {
                rozstawienie_rzutnika = 1;
            }
            czas_nieaktywnosci = 30;
            this.timer2.Enabled = true;
        }

        private void button_projektor_Click(object sender, EventArgs e)
        {
            projektor = !projektor;
            czas_nieaktywnosci = 30;
        }

        private void button_flamastry_Click(object sender, EventArgs e)
        {
            ilosc_flamastrow = 3;
            progres_flamastrow = 100;
            czas_nieaktywnosci = 30;
        }

        private void button_wifi_Click(object sender, EventArgs e)
        {
            siec_wifi = !siec_wifi;
            czas_nieaktywnosci = 30;
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            czas_rzutnika -= 1;
            if (czas_rzutnika <= 0)
            {
                if(rozstawienie_rzutnika == 2)
                {
                    rozstawienie_rzutnika = 3;
                }
                else if (rozstawienie_rzutnika == 1)
                {
                    rozstawienie_rzutnika = 0;
                }
                czas_rzutnika = 10;
                this.timer2.Enabled = false;
            }
        }

        private void timer3_Tick(object sender, EventArgs e)
        {
            czas_nieaktywnosci -= 1;
            if (czas_nieaktywnosci <= 0)
            {
                this.label_testaktywnosci.Visible = true;
                this.button_testaktywnosci.Visible = true;
                if (czas_nieaktywnosci <= -15)
                {
                    //this.Form1.Close();
                    //this.Form1 = new Form1();
                    //this.Form1.textBox_login.Text = "";
                    //this.Form1.textBox_haslo.Text = "";
                    this.Close();
                }
            }
            else
            {
                this.label_testaktywnosci.Visible = false;
                this.button_testaktywnosci.Visible = false;
            }
        }

        private void button_testaktywnosci_Click(object sender, EventArgs e)
        {
            czas_nieaktywnosci = 30;
            this.label_testaktywnosci.Visible = false;
            this.button_testaktywnosci.Visible = false;
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            if (ile_osob < 10)
            {
                ile_osob++;
                this.label1.Text = "Liczba osób: " + ile_osob.ToString();
            }
            else MessageBox.Show("Sala zapełniona");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (ile_osob >= 1)
            {
                ile_osob--;
                this.label1.Text = "Liczba osób: " + ile_osob.ToString();
            }
            else MessageBox.Show("Brak osób w sali");
        }
    }
}
