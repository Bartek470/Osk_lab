﻿
namespace SalaKonferencyjna3
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        public int poziom_wody;
        public int rozstawienie_rzutnika;
        public bool projektor;
        public int ilosc_flamastrow;
        public bool siec_wifi;
        public int progres_wody;
        public int progres_flamastrow;
        public bool sala_zajeta;
        public int czas_rzutnika;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.button_woda = new System.Windows.Forms.Button();
            this.button_rzutnik = new System.Windows.Forms.Button();
            this.button_projektor = new System.Windows.Forms.Button();
            this.button_flamastry = new System.Windows.Forms.Button();
            this.button_wifi = new System.Windows.Forms.Button();
            this.label_poziomwody = new System.Windows.Forms.Label();
            this.label_stanrzutnika = new System.Windows.Forms.Label();
            this.label_projektor = new System.Windows.Forms.Label();
            this.label_flamastry = new System.Windows.Forms.Label();
            this.label_wifi = new System.Windows.Forms.Label();
            this.progressBar_poziomwody = new System.Windows.Forms.ProgressBar();
            this.progressBar_flamastry = new System.Windows.Forms.ProgressBar();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.SuspendLayout();
            // 
            // button_woda
            // 
            this.button_woda.Location = new System.Drawing.Point(825, 84);
            this.button_woda.Name = "button_woda";
            this.button_woda.Size = new System.Drawing.Size(114, 33);
            this.button_woda.TabIndex = 0;
            this.button_woda.Text = "Przyniesienie wody";
            this.button_woda.UseVisualStyleBackColor = true;
            this.button_woda.Click += new System.EventHandler(this.button1_Click);
            // 
            // button_rzutnik
            // 
            this.button_rzutnik.Location = new System.Drawing.Point(825, 180);
            this.button_rzutnik.Name = "button_rzutnik";
            this.button_rzutnik.Size = new System.Drawing.Size(126, 25);
            this.button_rzutnik.TabIndex = 1;
            this.button_rzutnik.Text = "Rozstawienie rzutnika";
            this.button_rzutnik.UseVisualStyleBackColor = true;
            this.button_rzutnik.Click += new System.EventHandler(this.button_rzutnik_Click);
            // 
            // button_projektor
            // 
            this.button_projektor.Location = new System.Drawing.Point(825, 264);
            this.button_projektor.Name = "button_projektor";
            this.button_projektor.Size = new System.Drawing.Size(131, 27);
            this.button_projektor.TabIndex = 2;
            this.button_projektor.Text = "Włączenie projektora";
            this.button_projektor.UseVisualStyleBackColor = true;
            this.button_projektor.Click += new System.EventHandler(this.button_projektor_Click);
            // 
            // button_flamastry
            // 
            this.button_flamastry.Location = new System.Drawing.Point(825, 352);
            this.button_flamastry.Name = "button_flamastry";
            this.button_flamastry.Size = new System.Drawing.Size(142, 29);
            this.button_flamastry.TabIndex = 3;
            this.button_flamastry.Text = "Przyniesienie flamastrów";
            this.button_flamastry.UseVisualStyleBackColor = true;
            this.button_flamastry.Click += new System.EventHandler(this.button_flamastry_Click);
            // 
            // button_wifi
            // 
            this.button_wifi.Location = new System.Drawing.Point(825, 422);
            this.button_wifi.Name = "button_wifi";
            this.button_wifi.Size = new System.Drawing.Size(138, 34);
            this.button_wifi.TabIndex = 4;
            this.button_wifi.Text = "Włączenie sieci WiFi";
            this.button_wifi.UseVisualStyleBackColor = true;
            this.button_wifi.Click += new System.EventHandler(this.button_wifi_Click);
            // 
            // label_poziomwody
            // 
            this.label_poziomwody.AutoSize = true;
            this.label_poziomwody.BackColor = System.Drawing.Color.Transparent;
            this.label_poziomwody.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_poziomwody.ForeColor = System.Drawing.SystemColors.Control;
            this.label_poziomwody.Location = new System.Drawing.Point(822, 36);
            this.label_poziomwody.Name = "label_poziomwody";
            this.label_poziomwody.Size = new System.Drawing.Size(154, 16);
            this.label_poziomwody.TabIndex = 5;
            this.label_poziomwody.Text = "Poziom wody: wysoki";
            // 
            // label_stanrzutnika
            // 
            this.label_stanrzutnika.AutoSize = true;
            this.label_stanrzutnika.BackColor = System.Drawing.Color.Transparent;
            this.label_stanrzutnika.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_stanrzutnika.ForeColor = System.Drawing.SystemColors.Control;
            this.label_stanrzutnika.Location = new System.Drawing.Point(822, 132);
            this.label_stanrzutnika.Name = "label_stanrzutnika";
            this.label_stanrzutnika.Size = new System.Drawing.Size(173, 16);
            this.label_stanrzutnika.TabIndex = 6;
            this.label_stanrzutnika.Text = "Stan rzutnika: zamknięty";
            // 
            // label_projektor
            // 
            this.label_projektor.AutoSize = true;
            this.label_projektor.BackColor = System.Drawing.Color.Transparent;
            this.label_projektor.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_projektor.ForeColor = System.Drawing.SystemColors.Control;
            this.label_projektor.Location = new System.Drawing.Point(822, 216);
            this.label_projektor.Name = "label_projektor";
            this.label_projektor.Size = new System.Drawing.Size(108, 16);
            this.label_projektor.TabIndex = 7;
            this.label_projektor.Text = "Projektor: OFF";
            // 
            // label_flamastry
            // 
            this.label_flamastry.AutoSize = true;
            this.label_flamastry.BackColor = System.Drawing.Color.Transparent;
            this.label_flamastry.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_flamastry.ForeColor = System.Drawing.SystemColors.Control;
            this.label_flamastry.Location = new System.Drawing.Point(803, 304);
            this.label_flamastry.Name = "label_flamastry";
            this.label_flamastry.Size = new System.Drawing.Size(192, 16);
            this.label_flamastry.TabIndex = 8;
            this.label_flamastry.Text = "Poziom flamastrów: wysoki";
            // 
            // label_wifi
            // 
            this.label_wifi.AutoSize = true;
            this.label_wifi.BackColor = System.Drawing.Color.Transparent;
            this.label_wifi.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_wifi.ForeColor = System.Drawing.SystemColors.Control;
            this.label_wifi.Location = new System.Drawing.Point(822, 384);
            this.label_wifi.Name = "label_wifi";
            this.label_wifi.Size = new System.Drawing.Size(111, 16);
            this.label_wifi.TabIndex = 9;
            this.label_wifi.Text = "Sieć WiFi: OFF";
            // 
            // progressBar_poziomwody
            // 
            this.progressBar_poziomwody.Location = new System.Drawing.Point(825, 55);
            this.progressBar_poziomwody.Name = "progressBar_poziomwody";
            this.progressBar_poziomwody.Size = new System.Drawing.Size(151, 23);
            this.progressBar_poziomwody.TabIndex = 10;
            this.progressBar_poziomwody.Value = 100;
            this.progressBar_poziomwody.Click += new System.EventHandler(this.progressBar_poziomwody_Click);
            // 
            // progressBar_flamastry
            // 
            this.progressBar_flamastry.Location = new System.Drawing.Point(825, 323);
            this.progressBar_flamastry.Name = "progressBar_flamastry";
            this.progressBar_flamastry.Size = new System.Drawing.Size(151, 23);
            this.progressBar_flamastry.TabIndex = 11;
            this.progressBar_flamastry.Value = 100;
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 500;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // timer2
            // 
            this.timer2.Interval = 1000;
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::SalaKonferencyjna3.Properties.Resources.sala_konferencyjna;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1001, 612);
            this.Controls.Add(this.progressBar_flamastry);
            this.Controls.Add(this.progressBar_poziomwody);
            this.Controls.Add(this.label_wifi);
            this.Controls.Add(this.label_flamastry);
            this.Controls.Add(this.label_projektor);
            this.Controls.Add(this.label_stanrzutnika);
            this.Controls.Add(this.label_poziomwody);
            this.Controls.Add(this.button_wifi);
            this.Controls.Add(this.button_flamastry);
            this.Controls.Add(this.button_projektor);
            this.Controls.Add(this.button_rzutnik);
            this.Controls.Add(this.button_woda);
            this.Name = "Form2";
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button_woda;
        private System.Windows.Forms.Button button_rzutnik;
        private System.Windows.Forms.Button button_projektor;
        private System.Windows.Forms.Button button_flamastry;
        private System.Windows.Forms.Button button_wifi;
        private System.Windows.Forms.Label label_poziomwody;
        private System.Windows.Forms.Label label_stanrzutnika;
        private System.Windows.Forms.Label label_projektor;
        private System.Windows.Forms.Label label_flamastry;
        private System.Windows.Forms.Label label_wifi;
        private System.Windows.Forms.ProgressBar progressBar_poziomwody;
        private System.Windows.Forms.ProgressBar progressBar_flamastry;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Timer timer2;
    }
}