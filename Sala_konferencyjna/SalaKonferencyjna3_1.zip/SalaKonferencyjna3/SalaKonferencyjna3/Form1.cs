﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SalaKonferencyjna3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox_login_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (this.textBox_login.Text == "Admin" && this.textBox_haslo.Text == "12345")
            {
                this.sala = new Form2();
                this.sala.Show();
            }
            else if (this.textBox_login.Text != "Admin")
            {
                MessageBox.Show("Niepoprawny login");
            }
            else if (this.textBox_haslo.Text != "12345")
            {
                MessageBox.Show("Niepoprawne hasło");
            }
        }
    }
}
