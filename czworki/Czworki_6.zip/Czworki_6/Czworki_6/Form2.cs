﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Czworki_6
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
            pola = new List<PictureBox>() { this.pictureBox1_1, this.pictureBox2_1, this.pictureBox3_1, this.pictureBox4_1, this.pictureBox5_1, this.pictureBox6_1,
            pictureBox7_1, this.pictureBox1_2, this.pictureBox2_2, this.pictureBox3_2, this.pictureBox4_2, this.pictureBox5_2, this.pictureBox6_2, this.pictureBox7_2,
            this.pictureBox1_3, this.pictureBox2_3, this.pictureBox3_3, this.pictureBox4_3, this.pictureBox5_3, this.pictureBox6_3, this.pictureBox7_3, this.pictureBox1_4,
            this.pictureBox2_4, this.pictureBox3_4, this.pictureBox4_4, this.pictureBox5_4, this.pictureBox6_4, this.pictureBox7_4, this.pictureBox1_5, this.pictureBox2_5,
            this.pictureBox3_5, this.pictureBox4_5, this.pictureBox5_5, this.pictureBox6_5, this.pictureBox7_5, this.pictureBox1_6, this.pictureBox2_6, this.pictureBox3_6,
            this.pictureBox4_6, this.pictureBox5_6, this.pictureBox6_6, this.pictureBox7_6};
            tura_gracza1 = true;
            //this.button1.Click += (sender, e) => button1_Click(sender, e, pola);
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            czarny_zeton = Properties.Resources.czarny_zeton;
            rozowy_zeton = Properties.Resources.rozowy_zeton;
            zielony_zeton = Properties.Resources.zielony_zeton;
            niebieski_zeton = Properties.Resources.niebieski_zeton;

            this.label_kolorgracza1.Text += kolor_gracza1;
            this.label_kolorgracza2.Text += kolor_gracza2;

            switch (kolor_gracza1)
            {
                case "Niebieski":
                    zeton_gracza1 = niebieski_zeton;
                    break;
                case "Zielony":
                    zeton_gracza1 = zielony_zeton;
                    break;
                case "Czarny":
                    zeton_gracza1 = czarny_zeton;
                    break;
                case "Różowy":
                    zeton_gracza1 = rozowy_zeton;
                    break;
                default:
                    break;
            }
            switch (kolor_gracza2)
            {
                case "Niebieski":
                    zeton_gracza2 = niebieski_zeton;
                    break;
                case "Zielony":
                    zeton_gracza2 = zielony_zeton;
                    break;
                case "Czarny":
                    zeton_gracza2 = czarny_zeton;
                    break;
                case "Różowy":
                    zeton_gracza2 = rozowy_zeton;
                    break;
                default:
                    break;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //int numer = 0;
            for (int i = 0; i < 6; i++)
            {
                if (this.pola[i * 7].Image != zeton_gracza1 && this.pola[i * 7].Image != zeton_gracza2)
                {
                    if (tura_gracza1)
                    {
                        this.pola[i * 7].Image = zeton_gracza1;
                        tura_gracza1 = !tura_gracza1;
                        label_update();
                        break;
                    }
                    else
                    {
                        this.pola[i * 7].Image = zeton_gracza2;
                        tura_gracza1 = !tura_gracza1;
                        label_update();
                        break;
                    }
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            for(int i = 0; i < 6; i++)
            {
                if (this.pola[i * 7 + 1].Image != zeton_gracza1 && this.pola[i * 7 + 1].Image != zeton_gracza2)
                {
                    if (tura_gracza1)
                    {
                        this.pola[i * 7 + 1].Image = zeton_gracza1;
                        tura_gracza1 = !tura_gracza1;
                        label_update();
                        break;
                    }
                    else
                    {
                        this.pola[i * 7 + 1].Image = zeton_gracza2;
                        tura_gracza1 = !tura_gracza1;
                        label_update();
                        break;
                    }
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 6; i++)
            {
                if (this.pola[i * 7 + 2].Image != zeton_gracza1 && this.pola[i * 7 + 2].Image != zeton_gracza2)
                {
                    if (tura_gracza1)
                    {
                        this.pola[i * 7 + 2].Image = zeton_gracza1;
                        tura_gracza1 = !tura_gracza1;
                        label_update();
                        break;
                    }
                    else
                    {
                        this.pola[i * 7 + 2].Image = zeton_gracza2;
                        tura_gracza1 = !tura_gracza1;
                        label_update();
                        break;
                    }
                }
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 6; i++)
            {
                if (this.pola[i * 7 + 3].Image != zeton_gracza1 && this.pola[i * 7 + 3].Image != zeton_gracza2)
                {
                    if (tura_gracza1)
                    {
                        this.pola[i * 7 + 3].Image = zeton_gracza1;
                        tura_gracza1 = !tura_gracza1;
                        label_update();
                        break;
                    }
                    else
                    {
                        this.pola[i * 7 + 3].Image = zeton_gracza2;
                        tura_gracza1 = !tura_gracza1;
                        label_update();
                        break;
                    }
                }
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 6; i++)
            {
                if (this.pola[i * 7 + 4].Image != zeton_gracza1 && this.pola[i * 7 + 4].Image != zeton_gracza2)
                {
                    if (tura_gracza1)
                    {
                        this.pola[i * 7 + 4].Image = zeton_gracza1;
                        tura_gracza1 = !tura_gracza1;
                        label_update();
                        break;
                    }
                    else
                    {
                        this.pola[i * 7 + 4].Image = zeton_gracza2;
                        tura_gracza1 = !tura_gracza1;
                        label_update();
                        break;
                    }
                }
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 6; i++)
            {
                if (this.pola[i * 7 + 5].Image != zeton_gracza1 && this.pola[i * 7 + 5].Image != zeton_gracza2)
                {
                    if (tura_gracza1)
                    {
                        this.pola[i * 7 + 5].Image = zeton_gracza1;
                        tura_gracza1 = !tura_gracza1;
                        label_update();
                        break;
                    }
                    else
                    {
                        this.pola[i * 7 + 5].Image = zeton_gracza2;
                        tura_gracza1 = !tura_gracza1;
                        label_update();
                        break;
                    }
                }
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 6; i++)
            {
                if (this.pola[i * 7 + 6].Image != zeton_gracza1 && this.pola[i * 7 + 6].Image != zeton_gracza2)
                {
                    if (tura_gracza1)
                    {
                        this.pola[i * 7 + 6].Image = zeton_gracza1;
                        tura_gracza1 = !tura_gracza1;
                        label_update();
                        break;
                    }
                    else
                    {
                        this.pola[i * 7 + 6].Image = zeton_gracza2;
                        tura_gracza1 = !tura_gracza1;
                        label_update();
                        break;
                    }
                }
            }
        }

        public void label_update()
        {
            if (tura_gracza1)
            {
                this.label1.Text = "Tura gracza: 1";
            }
            else this.label1.Text = "Tura gracza: 2";
        }
    }
}
