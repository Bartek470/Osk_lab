﻿using System.Drawing;
using System.Windows.Forms;
using System;
using System.Collections.Generic;
namespace Czworki_6
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        public Image czarny_zeton;
        public Image rozowy_zeton;
        public Image niebieski_zeton;
        public Image zielony_zeton;
        public Image zeton_gracza1;
        public Image zeton_gracza2;
        public bool tura_gracza1;
        public string kolor_gracza1;
        public string kolor_gracza2;
        public List<PictureBox> pola;
        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            this.pictureBox7_1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2_6 = new System.Windows.Forms.PictureBox();
            this.pictureBox3_6 = new System.Windows.Forms.PictureBox();
            this.pictureBox4_6 = new System.Windows.Forms.PictureBox();
            this.pictureBox5_6 = new System.Windows.Forms.PictureBox();
            this.pictureBox6_6 = new System.Windows.Forms.PictureBox();
            this.pictureBox7_6 = new System.Windows.Forms.PictureBox();
            this.pictureBox1_5 = new System.Windows.Forms.PictureBox();
            this.pictureBox2_5 = new System.Windows.Forms.PictureBox();
            this.pictureBox3_5 = new System.Windows.Forms.PictureBox();
            this.pictureBox1_2 = new System.Windows.Forms.PictureBox();
            this.pictureBox2_2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3_2 = new System.Windows.Forms.PictureBox();
            this.pictureBox4_2 = new System.Windows.Forms.PictureBox();
            this.pictureBox5_2 = new System.Windows.Forms.PictureBox();
            this.pictureBox6_2 = new System.Windows.Forms.PictureBox();
            this.pictureBox7_2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1_1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2_1 = new System.Windows.Forms.PictureBox();
            this.pictureBox3_1 = new System.Windows.Forms.PictureBox();
            this.pictureBox4_1 = new System.Windows.Forms.PictureBox();
            this.pictureBox5_1 = new System.Windows.Forms.PictureBox();
            this.pictureBox6_1 = new System.Windows.Forms.PictureBox();
            this.pictureBox7_3 = new System.Windows.Forms.PictureBox();
            this.pictureBox6_3 = new System.Windows.Forms.PictureBox();
            this.pictureBox5_3 = new System.Windows.Forms.PictureBox();
            this.pictureBox4_3 = new System.Windows.Forms.PictureBox();
            this.pictureBox3_3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2_3 = new System.Windows.Forms.PictureBox();
            this.pictureBox1_3 = new System.Windows.Forms.PictureBox();
            this.pictureBox7_4 = new System.Windows.Forms.PictureBox();
            this.pictureBox6_4 = new System.Windows.Forms.PictureBox();
            this.pictureBox5_4 = new System.Windows.Forms.PictureBox();
            this.pictureBox4_4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3_4 = new System.Windows.Forms.PictureBox();
            this.pictureBox2_4 = new System.Windows.Forms.PictureBox();
            this.pictureBox1_4 = new System.Windows.Forms.PictureBox();
            this.pictureBox7_5 = new System.Windows.Forms.PictureBox();
            this.pictureBox6_5 = new System.Windows.Forms.PictureBox();
            this.pictureBox5_5 = new System.Windows.Forms.PictureBox();
            this.pictureBox4_5 = new System.Windows.Forms.PictureBox();
            this.pictureBox1_6 = new System.Windows.Forms.PictureBox();
            this.label_kolorgracza1 = new System.Windows.Forms.Label();
            this.label_kolorgracza2 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2_6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3_6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4_6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5_6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6_6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7_6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1_5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2_5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3_5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7_5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6_5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5_5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4_5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1_6)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox7_1
            // 
            this.pictureBox7_1.BackColor = System.Drawing.SystemColors.HotTrack;
            this.pictureBox7_1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox7_1.Image")));
            this.pictureBox7_1.Location = new System.Drawing.Point(628, 572);
            this.pictureBox7_1.Name = "pictureBox7_1";
            this.pictureBox7_1.Size = new System.Drawing.Size(80, 80);
            this.pictureBox7_1.TabIndex = 41;
            this.pictureBox7_1.TabStop = false;
            // 
            // pictureBox2_6
            // 
            this.pictureBox2_6.BackColor = System.Drawing.SystemColors.HotTrack;
            this.pictureBox2_6.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2_6.Image")));
            this.pictureBox2_6.Location = new System.Drawing.Point(198, 142);
            this.pictureBox2_6.Name = "pictureBox2_6";
            this.pictureBox2_6.Size = new System.Drawing.Size(80, 80);
            this.pictureBox2_6.TabIndex = 40;
            this.pictureBox2_6.TabStop = false;
            // 
            // pictureBox3_6
            // 
            this.pictureBox3_6.BackColor = System.Drawing.SystemColors.HotTrack;
            this.pictureBox3_6.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3_6.Image")));
            this.pictureBox3_6.Location = new System.Drawing.Point(284, 142);
            this.pictureBox3_6.Name = "pictureBox3_6";
            this.pictureBox3_6.Size = new System.Drawing.Size(80, 80);
            this.pictureBox3_6.TabIndex = 39;
            this.pictureBox3_6.TabStop = false;
            // 
            // pictureBox4_6
            // 
            this.pictureBox4_6.BackColor = System.Drawing.SystemColors.HotTrack;
            this.pictureBox4_6.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4_6.Image")));
            this.pictureBox4_6.Location = new System.Drawing.Point(370, 142);
            this.pictureBox4_6.Name = "pictureBox4_6";
            this.pictureBox4_6.Size = new System.Drawing.Size(80, 80);
            this.pictureBox4_6.TabIndex = 38;
            this.pictureBox4_6.TabStop = false;
            // 
            // pictureBox5_6
            // 
            this.pictureBox5_6.BackColor = System.Drawing.SystemColors.HotTrack;
            this.pictureBox5_6.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5_6.Image")));
            this.pictureBox5_6.Location = new System.Drawing.Point(456, 142);
            this.pictureBox5_6.Name = "pictureBox5_6";
            this.pictureBox5_6.Size = new System.Drawing.Size(80, 80);
            this.pictureBox5_6.TabIndex = 37;
            this.pictureBox5_6.TabStop = false;
            // 
            // pictureBox6_6
            // 
            this.pictureBox6_6.BackColor = System.Drawing.SystemColors.HotTrack;
            this.pictureBox6_6.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox6_6.Image")));
            this.pictureBox6_6.Location = new System.Drawing.Point(542, 142);
            this.pictureBox6_6.Name = "pictureBox6_6";
            this.pictureBox6_6.Size = new System.Drawing.Size(80, 80);
            this.pictureBox6_6.TabIndex = 36;
            this.pictureBox6_6.TabStop = false;
            // 
            // pictureBox7_6
            // 
            this.pictureBox7_6.BackColor = System.Drawing.SystemColors.HotTrack;
            this.pictureBox7_6.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox7_6.Image")));
            this.pictureBox7_6.Location = new System.Drawing.Point(628, 142);
            this.pictureBox7_6.Name = "pictureBox7_6";
            this.pictureBox7_6.Size = new System.Drawing.Size(80, 80);
            this.pictureBox7_6.TabIndex = 35;
            this.pictureBox7_6.TabStop = false;
            // 
            // pictureBox1_5
            // 
            this.pictureBox1_5.BackColor = System.Drawing.SystemColors.HotTrack;
            this.pictureBox1_5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1_5.Image")));
            this.pictureBox1_5.Location = new System.Drawing.Point(112, 228);
            this.pictureBox1_5.Name = "pictureBox1_5";
            this.pictureBox1_5.Size = new System.Drawing.Size(80, 80);
            this.pictureBox1_5.TabIndex = 34;
            this.pictureBox1_5.TabStop = false;
            // 
            // pictureBox2_5
            // 
            this.pictureBox2_5.BackColor = System.Drawing.SystemColors.HotTrack;
            this.pictureBox2_5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2_5.Image")));
            this.pictureBox2_5.Location = new System.Drawing.Point(198, 228);
            this.pictureBox2_5.Name = "pictureBox2_5";
            this.pictureBox2_5.Size = new System.Drawing.Size(80, 80);
            this.pictureBox2_5.TabIndex = 33;
            this.pictureBox2_5.TabStop = false;
            // 
            // pictureBox3_5
            // 
            this.pictureBox3_5.BackColor = System.Drawing.SystemColors.HotTrack;
            this.pictureBox3_5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3_5.Image")));
            this.pictureBox3_5.Location = new System.Drawing.Point(284, 228);
            this.pictureBox3_5.Name = "pictureBox3_5";
            this.pictureBox3_5.Size = new System.Drawing.Size(80, 80);
            this.pictureBox3_5.TabIndex = 32;
            this.pictureBox3_5.TabStop = false;
            // 
            // pictureBox1_2
            // 
            this.pictureBox1_2.BackColor = System.Drawing.SystemColors.HotTrack;
            this.pictureBox1_2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1_2.Image")));
            this.pictureBox1_2.Location = new System.Drawing.Point(112, 486);
            this.pictureBox1_2.Name = "pictureBox1_2";
            this.pictureBox1_2.Size = new System.Drawing.Size(80, 80);
            this.pictureBox1_2.TabIndex = 31;
            this.pictureBox1_2.TabStop = false;
            // 
            // pictureBox2_2
            // 
            this.pictureBox2_2.BackColor = System.Drawing.SystemColors.HotTrack;
            this.pictureBox2_2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2_2.Image")));
            this.pictureBox2_2.Location = new System.Drawing.Point(198, 486);
            this.pictureBox2_2.Name = "pictureBox2_2";
            this.pictureBox2_2.Size = new System.Drawing.Size(80, 80);
            this.pictureBox2_2.TabIndex = 30;
            this.pictureBox2_2.TabStop = false;
            // 
            // pictureBox3_2
            // 
            this.pictureBox3_2.BackColor = System.Drawing.SystemColors.HotTrack;
            this.pictureBox3_2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3_2.Image")));
            this.pictureBox3_2.Location = new System.Drawing.Point(284, 486);
            this.pictureBox3_2.Name = "pictureBox3_2";
            this.pictureBox3_2.Size = new System.Drawing.Size(80, 80);
            this.pictureBox3_2.TabIndex = 29;
            this.pictureBox3_2.TabStop = false;
            // 
            // pictureBox4_2
            // 
            this.pictureBox4_2.BackColor = System.Drawing.SystemColors.HotTrack;
            this.pictureBox4_2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4_2.Image")));
            this.pictureBox4_2.Location = new System.Drawing.Point(370, 486);
            this.pictureBox4_2.Name = "pictureBox4_2";
            this.pictureBox4_2.Size = new System.Drawing.Size(80, 80);
            this.pictureBox4_2.TabIndex = 28;
            this.pictureBox4_2.TabStop = false;
            // 
            // pictureBox5_2
            // 
            this.pictureBox5_2.BackColor = System.Drawing.SystemColors.HotTrack;
            this.pictureBox5_2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5_2.Image")));
            this.pictureBox5_2.Location = new System.Drawing.Point(456, 486);
            this.pictureBox5_2.Name = "pictureBox5_2";
            this.pictureBox5_2.Size = new System.Drawing.Size(80, 80);
            this.pictureBox5_2.TabIndex = 27;
            this.pictureBox5_2.TabStop = false;
            // 
            // pictureBox6_2
            // 
            this.pictureBox6_2.BackColor = System.Drawing.SystemColors.HotTrack;
            this.pictureBox6_2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox6_2.Image")));
            this.pictureBox6_2.Location = new System.Drawing.Point(542, 486);
            this.pictureBox6_2.Name = "pictureBox6_2";
            this.pictureBox6_2.Size = new System.Drawing.Size(80, 80);
            this.pictureBox6_2.TabIndex = 26;
            this.pictureBox6_2.TabStop = false;
            // 
            // pictureBox7_2
            // 
            this.pictureBox7_2.BackColor = System.Drawing.SystemColors.HotTrack;
            this.pictureBox7_2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox7_2.Image")));
            this.pictureBox7_2.Location = new System.Drawing.Point(628, 486);
            this.pictureBox7_2.Name = "pictureBox7_2";
            this.pictureBox7_2.Size = new System.Drawing.Size(80, 80);
            this.pictureBox7_2.TabIndex = 25;
            this.pictureBox7_2.TabStop = false;
            // 
            // pictureBox1_1
            // 
            this.pictureBox1_1.BackColor = System.Drawing.SystemColors.HotTrack;
            this.pictureBox1_1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1_1.Image")));
            this.pictureBox1_1.Location = new System.Drawing.Point(112, 572);
            this.pictureBox1_1.Name = "pictureBox1_1";
            this.pictureBox1_1.Size = new System.Drawing.Size(80, 80);
            this.pictureBox1_1.TabIndex = 24;
            this.pictureBox1_1.TabStop = false;
            // 
            // pictureBox2_1
            // 
            this.pictureBox2_1.BackColor = System.Drawing.SystemColors.HotTrack;
            this.pictureBox2_1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2_1.Image")));
            this.pictureBox2_1.Location = new System.Drawing.Point(198, 572);
            this.pictureBox2_1.Name = "pictureBox2_1";
            this.pictureBox2_1.Size = new System.Drawing.Size(80, 80);
            this.pictureBox2_1.TabIndex = 23;
            this.pictureBox2_1.TabStop = false;
            // 
            // pictureBox3_1
            // 
            this.pictureBox3_1.BackColor = System.Drawing.SystemColors.HotTrack;
            this.pictureBox3_1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3_1.Image")));
            this.pictureBox3_1.Location = new System.Drawing.Point(284, 572);
            this.pictureBox3_1.Name = "pictureBox3_1";
            this.pictureBox3_1.Size = new System.Drawing.Size(80, 80);
            this.pictureBox3_1.TabIndex = 22;
            this.pictureBox3_1.TabStop = false;
            // 
            // pictureBox4_1
            // 
            this.pictureBox4_1.BackColor = System.Drawing.SystemColors.HotTrack;
            this.pictureBox4_1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4_1.Image")));
            this.pictureBox4_1.Location = new System.Drawing.Point(370, 572);
            this.pictureBox4_1.Name = "pictureBox4_1";
            this.pictureBox4_1.Size = new System.Drawing.Size(80, 80);
            this.pictureBox4_1.TabIndex = 21;
            this.pictureBox4_1.TabStop = false;
            // 
            // pictureBox5_1
            // 
            this.pictureBox5_1.BackColor = System.Drawing.SystemColors.HotTrack;
            this.pictureBox5_1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5_1.Image")));
            this.pictureBox5_1.Location = new System.Drawing.Point(456, 572);
            this.pictureBox5_1.Name = "pictureBox5_1";
            this.pictureBox5_1.Size = new System.Drawing.Size(80, 80);
            this.pictureBox5_1.TabIndex = 20;
            this.pictureBox5_1.TabStop = false;
            // 
            // pictureBox6_1
            // 
            this.pictureBox6_1.BackColor = System.Drawing.SystemColors.HotTrack;
            this.pictureBox6_1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox6_1.Image")));
            this.pictureBox6_1.Location = new System.Drawing.Point(542, 572);
            this.pictureBox6_1.Name = "pictureBox6_1";
            this.pictureBox6_1.Size = new System.Drawing.Size(80, 80);
            this.pictureBox6_1.TabIndex = 19;
            this.pictureBox6_1.TabStop = false;
            // 
            // pictureBox7_3
            // 
            this.pictureBox7_3.BackColor = System.Drawing.SystemColors.HotTrack;
            this.pictureBox7_3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox7_3.Image")));
            this.pictureBox7_3.Location = new System.Drawing.Point(628, 400);
            this.pictureBox7_3.Name = "pictureBox7_3";
            this.pictureBox7_3.Size = new System.Drawing.Size(80, 80);
            this.pictureBox7_3.TabIndex = 18;
            this.pictureBox7_3.TabStop = false;
            // 
            // pictureBox6_3
            // 
            this.pictureBox6_3.BackColor = System.Drawing.SystemColors.HotTrack;
            this.pictureBox6_3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox6_3.Image")));
            this.pictureBox6_3.Location = new System.Drawing.Point(542, 400);
            this.pictureBox6_3.Name = "pictureBox6_3";
            this.pictureBox6_3.Size = new System.Drawing.Size(80, 80);
            this.pictureBox6_3.TabIndex = 17;
            this.pictureBox6_3.TabStop = false;
            // 
            // pictureBox5_3
            // 
            this.pictureBox5_3.BackColor = System.Drawing.SystemColors.HotTrack;
            this.pictureBox5_3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5_3.Image")));
            this.pictureBox5_3.Location = new System.Drawing.Point(456, 400);
            this.pictureBox5_3.Name = "pictureBox5_3";
            this.pictureBox5_3.Size = new System.Drawing.Size(80, 80);
            this.pictureBox5_3.TabIndex = 16;
            this.pictureBox5_3.TabStop = false;
            // 
            // pictureBox4_3
            // 
            this.pictureBox4_3.BackColor = System.Drawing.SystemColors.HotTrack;
            this.pictureBox4_3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4_3.Image")));
            this.pictureBox4_3.Location = new System.Drawing.Point(370, 400);
            this.pictureBox4_3.Name = "pictureBox4_3";
            this.pictureBox4_3.Size = new System.Drawing.Size(80, 80);
            this.pictureBox4_3.TabIndex = 15;
            this.pictureBox4_3.TabStop = false;
            // 
            // pictureBox3_3
            // 
            this.pictureBox3_3.BackColor = System.Drawing.SystemColors.HotTrack;
            this.pictureBox3_3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3_3.Image")));
            this.pictureBox3_3.Location = new System.Drawing.Point(284, 400);
            this.pictureBox3_3.Name = "pictureBox3_3";
            this.pictureBox3_3.Size = new System.Drawing.Size(80, 80);
            this.pictureBox3_3.TabIndex = 14;
            this.pictureBox3_3.TabStop = false;
            // 
            // pictureBox2_3
            // 
            this.pictureBox2_3.BackColor = System.Drawing.SystemColors.HotTrack;
            this.pictureBox2_3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2_3.Image")));
            this.pictureBox2_3.Location = new System.Drawing.Point(198, 400);
            this.pictureBox2_3.Name = "pictureBox2_3";
            this.pictureBox2_3.Size = new System.Drawing.Size(80, 80);
            this.pictureBox2_3.TabIndex = 13;
            this.pictureBox2_3.TabStop = false;
            // 
            // pictureBox1_3
            // 
            this.pictureBox1_3.BackColor = System.Drawing.SystemColors.HotTrack;
            this.pictureBox1_3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1_3.Image")));
            this.pictureBox1_3.Location = new System.Drawing.Point(112, 400);
            this.pictureBox1_3.Name = "pictureBox1_3";
            this.pictureBox1_3.Size = new System.Drawing.Size(80, 80);
            this.pictureBox1_3.TabIndex = 12;
            this.pictureBox1_3.TabStop = false;
            // 
            // pictureBox7_4
            // 
            this.pictureBox7_4.BackColor = System.Drawing.SystemColors.HotTrack;
            this.pictureBox7_4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox7_4.Image")));
            this.pictureBox7_4.Location = new System.Drawing.Point(628, 314);
            this.pictureBox7_4.Name = "pictureBox7_4";
            this.pictureBox7_4.Size = new System.Drawing.Size(80, 80);
            this.pictureBox7_4.TabIndex = 11;
            this.pictureBox7_4.TabStop = false;
            // 
            // pictureBox6_4
            // 
            this.pictureBox6_4.BackColor = System.Drawing.SystemColors.HotTrack;
            this.pictureBox6_4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox6_4.Image")));
            this.pictureBox6_4.Location = new System.Drawing.Point(542, 314);
            this.pictureBox6_4.Name = "pictureBox6_4";
            this.pictureBox6_4.Size = new System.Drawing.Size(80, 80);
            this.pictureBox6_4.TabIndex = 10;
            this.pictureBox6_4.TabStop = false;
            // 
            // pictureBox5_4
            // 
            this.pictureBox5_4.BackColor = System.Drawing.SystemColors.HotTrack;
            this.pictureBox5_4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5_4.Image")));
            this.pictureBox5_4.Location = new System.Drawing.Point(456, 314);
            this.pictureBox5_4.Name = "pictureBox5_4";
            this.pictureBox5_4.Size = new System.Drawing.Size(80, 80);
            this.pictureBox5_4.TabIndex = 9;
            this.pictureBox5_4.TabStop = false;
            // 
            // pictureBox4_4
            // 
            this.pictureBox4_4.BackColor = System.Drawing.SystemColors.HotTrack;
            this.pictureBox4_4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4_4.Image")));
            this.pictureBox4_4.Location = new System.Drawing.Point(370, 314);
            this.pictureBox4_4.Name = "pictureBox4_4";
            this.pictureBox4_4.Size = new System.Drawing.Size(80, 80);
            this.pictureBox4_4.TabIndex = 8;
            this.pictureBox4_4.TabStop = false;
            // 
            // pictureBox3_4
            // 
            this.pictureBox3_4.BackColor = System.Drawing.SystemColors.HotTrack;
            this.pictureBox3_4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3_4.Image")));
            this.pictureBox3_4.Location = new System.Drawing.Point(284, 314);
            this.pictureBox3_4.Name = "pictureBox3_4";
            this.pictureBox3_4.Size = new System.Drawing.Size(80, 80);
            this.pictureBox3_4.TabIndex = 7;
            this.pictureBox3_4.TabStop = false;
            // 
            // pictureBox2_4
            // 
            this.pictureBox2_4.BackColor = System.Drawing.SystemColors.HotTrack;
            this.pictureBox2_4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2_4.Image")));
            this.pictureBox2_4.Location = new System.Drawing.Point(198, 314);
            this.pictureBox2_4.Name = "pictureBox2_4";
            this.pictureBox2_4.Size = new System.Drawing.Size(80, 80);
            this.pictureBox2_4.TabIndex = 6;
            this.pictureBox2_4.TabStop = false;
            // 
            // pictureBox1_4
            // 
            this.pictureBox1_4.BackColor = System.Drawing.SystemColors.HotTrack;
            this.pictureBox1_4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1_4.Image")));
            this.pictureBox1_4.Location = new System.Drawing.Point(112, 314);
            this.pictureBox1_4.Name = "pictureBox1_4";
            this.pictureBox1_4.Size = new System.Drawing.Size(80, 80);
            this.pictureBox1_4.TabIndex = 5;
            this.pictureBox1_4.TabStop = false;
            // 
            // pictureBox7_5
            // 
            this.pictureBox7_5.BackColor = System.Drawing.SystemColors.HotTrack;
            this.pictureBox7_5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox7_5.Image")));
            this.pictureBox7_5.Location = new System.Drawing.Point(628, 228);
            this.pictureBox7_5.Name = "pictureBox7_5";
            this.pictureBox7_5.Size = new System.Drawing.Size(80, 80);
            this.pictureBox7_5.TabIndex = 4;
            this.pictureBox7_5.TabStop = false;
            // 
            // pictureBox6_5
            // 
            this.pictureBox6_5.BackColor = System.Drawing.SystemColors.HotTrack;
            this.pictureBox6_5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox6_5.Image")));
            this.pictureBox6_5.Location = new System.Drawing.Point(542, 228);
            this.pictureBox6_5.Name = "pictureBox6_5";
            this.pictureBox6_5.Size = new System.Drawing.Size(80, 80);
            this.pictureBox6_5.TabIndex = 3;
            this.pictureBox6_5.TabStop = false;
            // 
            // pictureBox5_5
            // 
            this.pictureBox5_5.BackColor = System.Drawing.SystemColors.HotTrack;
            this.pictureBox5_5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5_5.Image")));
            this.pictureBox5_5.Location = new System.Drawing.Point(456, 228);
            this.pictureBox5_5.Name = "pictureBox5_5";
            this.pictureBox5_5.Size = new System.Drawing.Size(80, 80);
            this.pictureBox5_5.TabIndex = 2;
            this.pictureBox5_5.TabStop = false;
            // 
            // pictureBox4_5
            // 
            this.pictureBox4_5.BackColor = System.Drawing.SystemColors.HotTrack;
            this.pictureBox4_5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4_5.Image")));
            this.pictureBox4_5.Location = new System.Drawing.Point(370, 228);
            this.pictureBox4_5.Name = "pictureBox4_5";
            this.pictureBox4_5.Size = new System.Drawing.Size(80, 80);
            this.pictureBox4_5.TabIndex = 1;
            this.pictureBox4_5.TabStop = false;
            // 
            // pictureBox1_6
            // 
            this.pictureBox1_6.BackColor = System.Drawing.SystemColors.HotTrack;
            this.pictureBox1_6.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1_6.Image")));
            this.pictureBox1_6.Location = new System.Drawing.Point(112, 142);
            this.pictureBox1_6.Name = "pictureBox1_6";
            this.pictureBox1_6.Size = new System.Drawing.Size(80, 80);
            this.pictureBox1_6.TabIndex = 0;
            this.pictureBox1_6.TabStop = false;
            // 
            // label_kolorgracza1
            // 
            this.label_kolorgracza1.AutoSize = true;
            this.label_kolorgracza1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_kolorgracza1.Location = new System.Drawing.Point(880, 108);
            this.label_kolorgracza1.Name = "label_kolorgracza1";
            this.label_kolorgracza1.Size = new System.Drawing.Size(257, 25);
            this.label_kolorgracza1.TabIndex = 42;
            this.label_kolorgracza1.Text = "Kolor żetonu gracza 1: ";
            // 
            // label_kolorgracza2
            // 
            this.label_kolorgracza2.AutoSize = true;
            this.label_kolorgracza2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_kolorgracza2.Location = new System.Drawing.Point(880, 152);
            this.label_kolorgracza2.Name = "label_kolorgracza2";
            this.label_kolorgracza2.Size = new System.Drawing.Size(257, 25);
            this.label_kolorgracza2.TabIndex = 43;
            this.label_kolorgracza2.Text = "Kolor żetonu gracza 2: ";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(112, 42);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(80, 47);
            this.button1.TabIndex = 44;
            this.button1.Text = "1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(198, 42);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(80, 47);
            this.button2.TabIndex = 45;
            this.button2.Text = "2";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(284, 42);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(80, 47);
            this.button3.TabIndex = 46;
            this.button3.Text = "3";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(370, 42);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(80, 47);
            this.button4.TabIndex = 47;
            this.button4.Text = "4";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(456, 42);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(80, 47);
            this.button5.TabIndex = 48;
            this.button5.Text = "5";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(542, 42);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(80, 47);
            this.button6.TabIndex = 49;
            this.button6.Text = "6";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(628, 42);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(80, 47);
            this.button7.TabIndex = 50;
            this.button7.Text = "7";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(880, 283);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(165, 25);
            this.label1.TabIndex = 51;
            this.label1.Text = "Tura gracza: 1";
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1344, 731);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label_kolorgracza2);
            this.Controls.Add(this.label_kolorgracza1);
            this.Controls.Add(this.pictureBox7_1);
            this.Controls.Add(this.pictureBox2_6);
            this.Controls.Add(this.pictureBox3_6);
            this.Controls.Add(this.pictureBox4_6);
            this.Controls.Add(this.pictureBox5_6);
            this.Controls.Add(this.pictureBox6_6);
            this.Controls.Add(this.pictureBox7_6);
            this.Controls.Add(this.pictureBox1_5);
            this.Controls.Add(this.pictureBox2_5);
            this.Controls.Add(this.pictureBox3_5);
            this.Controls.Add(this.pictureBox1_2);
            this.Controls.Add(this.pictureBox2_2);
            this.Controls.Add(this.pictureBox3_2);
            this.Controls.Add(this.pictureBox4_2);
            this.Controls.Add(this.pictureBox5_2);
            this.Controls.Add(this.pictureBox6_2);
            this.Controls.Add(this.pictureBox7_2);
            this.Controls.Add(this.pictureBox1_1);
            this.Controls.Add(this.pictureBox2_1);
            this.Controls.Add(this.pictureBox3_1);
            this.Controls.Add(this.pictureBox4_1);
            this.Controls.Add(this.pictureBox5_1);
            this.Controls.Add(this.pictureBox6_1);
            this.Controls.Add(this.pictureBox7_3);
            this.Controls.Add(this.pictureBox6_3);
            this.Controls.Add(this.pictureBox5_3);
            this.Controls.Add(this.pictureBox4_3);
            this.Controls.Add(this.pictureBox3_3);
            this.Controls.Add(this.pictureBox2_3);
            this.Controls.Add(this.pictureBox1_3);
            this.Controls.Add(this.pictureBox7_4);
            this.Controls.Add(this.pictureBox6_4);
            this.Controls.Add(this.pictureBox5_4);
            this.Controls.Add(this.pictureBox4_4);
            this.Controls.Add(this.pictureBox3_4);
            this.Controls.Add(this.pictureBox2_4);
            this.Controls.Add(this.pictureBox1_4);
            this.Controls.Add(this.pictureBox7_5);
            this.Controls.Add(this.pictureBox6_5);
            this.Controls.Add(this.pictureBox5_5);
            this.Controls.Add(this.pictureBox4_5);
            this.Controls.Add(this.pictureBox1_6);
            this.Name = "Form2";
            this.Text = "Gra";
            this.Load += new System.EventHandler(this.Form2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2_6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3_6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4_6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5_6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6_6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7_6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1_5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2_5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3_5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7_5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6_5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5_5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4_5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1_6)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1_6;
        private System.Windows.Forms.PictureBox pictureBox4_5;
        private System.Windows.Forms.PictureBox pictureBox5_5;
        private System.Windows.Forms.PictureBox pictureBox6_5;
        private System.Windows.Forms.PictureBox pictureBox7_5;
        private System.Windows.Forms.PictureBox pictureBox1_4;
        private System.Windows.Forms.PictureBox pictureBox2_4;
        private System.Windows.Forms.PictureBox pictureBox3_4;
        private System.Windows.Forms.PictureBox pictureBox4_4;
        private System.Windows.Forms.PictureBox pictureBox5_4;
        private System.Windows.Forms.PictureBox pictureBox6_4;
        private System.Windows.Forms.PictureBox pictureBox7_4;
        private System.Windows.Forms.PictureBox pictureBox1_3;
        private System.Windows.Forms.PictureBox pictureBox2_3;
        private System.Windows.Forms.PictureBox pictureBox3_3;
        private System.Windows.Forms.PictureBox pictureBox4_3;
        private System.Windows.Forms.PictureBox pictureBox5_3;
        private System.Windows.Forms.PictureBox pictureBox6_3;
        private System.Windows.Forms.PictureBox pictureBox7_3;
        private System.Windows.Forms.PictureBox pictureBox6_1;
        private System.Windows.Forms.PictureBox pictureBox5_1;
        private System.Windows.Forms.PictureBox pictureBox4_1;
        private System.Windows.Forms.PictureBox pictureBox3_1;
        private System.Windows.Forms.PictureBox pictureBox2_1;
        private System.Windows.Forms.PictureBox pictureBox1_1;
        private System.Windows.Forms.PictureBox pictureBox7_2;
        private System.Windows.Forms.PictureBox pictureBox6_2;
        private System.Windows.Forms.PictureBox pictureBox5_2;
        private System.Windows.Forms.PictureBox pictureBox4_2;
        private System.Windows.Forms.PictureBox pictureBox3_2;
        private System.Windows.Forms.PictureBox pictureBox2_2;
        private System.Windows.Forms.PictureBox pictureBox1_2;
        private System.Windows.Forms.PictureBox pictureBox3_5;
        private System.Windows.Forms.PictureBox pictureBox2_5;
        private System.Windows.Forms.PictureBox pictureBox1_5;
        private System.Windows.Forms.PictureBox pictureBox7_6;
        private System.Windows.Forms.PictureBox pictureBox6_6;
        private System.Windows.Forms.PictureBox pictureBox5_6;
        private System.Windows.Forms.PictureBox pictureBox4_6;
        private System.Windows.Forms.PictureBox pictureBox3_6;
        private System.Windows.Forms.PictureBox pictureBox2_6;
        private System.Windows.Forms.PictureBox pictureBox7_1;
        private System.Windows.Forms.Label label_kolorgracza1;
        private System.Windows.Forms.Label label_kolorgracza2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private Label label1;
    }
}