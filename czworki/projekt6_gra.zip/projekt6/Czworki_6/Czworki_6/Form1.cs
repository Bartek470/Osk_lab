﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Czworki_6
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (this.comboBox_wyborgracza1.Text != "" && this.comboBox_wyborgracza2.Text != "" && this.comboBox_wyborgracza1.Text != this.comboBox_wyborgracza2.Text)
            {
                this.gra = new Form2();
                gra.kolor_gracza1 = this.comboBox_wyborgracza1.Text;
                gra.kolor_gracza2 = this.comboBox_wyborgracza2.Text;
                this.gra.Show();
            }
            else MessageBox.Show("Błędny wybór żetonów");
            
        }
    }
}
