﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace kalkulator1
{
    public partial class Form3 : Form
    {
        int xo, yo;
        int WIDTH = 300, HEIGHT = 300, Lh = 80, Lm = 110, Ls = 140;
        Graphics g;
        Bitmap bmp;

        public Form3()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            bmp = new Bitmap(WIDTH + 1, HEIGHT + 1);
            xo = WIDTH / 2;
            yo = HEIGHT / 2;
            timer1.Tick += new EventHandler(this.timer1_Tick);
            timer1.Start();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            g = Graphics.FromImage(bmp);
            int s = DateTime.Now.Second;
            int m = DateTime.Now.Minute;
            int h = DateTime.Now.Hour;
            int[] hand = new int[2];
            g.Clear(Color.White);
            //rysowanie tarczy
            g.DrawEllipse(new Pen(Color.Black, 1f), 0, 0, WIDTH, HEIGHT);
            g.DrawString("12", new Font("Arial", 12), Brushes.Black, new PointF(140, 2));
            g.DrawString("3", new Font("Arial", 12), Brushes.Black, new PointF(286, 140));
            g.DrawString("6", new Font("Arial", 12), Brushes.Black, new PointF(142, 282));
            g.DrawString("9", new Font("Arial", 12), Brushes.Black, new PointF(0, 140));
            hand = msCoordinates(s, Ls);
            g.DrawLine(new Pen(Color.Red, 1f), new Point(xo, yo), new Point(hand[0], hand[1]));
            hand = msCoordinates(m, Lm);
            g.DrawLine(new Pen(Color.Black, 2f), new Point(xo, yo), new Point(hand[0], hand[1]));
            hand = hCoordinates(h, m,Lh);
            g.DrawLine(new Pen(Color.Black, 3f), new Point(xo, yo), new Point(hand[0], hand[1]));
            pictureBox1.Image = bmp;
            g.Dispose();
        }
        private int[] msCoordinates(int val, int leng)
        {
            int[] coordinates = new int[2];
            val *= 6;
            if (val >= 0 && val <= 180)
            {
                coordinates[0] = xo + (int)(leng * Math.Sin(Math.PI * val / 180));
                coordinates[1] = yo - (int)(leng * Math.Cos(Math.PI * val / 180));
            }
            else
            {
                coordinates[0] = xo - (int)(leng * -Math.Sin(Math.PI * val / 180));
                coordinates[1] = yo - (int)(leng * Math.Cos(Math.PI * val / 180));
            }
            return coordinates;
        }
        private int[] hCoordinates(int hval, int mval, int leng)
        {
            int[] coordinates = new int[2];
            hval = hval % 12;
            int val = (int)((hval * 30) + (mval * 0.5));
            if (val >= 0 && val <= 180)
            {
                coordinates[0] = xo + (int)(leng * Math.Sin(Math.PI * val / 180));
                coordinates[1] = yo - (int)(leng * Math.Cos(Math.PI * val / 180));
            }
            else
            {
                coordinates[0] = xo - (int)(leng * -Math.Sin(Math.PI * val / 180));
                coordinates[1] = yo - (int)(leng * Math.Cos(Math.PI * val / 180));
            }
            return coordinates;
        }
    }
}
