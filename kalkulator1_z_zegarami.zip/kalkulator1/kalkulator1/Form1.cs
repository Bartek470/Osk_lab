﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace kalkulator1
{
    public partial class Form1 : Form
    {
        private string liczba_string1;
        private double liczba1;
        private string liczba_string2;
        private double liczba2;
        private bool ostatnia_liczba;
        private bool liczba1_zakonczona;
        private bool liczba2_zakonczona;
        private bool dzialanie_zrobione;
        private bool liczba2_rozpoczeta;
        private char dzialanie;
        private double wynik;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            ostatnia_liczba = false;
            liczba1_zakonczona = false;
            liczba2_zakonczona = false;
            dzialanie_zrobione = false;
            liczba2_rozpoczeta = false;
        }

        private void button1_Click(object sender, EventArgs e) // przycisk +
        {
            if (ostatnia_liczba && !dzialanie_zrobione)
            {
                liczba1_zakonczona = true;
                dzialanie = '+';
                ostatnia_liczba = false;
                dzialanie_zrobione = true;
                this.label1.Text = this.label1.Text + "+";
                //liczba_string1 = liczba_string1 + "D";
                liczba1 = Convert.ToDouble(liczba_string1);
            }
        }

        private void button2_Click(object sender, EventArgs e) // przycisk =
        {
            if (ostatnia_liczba && dzialanie_zrobione && liczba1_zakonczona)
            {
                liczba2_zakonczona = true;
                //liczba_string2 = liczba_string2 + "D";
                liczba2 = Convert.ToDouble(liczba_string2);
                switch (dzialanie) {
                    case '+':
                        wynik = liczba1 + liczba2;
                        break;
                    case '-':
                        wynik = liczba1 - liczba2;
                        break;
                    case 'x':
                        wynik = liczba1 * liczba2;
                        break;
                    case '/':
                        wynik = liczba1 / liczba2;
                        break;
                }
                this.label1.Text = Convert.ToString(wynik);
                liczba1 = wynik;
                liczba_string1 = Convert.ToString(liczba1);
                liczba2 = 0;
                liczba_string2 = "";
                ostatnia_liczba = true;
                //liczba1_zakonczona = true;
                liczba1_zakonczona = false;
                dzialanie_zrobione = false;
                liczba2_zakonczona = false;
            }
        }

        private void zakończToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void ciemnaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.BackColor = Color.DarkGray;
            this.label1.ForeColor = Color.White;
            zmiana_przyciskow(this.button1, 'c');
            zmiana_przyciskow(this.button2, 'c');
            zmiana_przyciskow(this.button3, 'c');
            zmiana_przyciskow(this.button4, 'c');
            zmiana_przyciskow(this.button5, 'c');
            zmiana_przyciskow(this.button6, 'c');
            zmiana_przyciskow(this.button7, 'c');
            zmiana_przyciskow(this.button8, 'c');
            zmiana_przyciskow(this.button9, 'c');
            zmiana_przyciskow(this.button10, 'c');
            zmiana_przyciskow(this.button11, 'c');
            zmiana_przyciskow(this.button12, 'c');
            zmiana_przyciskow(this.button13, 'c');
            zmiana_przyciskow(this.button14, 'c');
            zmiana_przyciskow(this.button15, 'c');
            zmiana_przyciskow(this.button16, 'c');
            zmiana_przyciskow(this.button17, 'c');
            zmiana_przyciskow(this.button18, 'c');
        }

        private void nIebieskaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.BackColor = Color.Blue;
            this.label1.ForeColor = Color.White;
            zmiana_przyciskow(this.button1, 'n');
            zmiana_przyciskow(this.button2, 'n');
            zmiana_przyciskow(this.button3, 'n');
            zmiana_przyciskow(this.button4, 'n');
            zmiana_przyciskow(this.button5, 'n');
            zmiana_przyciskow(this.button6, 'n');
            zmiana_przyciskow(this.button7, 'n');
            zmiana_przyciskow(this.button8, 'n');
            zmiana_przyciskow(this.button9, 'n');
            zmiana_przyciskow(this.button10, 'n');
            zmiana_przyciskow(this.button11, 'n');
            zmiana_przyciskow(this.button12, 'n');
            zmiana_przyciskow(this.button13, 'n');
            zmiana_przyciskow(this.button14, 'n');
            zmiana_przyciskow(this.button15, 'n');
            zmiana_przyciskow(this.button16, 'n');
            zmiana_przyciskow(this.button17, 'n');
            zmiana_przyciskow(this.button18, 'n');
        }

        private void jasnaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.BackColor = Color.White;
            this.label1.ForeColor = Color.Black;
            zmiana_przyciskow(this.button1, 'b');
            zmiana_przyciskow(this.button2, 'b');
            zmiana_przyciskow(this.button3, 'b');
            zmiana_przyciskow(this.button4, 'b');
            zmiana_przyciskow(this.button5, 'b');
            zmiana_przyciskow(this.button6, 'b');
            zmiana_przyciskow(this.button7, 'b');
            zmiana_przyciskow(this.button8, 'b');
            zmiana_przyciskow(this.button9, 'b');
            zmiana_przyciskow(this.button10, 'b');
            zmiana_przyciskow(this.button11, 'b');
            zmiana_przyciskow(this.button12, 'b');
            zmiana_przyciskow(this.button13, 'b');
            zmiana_przyciskow(this.button14, 'b');
            zmiana_przyciskow(this.button15, 'b');
            zmiana_przyciskow(this.button16, 'b');
            zmiana_przyciskow(this.button17, 'b');
            zmiana_przyciskow(this.button18, 'b');
        }

        private void button4_Click(object sender, EventArgs e) //przycisk 0
        {
            if (!dzialanie_zrobione)
            {
                this.label1.Text = this.label1.Text + "0";
                liczba_string1 = liczba_string1 + "0";
                ostatnia_liczba = true;
            }
            else
            {
                this.label1.Text = this.label1.Text + "0";
                liczba_string2 = liczba_string2 + "0";
                ostatnia_liczba = true;
            }
        }

        private void button5_Click(object sender, EventArgs e) //przycisk 1
        {
            if (!dzialanie_zrobione)
            {
                this.label1.Text = this.label1.Text + "1";
                liczba_string1 = liczba_string1 + "1";
                ostatnia_liczba = true;
            }
            else
            {
                this.label1.Text = this.label1.Text + "1";
                liczba_string2 = liczba_string2 + "1";
                ostatnia_liczba = true;
                liczba2_rozpoczeta = true;
            }
        }

        private void button6_Click(object sender, EventArgs e) //przycisk 2
        {
            if (!dzialanie_zrobione)
            {
                this.label1.Text = this.label1.Text + "2";
                liczba_string1 = liczba_string1 + "2";
                ostatnia_liczba = true;
            }
            else
            {
                this.label1.Text = this.label1.Text + "2";
                liczba_string2 = liczba_string2 + "2";
                ostatnia_liczba = true;
                liczba2_rozpoczeta = true;
            }
        }

        private void button7_Click(object sender, EventArgs e) //przycisk 3
        {
            if (!dzialanie_zrobione)
            {
                this.label1.Text = this.label1.Text + "3";
                liczba_string1 = liczba_string1 + "3";
                ostatnia_liczba = true;
            }
            else
            {
                this.label1.Text = this.label1.Text + "3";
                liczba_string2 = liczba_string2 + "3";
                ostatnia_liczba = true;
                liczba2_rozpoczeta = true;
            }
        }

        private void button9_Click(object sender, EventArgs e) //przycisk 4
        {
            if (!dzialanie_zrobione)
            {
                this.label1.Text = this.label1.Text + "4";
                liczba_string1 = liczba_string1 + "4";
                ostatnia_liczba = true;
            }
            else
            {
                this.label1.Text = this.label1.Text + "4";
                liczba_string2 = liczba_string2 + "4";
                ostatnia_liczba = true;
                liczba2_rozpoczeta = true;
            }
        }

        private void button10_Click(object sender, EventArgs e) //przycisk 5
        {
            if (!dzialanie_zrobione)
            {
                this.label1.Text = this.label1.Text + "5";
                liczba_string1 = liczba_string1 + "5";
                ostatnia_liczba = true;
            }
            else
            {
                this.label1.Text = this.label1.Text + "5";
                liczba_string2 = liczba_string2 + "5";
                ostatnia_liczba = true;
                liczba2_rozpoczeta = true;
            }
        }

        private void button11_Click(object sender, EventArgs e) //przycisk 6
        {
            if (!dzialanie_zrobione)
            {
                this.label1.Text = this.label1.Text + "6";
                liczba_string1 = liczba_string1 + "6";
                ostatnia_liczba = true;
            }
            else
            {
                this.label1.Text = this.label1.Text + "6";
                liczba_string2 = liczba_string2 + "6";
                ostatnia_liczba = true;
                liczba2_rozpoczeta = true;
            }
        }

        private void button13_Click(object sender, EventArgs e) //przycisk 7
        {
            if (!dzialanie_zrobione)
            {
                this.label1.Text = this.label1.Text + "7";
                liczba_string1 = liczba_string1 + "7";
                ostatnia_liczba = true;
            }
            else
            {
                this.label1.Text = this.label1.Text + "7";
                liczba_string2 = liczba_string2 + "7";
                ostatnia_liczba = true;
                liczba2_rozpoczeta = true;
            }
        }

        private void button14_Click(object sender, EventArgs e) //przycisk 8
        {
            if (!dzialanie_zrobione)
            {
                this.label1.Text = this.label1.Text + "8";
                liczba_string1 = liczba_string1 + "8";
                ostatnia_liczba = true;
            }
            else
            {
                this.label1.Text = this.label1.Text + "8";
                liczba_string2 = liczba_string2 + "8";
                ostatnia_liczba = true;
                liczba2_rozpoczeta = true;
            }
        }

        private void button15_Click(object sender, EventArgs e) //przycisk 9
        {
            if (!dzialanie_zrobione)
            {
                this.label1.Text = this.label1.Text + "9";
                liczba_string1 = liczba_string1 + "9";
                ostatnia_liczba = true;
            }
            else
            {
                this.label1.Text = this.label1.Text + "9";
                liczba_string2 = liczba_string2 + "9";
                ostatnia_liczba = true;
                liczba2_rozpoczeta = true;
            }
        }

        private void button3_Click(object sender, EventArgs e) //przycisk .
        {
            if (!dzialanie_zrobione)
            {
                this.label1.Text = this.label1.Text + ",";
                liczba_string1 = liczba_string1 + ",";
                ostatnia_liczba = true;
            }
            else
            {
                this.label1.Text = this.label1.Text + ",";
                liczba_string2 = liczba_string2 + ",";
                ostatnia_liczba = true;
            }
        }

        private void button8_Click(object sender, EventArgs e) //przycisk -
        {
            if (ostatnia_liczba && !dzialanie_zrobione)
            {
                liczba1_zakonczona = true;
                dzialanie = '-';
                ostatnia_liczba = false;
                dzialanie_zrobione = true;
                this.label1.Text = this.label1.Text + "-";
                //liczba_string1 = liczba_string1 + "D";
                liczba1 = Convert.ToDouble(liczba_string1);
            }
        }

        private void button12_Click(object sender, EventArgs e) //przycisk x
        {
            if (ostatnia_liczba && !dzialanie_zrobione)
            {
                liczba1_zakonczona = true;
                dzialanie = 'x';
                ostatnia_liczba = false;
                dzialanie_zrobione = true;
                this.label1.Text = this.label1.Text + "X";
                //liczba_string1 = liczba_string1 + "D";
                liczba1 = Convert.ToDouble(liczba_string1);
            }
        }

        private void button16_Click(object sender, EventArgs e) //przycisk /
        {
            if (ostatnia_liczba && !dzialanie_zrobione)
            {
                liczba1_zakonczona = true;
                dzialanie = '/';
                ostatnia_liczba = false;
                dzialanie_zrobione = true;
                this.label1.Text = this.label1.Text + "/";
                //liczba_string1 = liczba_string1 + "D";
                liczba1 = Convert.ToDouble(liczba_string1);
            }
        }

        private void button17_Click(object sender, EventArgs e) //przycisk CE
        {
            ostatnia_liczba = false;
            liczba1_zakonczona = false;
            liczba2_zakonczona = false;
            dzialanie_zrobione = false;
            liczba_string1 = "";
            liczba_string2 = "";
            this.label1.Text = "";
        }

        private void wojskowaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.BackColor = Color.DarkGreen;
            this.label1.ForeColor = Color.White;
            zmiana_przyciskow(this.button1, 'w');
            zmiana_przyciskow(this.button2, 'w');
            zmiana_przyciskow(this.button3, 'w');
            zmiana_przyciskow(this.button4, 'w');
            zmiana_przyciskow(this.button5, 'w');
            zmiana_przyciskow(this.button6, 'w');
            zmiana_przyciskow(this.button7, 'w');
            zmiana_przyciskow(this.button8, 'w');
            zmiana_przyciskow(this.button9, 'w');
            zmiana_przyciskow(this.button10, 'w');
            zmiana_przyciskow(this.button11, 'w');
            zmiana_przyciskow(this.button12, 'w');
            zmiana_przyciskow(this.button13, 'w');
            zmiana_przyciskow(this.button14, 'w');
            zmiana_przyciskow(this.button15, 'w');
            zmiana_przyciskow(this.button16, 'w');
            zmiana_przyciskow(this.button17, 'w');
            zmiana_przyciskow(this.button18, 'w');
        }

        private void zmiana_przyciskow(Button button, char wybor)
        {
            switch (wybor)
            {
                case 'b':
                    button.BackColor = Color.White;
                    button.ForeColor = Color.Black;
                    break;
                case 'n':
                    button.BackColor = Color.LightBlue;
                    button.ForeColor = Color.Black;
                    break;
                case 'w':
                    button.BackColor = Color.LightGreen;
                    button.ForeColor = Color.Black;
                    break;
                case 'c':
                    button.BackColor = Color.DarkSlateGray;
                    button.ForeColor = Color.White;
                    break;
            }
        }

        private void button18_Click(object sender, EventArgs e)
        {
            //char sample = this.label1.Text.Last();
            char[] text = new char[this.label1.Text.Length + 1];
            for (int i = 0; i < this.label1.Text.Length - 1; i++)
            {
                text[i] = this.label1.Text[i];
            }
            string text1 = new string(text);
            this.label1.Text = text1;
            text1 = "";
            
            if (ostatnia_liczba)
            {
                if (!liczba1_zakonczona)
                {
                    char[] text2 = new char[liczba_string1.Length + 1];
                    for (int i = 0; i < liczba_string1.Length - 1; i++)
                    {
                        text2[i] = liczba_string1[i];
                    }
                    string text3 = new string(text2);
                    liczba_string1 = text3;
                    text3 = "";
                }
                else if (liczba2_rozpoczeta)
                {
                    char[] text4 = new char[liczba_string2.Length + 1];
                    for (int i = 0; i < liczba_string2.Length - 1; i++)
                    {
                        text4[i] = liczba_string2[i];
                    }
                    string text5 = new string(text4);
                    liczba_string2 = text5;
                    text5 = "";
                }
            }
            else
            {
                liczba1_zakonczona = false;
                dzialanie = ' ';
                ostatnia_liczba = true;
                dzialanie_zrobione = false;
            }
        }

        private void Form1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 48) //0
            {
                if (!dzialanie_zrobione)
                {
                    this.label1.Text = this.label1.Text + "0";
                    liczba_string1 = liczba_string1 + "0";
                    ostatnia_liczba = true;
                }
                else
                {
                    this.label1.Text = this.label1.Text + "0";
                    liczba_string2 = liczba_string2 + "0";
                    ostatnia_liczba = true;
                }
            }

            if (e.KeyChar == 49) //numer 1
            {
                if (!dzialanie_zrobione)
                {
                    this.label1.Text = this.label1.Text + "1";
                    liczba_string1 = liczba_string1 + "1";
                    ostatnia_liczba = true;
                }
                else
                {
                    this.label1.Text = this.label1.Text + "1";
                    liczba_string2 = liczba_string2 + "1";
                    ostatnia_liczba = true;
                    liczba2_rozpoczeta = true;
                }
            }

            if (e.KeyChar == 50) //2
            {
                if (!dzialanie_zrobione)
                {
                    this.label1.Text = this.label1.Text + "2";
                    liczba_string1 = liczba_string1 + "2";
                    ostatnia_liczba = true;
                }
                else
                {
                    this.label1.Text = this.label1.Text + "2";
                    liczba_string2 = liczba_string2 + "2";
                    ostatnia_liczba = true;
                    liczba2_rozpoczeta = true;
                }
            }

            if (e.KeyChar == 51) //3
            {
                if (!dzialanie_zrobione)
                {
                    this.label1.Text = this.label1.Text + "3";
                    liczba_string1 = liczba_string1 + "3";
                    ostatnia_liczba = true;
                }
                else
                {
                    this.label1.Text = this.label1.Text + "3";
                    liczba_string2 = liczba_string2 + "3";
                    ostatnia_liczba = true;
                    liczba2_rozpoczeta = true;
                }
            }

            if (e.KeyChar == 52) //4
            {
                if (!dzialanie_zrobione)
                {
                    this.label1.Text = this.label1.Text + "4";
                    liczba_string1 = liczba_string1 + "4";
                    ostatnia_liczba = true;
                }
                else
                {
                    this.label1.Text = this.label1.Text + "4";
                    liczba_string2 = liczba_string2 + "4";
                    ostatnia_liczba = true;
                    liczba2_rozpoczeta = true;
                }
            }

            if (e.KeyChar == 53) //5
            {
                if (!dzialanie_zrobione)
                {
                    this.label1.Text = this.label1.Text + "5";
                    liczba_string1 = liczba_string1 + "5";
                    ostatnia_liczba = true;
                }
                else
                {
                    this.label1.Text = this.label1.Text + "5";
                    liczba_string2 = liczba_string2 + "5";
                    ostatnia_liczba = true;
                    liczba2_rozpoczeta = true;
                }
            }

            if (e.KeyChar == 54) //6
            {
                if (!dzialanie_zrobione)
                {
                    this.label1.Text = this.label1.Text + "6";
                    liczba_string1 = liczba_string1 + "6";
                    ostatnia_liczba = true;
                }
                else
                {
                    this.label1.Text = this.label1.Text + "6";
                    liczba_string2 = liczba_string2 + "6";
                    ostatnia_liczba = true;
                    liczba2_rozpoczeta = true;
                }
            }

            if (e.KeyChar == 55) //7
            {
                if (!dzialanie_zrobione)
                {
                    this.label1.Text = this.label1.Text + "7";
                    liczba_string1 = liczba_string1 + "7";
                    ostatnia_liczba = true;
                }
                else
                {
                    this.label1.Text = this.label1.Text + "7";
                    liczba_string2 = liczba_string2 + "7";
                    ostatnia_liczba = true;
                    liczba2_rozpoczeta = true;
                }
            }

            if (e.KeyChar == 56) //8
            {
                if (!dzialanie_zrobione)
                {
                    this.label1.Text = this.label1.Text + "8";
                    liczba_string1 = liczba_string1 + "8";
                    ostatnia_liczba = true;
                }
                else
                {
                    this.label1.Text = this.label1.Text + "8";
                    liczba_string2 = liczba_string2 + "8";
                    ostatnia_liczba = true;
                    liczba2_rozpoczeta = true;
                }
            }

            if (e.KeyChar == 57) //9
            {
                if (!dzialanie_zrobione)
                {
                    this.label1.Text = this.label1.Text + "9";
                    liczba_string1 = liczba_string1 + "9";
                    ostatnia_liczba = true;
                }
                else
                {
                    this.label1.Text = this.label1.Text + "9";
                    liczba_string2 = liczba_string2 + "9";
                    ostatnia_liczba = true;
                    liczba2_rozpoczeta = true;
                }
            }

            if (e.KeyChar == '-') //-
            {
                if (ostatnia_liczba && !dzialanie_zrobione)
                {
                    liczba1_zakonczona = true;
                    dzialanie = '-';
                    ostatnia_liczba = false;
                    dzialanie_zrobione = true;
                    this.label1.Text = this.label1.Text + "-";
                    //liczba_string1 = liczba_string1 + "D";
                    liczba1 = Convert.ToDouble(liczba_string1);
                }
            } 

            if (e.KeyChar == '/') // przycisk /
            {
                if (ostatnia_liczba && !dzialanie_zrobione)
                {
                    liczba1_zakonczona = true;
                    dzialanie = '/';
                    ostatnia_liczba = false;
                    dzialanie_zrobione = true;
                    this.label1.Text = this.label1.Text + "/";
                    //liczba_string1 = liczba_string1 + "D";
                    liczba1 = Convert.ToDouble(liczba_string1);
                }
            }

            if (e.KeyChar == '+') // +
            {
                if (ostatnia_liczba && !dzialanie_zrobione)
                {
                    liczba1_zakonczona = true;
                    dzialanie = '+';
                    ostatnia_liczba = false;
                    dzialanie_zrobione = true;
                    this.label1.Text = this.label1.Text + "+";
                    //liczba_string1 = liczba_string1 + "D";
                    liczba1 = Convert.ToDouble(liczba_string1);
                }
            }

            if (e.KeyChar == 'x') //x
            {
                if (ostatnia_liczba && !dzialanie_zrobione)
                {
                    liczba1_zakonczona = true;
                    dzialanie = 'x';
                    ostatnia_liczba = false;
                    dzialanie_zrobione = true;
                    this.label1.Text = this.label1.Text + "X";
                    //liczba_string1 = liczba_string1 + "D";
                    liczba1 = Convert.ToDouble(liczba_string1);
                }
            }

            if (e.KeyChar == '.') //przycisk .
            {
                if (!dzialanie_zrobione)
                {
                    this.label1.Text = this.label1.Text + ",";
                    liczba_string1 = liczba_string1 + ",";
                    ostatnia_liczba = true;
                }
                else
                {
                    this.label1.Text = this.label1.Text + ",";
                    liczba_string2 = liczba_string2 + ",";
                    ostatnia_liczba = true;
                }
            }

            if (e.KeyChar == '=') //=
            {
                if (ostatnia_liczba && dzialanie_zrobione && liczba1_zakonczona)
                {
                    liczba2_zakonczona = true;
                    //liczba_string2 = liczba_string2 + "D";
                    liczba2 = Convert.ToDouble(liczba_string2);
                    switch (dzialanie)
                    {
                        case '+':
                            wynik = liczba1 + liczba2;
                            break;
                        case '-':
                            wynik = liczba1 - liczba2;
                            break;
                        case 'x':
                            wynik = liczba1 * liczba2;
                            break;
                        case '/':
                            wynik = liczba1 / liczba2;
                            break;
                    }
                    this.label1.Text = Convert.ToString(wynik);
                    liczba1 = wynik;
                    liczba_string1 = Convert.ToString(liczba1);
                    liczba2 = 0;
                    liczba_string2 = "";
                    ostatnia_liczba = true;
                    //liczba1_zakonczona = true;
                    liczba1_zakonczona = false;
                    dzialanie_zrobione = false;
                    liczba2_zakonczona = false;
                }
            }
        }

        private void button5_KeyPress(object sender, KeyPressEventArgs e)
        {
            /*if (e.KeyChar == 49) //numer 1
            {
                if (!dzialanie_zrobione)
                {
                    this.label1.Text = this.label1.Text + "1";
                    liczba_string1 = liczba_string1 + "1";
                    ostatnia_liczba = true;
                }
                else
                {
                    this.label1.Text = this.label1.Text + "1";
                    liczba_string2 = liczba_string2 + "1";
                    ostatnia_liczba = true;
                    liczba2_rozpoczeta = true;
                }
            }*/
        }

        private void cyfrowyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Cyfrowy = new Form2();
            this.Cyfrowy.Show();
        }

        private void analogowyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Analogowy = new Form3();
            this.Analogowy.Show();
        }
    }
}
