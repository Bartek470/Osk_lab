﻿
namespace Warcaby
{
    partial class Start
    {
        /// <summary>
        /// Wymagana zmienna projektanta.
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        public Form2 gra;
        public static string czas_rozgrywki;
        public static string kolor_gracza1;
        public static string kolor_gracza2;
        public static int czas_gracza1_minuty;
        public static int czas_gracza2_minuty;
        public static int czas_gracza1_sekundy;
        public static int czas_gracza2_sekundy;
        public static int dodanie_sekund;

        /// <summary>
        /// Wyczyść wszystkie używane zasoby.
        /// </summary>
        /// <param name="disposing">prawda, jeżeli zarządzane zasoby powinny zostać zlikwidowane; Fałsz w przeciwnym wypadku.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kod generowany przez Projektanta formularzy systemu Windows

        /// <summary>
        /// Metoda wymagana do obsługi projektanta — nie należy modyfikować
        /// jej zawartości w edytorze kodu.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.comboBoxczas = new System.Windows.Forms.ComboBox();
            this.comboBoxgracza1 = new System.Windows.Forms.ComboBox();
            this.comboBoxgracza2 = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label_kolorgracza1 = new System.Windows.Forms.Label();
            this.label_wyborgracza2 = new System.Windows.Forms.Label();
            this.label_wyborczasu = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Transparent;
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(200, 231);
            this.button1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(249, 117);
            this.button1.TabIndex = 1;
            this.button1.Text = "Rozpocznij grę";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // comboBoxczas
            // 
            this.comboBoxczas.FormattingEnabled = true;
            this.comboBoxczas.Items.AddRange(new object[] {
            "1 minuta",
            "3 minuty",
            "5 minut",
            "10 minut"});
            this.comboBoxczas.Location = new System.Drawing.Point(452, 585);
            this.comboBoxczas.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.comboBoxczas.Name = "comboBoxczas";
            this.comboBoxczas.Size = new System.Drawing.Size(180, 28);
            this.comboBoxczas.TabIndex = 3;
            this.comboBoxczas.Text = "Czas";
            // 
            // comboBoxgracza1
            // 
            this.comboBoxgracza1.FormattingEnabled = true;
            this.comboBoxgracza1.Items.AddRange(new object[] {
            "Czarny",
            "Biały",
            "Zielony",
            "Różowy",
            "Niebieski"});
            this.comboBoxgracza1.Location = new System.Drawing.Point(18, 585);
            this.comboBoxgracza1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.comboBoxgracza1.Name = "comboBoxgracza1";
            this.comboBoxgracza1.Size = new System.Drawing.Size(180, 28);
            this.comboBoxgracza1.TabIndex = 4;
            this.comboBoxgracza1.Text = "Kolor gracza 1";
            // 
            // comboBoxgracza2
            // 
            this.comboBoxgracza2.FormattingEnabled = true;
            this.comboBoxgracza2.Items.AddRange(new object[] {
            "Czarny",
            "Biały",
            "Zielony",
            "Różowy",
            "Niebieski"});
            this.comboBoxgracza2.Location = new System.Drawing.Point(236, 585);
            this.comboBoxgracza2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.comboBoxgracza2.Name = "comboBoxgracza2";
            this.comboBoxgracza2.Size = new System.Drawing.Size(180, 28);
            this.comboBoxgracza2.TabIndex = 5;
            this.comboBoxgracza2.Text = "Kolor gracza 2";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Comic Sans MS", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label1.Location = new System.Drawing.Point(213, 51);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(236, 67);
            this.label1.TabIndex = 9;
            this.label1.Text = "Warcaby";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_kolorgracza1
            // 
            this.label_kolorgracza1.AutoSize = true;
            this.label_kolorgracza1.BackColor = System.Drawing.Color.Transparent;
            this.label_kolorgracza1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label_kolorgracza1.Location = new System.Drawing.Point(18, 538);
            this.label_kolorgracza1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_kolorgracza1.MaximumSize = new System.Drawing.Size(180, 62);
            this.label_kolorgracza1.Name = "label_kolorgracza1";
            this.label_kolorgracza1.Size = new System.Drawing.Size(160, 40);
            this.label_kolorgracza1.TabIndex = 10;
            this.label_kolorgracza1.Text = "Wybierz kolor żetonu gracza 1:";
            // 
            // label_wyborgracza2
            // 
            this.label_wyborgracza2.AutoSize = true;
            this.label_wyborgracza2.BackColor = System.Drawing.Color.Transparent;
            this.label_wyborgracza2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label_wyborgracza2.Location = new System.Drawing.Point(236, 538);
            this.label_wyborgracza2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_wyborgracza2.MaximumSize = new System.Drawing.Size(180, 62);
            this.label_wyborgracza2.Name = "label_wyborgracza2";
            this.label_wyborgracza2.Size = new System.Drawing.Size(160, 40);
            this.label_wyborgracza2.TabIndex = 11;
            this.label_wyborgracza2.Text = "Wybierz kolor żetonu gracza 2:";
            // 
            // label_wyborczasu
            // 
            this.label_wyborczasu.AutoSize = true;
            this.label_wyborczasu.BackColor = System.Drawing.Color.Transparent;
            this.label_wyborczasu.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label_wyborczasu.Location = new System.Drawing.Point(452, 554);
            this.label_wyborczasu.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_wyborczasu.Name = "label_wyborczasu";
            this.label_wyborczasu.Size = new System.Drawing.Size(175, 20);
            this.label_wyborczasu.TabIndex = 12;
            this.label_wyborczasu.Text = "Wybierz czas rozgrywki:";
            // 
            // Start
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Warcaby.Properties.Resources.warcaby;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(651, 709);
            this.Controls.Add(this.label_wyborczasu);
            this.Controls.Add(this.label_wyborgracza2);
            this.Controls.Add(this.label_kolorgracza1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.comboBoxgracza2);
            this.Controls.Add(this.comboBoxgracza1);
            this.Controls.Add(this.comboBoxczas);
            this.Controls.Add(this.button1);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "Start";
            this.Text = "Start";
            this.Load += new System.EventHandler(this.Start_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ComboBox comboBoxczas;
        private System.Windows.Forms.ComboBox comboBoxgracza1;
        private System.Windows.Forms.ComboBox comboBoxgracza2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label_kolorgracza1;
        private System.Windows.Forms.Label label_wyborgracza2;
        private System.Windows.Forms.Label label_wyborczasu;
    }
}

