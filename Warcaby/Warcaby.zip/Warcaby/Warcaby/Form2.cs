﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Warcaby
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
            List<PictureBox> pictureBoxes = new List<PictureBox>(){ this.pictureBox1, this.pictureBox2, this.pictureBox3, this.pictureBox4, this.pictureBox5, this.pictureBox6, this.pictureBox7, this.pictureBox8, this.pictureBox9, this.pictureBox10, this.pictureBox11, this.pictureBox12,
                pictureBox13, this.pictureBox14, this.pictureBox15, this.pictureBox16, this.pictureBox17, this.pictureBox18, this.pictureBox19, this.pictureBox20, this.pictureBox21, this.pictureBox22, this.pictureBox23, this.pictureBox24,
                pictureBox25, this.pictureBox26, this.pictureBox27, this.pictureBox28, this.pictureBox29, this.pictureBox30, this.pictureBox31, this.pictureBox32, this.pictureBox33, this.pictureBox34, this.pictureBox35, this.pictureBox36,
                pictureBox37, this.pictureBox38, this.pictureBox39, this.pictureBox40, this.pictureBox41, this.pictureBox42, this.pictureBox43, this.pictureBox44, this.pictureBox45, this.pictureBox46, this.pictureBox47, this.pictureBox48,
                pictureBox49, this.pictureBox50, this.pictureBox51, this.pictureBox52, this.pictureBox53, this.pictureBox54, this.pictureBox55, this.pictureBox56, this.pictureBox57, this.pictureBox58, this.pictureBox59, this.pictureBox60,
                pictureBox61, this.pictureBox62, this.pictureBox63, this.pictureBox64};
            //PictureBox[] pictureBoxes = new PictureBox[64];
            this.label_wybrany_czas.Text += Start.czas_rozgrywki;
            this.label_kolor_gracza1.Text += Start.kolor_gracza1;
            this.label_kolor_grazca2.Text += Start.kolor_gracza2;
            if (Start.czas_gracza1_minuty < 10)
            {
                if (Start.czas_gracza1_sekundy >= 10) {
                    this.label_czas_gracza1.Text += "0" + Start.czas_gracza1_minuty.ToString() + ":" + Start.czas_gracza1_sekundy.ToString();
                }
                else
                {
                    this.label_czas_gracza1.Text += "0" + Start.czas_gracza1_minuty.ToString() + ":0" + Start.czas_gracza1_sekundy.ToString();
                }
            }
            else
            {
                if (Start.czas_gracza1_sekundy >= 10)
                {
                    this.label_czas_gracza1.Text += Start.czas_gracza1_minuty.ToString() + ":" + Start.czas_gracza1_sekundy.ToString();
                }
                else
                {
                    this.label_czas_gracza1.Text += Start.czas_gracza1_minuty.ToString() + ":0" + Start.czas_gracza1_sekundy.ToString();
                }
            }
            if (Start.czas_gracza2_minuty < 10)
            {
                if (Start.czas_gracza2_sekundy >= 10)
                {
                    this.label_czas_gracza2.Text += "0" + Start.czas_gracza2_minuty.ToString() + ":" + Start.czas_gracza2_sekundy.ToString();
                }
                else
                {
                    this.label_czas_gracza2.Text += "0" + Start.czas_gracza2_minuty.ToString() + ":0" + Start.czas_gracza2_sekundy.ToString();
                }
            }
            else
            {
                if (Start.czas_gracza2_sekundy >= 10)
                {
                    this.label_czas_gracza2.Text += Start.czas_gracza2_minuty.ToString() + ":" + Start.czas_gracza2_sekundy.ToString();
                }
                else
                {
                    this.label_czas_gracza2.Text += Start.czas_gracza2_minuty.ToString() + ":0" + Start.czas_gracza2_sekundy.ToString();
                }
            }
            RozstawZetony(Start.kolor_gracza1, Start.kolor_gracza2, pictureBoxes);
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            /*PictureBox[] pictureBoxes = new PictureBox[64];
            pictureBoxes = new PictureBox[] { this.pictureBox1, this.pictureBox2, this.pictureBox3, this.pictureBox4, this.pictureBox5, this.pictureBox6, this.pictureBox7, this.pictureBox8, this.pictureBox9, this.pictureBox10, this.pictureBox11, this.pictureBox12,
                pictureBox13, this.pictureBox14, this.pictureBox15, this.pictureBox16, this.pictureBox17, this.pictureBox18, this.pictureBox19, this.pictureBox20, this.pictureBox21, this.pictureBox22, this.pictureBox23, this.pictureBox24,
                pictureBox25, this.pictureBox26, this.pictureBox27, this.pictureBox28, this.pictureBox29, this.pictureBox30, this.pictureBox31, this.pictureBox32, this.pictureBox33, this.pictureBox34, this.pictureBox35, this.pictureBox36,
                pictureBox37, this.pictureBox38, this.pictureBox39, this.pictureBox40, this.pictureBox41, this.pictureBox42, this.pictureBox43, this.pictureBox44, this.pictureBox45, this.pictureBox46, this.pictureBox47, this.pictureBox48,
                pictureBox49, this.pictureBox50, this.pictureBox51, this.pictureBox52, this.pictureBox53, this.pictureBox54, this.pictureBox55, this.pictureBox56, this.pictureBox57, this.pictureBox58, this.pictureBox59, this.pictureBox60,
                pictureBox61, this.pictureBox62, this.pictureBox63, this.pictureBox64};
            int pozycja_x = 0;
            int pozycja_y = 0;
            int indeks_x = 0;
            int indeks_y = 0;
            for (int i = 0; i < pictureBoxes.Count; i++)
            {
                pozycja_x = i % 8;
                indeks_x = pozycja_x;
                pozycja_x = 37 + 80 * pozycja_x;
                pozycja_y = i / 8;
                indeks_y = pozycja_y;
                pozycja_y = 28 + 80 * pozycja_y;
                pictureBoxes[i].Location = new Point(pozycja_x, pozycja_y);
                if ((indeks_x + indeks_y) % 2 == 0)
                {
                    this.pictureBoxes[i].Load("C:/Users/Wojtek/Downloads/bialy_kolor_planszy.png");
                }
                else if ((indeks_x + indeks_y) % 2 == 1)
                {
                    this.pictureBoxes[i].Load("C:/Users/Wojtek/Downloads/czarny_kolor_planszy.png");
                }
            }*/
            //this.label_wybrany_czas.Text += Start.czas_rozgrywki;
            //this.BackgroundImage = Properties.Resources.warcaby;
            //this.pictureBox1.Load("Warcaby/Resources/rozowy_zeton.png");
            //this.pictureBox1.BackgroundImage = Properties.Resources.bialy_kolor_planszy;
            //this.pictureBox1.Image = Properties.Resources.rozowy_zeton;
        }

        private void pictureBox40_Click(object sender, EventArgs e)
        {

        }

        private void RozstawZetony(String kolor_gracza1, String kolor_gracza2, List<PictureBox> pictureBoxes)
        {
            int indeks_x = 0;
            int indeks_y = 0;
            switch (kolor_gracza1)
            {
                case "Czarny":
                    for (int i = 0; i < pictureBoxes.Count; i++)
                    {
                        indeks_x = i % 8;
                        indeks_y = i / 8;
                        if ((indeks_x + indeks_y) % 2 == 1 && indeks_y <= 2)
                        {
                            pictureBoxes[i].Image = Properties.Resources.czarny_zeton;
                        }
                    }
                    break;
                case "Różowy":
                    for (int i = 0; i < pictureBoxes.Count; i++)
                    {
                        indeks_x = i % 8;
                        indeks_y = i / 8;
                        if ((indeks_x + indeks_y) % 2 == 1 && indeks_y <= 2)
                        {
                            pictureBoxes[i].Image = Properties.Resources.rozowy_zeton;
                        }
                    }
                    break;
                case "Zielony":
                    for (int i = 0; i < pictureBoxes.Count; i++)
                    {
                        indeks_x = i % 8;
                        indeks_y = i / 8;
                        if ((indeks_x + indeks_y) % 2 == 1 && indeks_y <= 2)
                        {
                            pictureBoxes[i].Image = Properties.Resources.zielony_zeton;
                        }
                    }
                    break;
                case "Biały":
                    for (int i = 0; i < pictureBoxes.Count; i++)
                    {
                        indeks_x = i % 8;
                        indeks_y = i / 8;
                        if ((indeks_x + indeks_y) % 2 == 1 && indeks_y <= 2)
                        {
                            pictureBoxes[i].Image = Properties.Resources.bialy_zeton;
                        }
                    }
                    break;
                case "Niebieski":
                    for (int i = 0; i < pictureBoxes.Count; i++)
                    {
                        indeks_x = i % 8;
                        indeks_y = i / 8;
                        if ((indeks_x + indeks_y) % 2 == 1 && indeks_y <= 2)
                        {
                            pictureBoxes[i].Image = Properties.Resources.niebieski_zeton;
                        }
                    }
                    break;
            }
            switch (kolor_gracza2)
            {
                case "Czarny":
                    for (int i = 0; i < pictureBoxes.Count; i++)
                    {
                        indeks_x = i % 8;
                        indeks_y = i / 8;
                        if ((indeks_x + indeks_y) % 2 == 1 && indeks_y >= 5)
                        {
                            pictureBoxes[i].Image = Properties.Resources.czarny_zeton;
                        }
                    }
                    break;
                case "Różowy":
                    for (int i = 0; i < pictureBoxes.Count; i++)
                    {
                        indeks_x = i % 8;
                        indeks_y = i / 8;
                        if ((indeks_x + indeks_y) % 2 == 1 && indeks_y >= 5)
                        {
                            pictureBoxes[i].Image = Properties.Resources.rozowy_zeton;
                        }
                    }
                    break;
                case "Zielony":
                    for (int i = 0; i < pictureBoxes.Count; i++)
                    {
                        indeks_x = i % 8;
                        indeks_y = i / 8;
                        if ((indeks_x + indeks_y) % 2 == 1 && indeks_y >= 5)
                        {
                            pictureBoxes[i].Image = Properties.Resources.zielony_zeton;
                        }
                    }
                    break;
                case "Biały":
                    for (int i = 0; i < pictureBoxes.Count; i++)
                    {
                        indeks_x = i % 8;
                        indeks_y = i / 8;
                        if ((indeks_x + indeks_y) % 2 == 1 && indeks_y >= 5)
                        {
                            pictureBoxes[i].Image = Properties.Resources.bialy_zeton;
                        }
                    }
                    break;
                case "Niebieski":
                    for (int i = 0; i < pictureBoxes.Count; i++)
                    {
                        indeks_x = i % 8;
                        indeks_y = i / 8;
                        if ((indeks_x + indeks_y) % 2 == 1 && indeks_y >= 5)
                        {
                            pictureBoxes[i].Image = Properties.Resources.niebieski_zeton;
                        }
                    }
                    break;
            }
        }
    }
}
