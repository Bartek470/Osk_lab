﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sym_mikroprocesora5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            ax_rejestr = "00000000 00000000";
            al_rejestr = "00000000";
            ah_rejestr = "00000000";
            bx_rejestr = "00000000 00000000";
            bl_rejestr = "00000000";
            bh_rejestr = "00000000";
            cx_rejestr = "00000000 00000000";
            cl_rejestr = "00000000";
            ch_rejestr = "00000000";
            dx_rejestr = "00000000 00000000";
            dl_rejestr = "00000000";
            dh_rejestr = "00000000";
            in_rejestr = "00000000 00000000";
            inl_rejestr = "00000000";
            inh_rejestr = "00000000";
            InitializeComponent();
        }

        private void radio_ax_click(object sender, EventArgs e)
        {
            string ax = "";
            if (this.radioButton_ax_15_1.Checked == true)
            {
                ax += "1";
            }
            else ax += "0";
            if (this.radioButton_ax_14_1.Checked == true)
            {
                ax += "1";
            }
            else ax += "0";
            if (this.radioButton_ax_13_1.Checked == true)
            {
                ax += "1";
            }
            else ax += "0";
            if (this.radioButton_ax_12_1.Checked == true)
            {
                ax += "1";
            }
            else ax += "0";
            if (this.radioButton_ax_11_1.Checked == true)
            {
                ax += "1";
            }
            else ax += "0";
            if (this.radioButton_ax_10_1.Checked == true)
            {
                ax += "1";
            }
            else ax += "0";
            if (this.radioButton_ax_9_1.Checked == true)
            {
                ax += "1";
            }
            else ax += "0";
            if (this.radioButton_ax_8_1.Checked == true)
            {
                ax += "1";
            }
            else ax += "0";

            //ax += " ";

            if (this.radioButton_ax_7_1.Checked == true)
            {
                ax += "1";
            }
            else ax += "0";
            if (this.radioButton_ax_6_1.Checked == true)
            {
                ax += "1";
            }
            else ax += "0";
            if (this.radioButton_ax_5_1.Checked == true)
            {
                ax += "1";
            }
            else ax += "0";
            if (this.radioButton_ax_4_1.Checked == true)
            {
                ax += "1";
            }
            else ax += "0";
            if (this.radioButton_ax_3_1.Checked == true)
            {
                ax += "1";
            }
            else ax += "0";
            if (this.radioButton_ax_2_1.Checked == true)
            {
                ax += "1";
            }
            else ax += "0";
            if (this.radioButton_ax_1_1.Checked == true)
            {
                ax += "1";
            }
            else ax += "0";
            if (this.radioButton_ax_0_1.Checked == true)
            {
                ax += "1";
            }
            else ax += "0";
            this.label_ax.Text = ax;
        }

        private void button_ax_Click(object sender, EventArgs e)
        {
            ax_rejestr = this.label_ax.Text;
            //this.label_ax_wartosc.Text = this.label_ax.Text;
            rozdziel_rejestr(ax_rejestr, ref ah_rejestr, ref al_rejestr);
            this.label_ah_wartosc.Text = ah_rejestr;
            this.label_al_wartosc.Text = al_rejestr;
        }

        private void radio_bx_click(object sender, EventArgs e)
        {
            string bx = "";
            if (this.radioButton_bx_15_1.Checked == true)
            {
                bx += "1";
            }
            else bx += "0";
            if (this.radioButton_bx_14_1.Checked == true)
            {
                bx += "1";
            }
            else bx += "0";
            if (this.radioButton_bx_13_1.Checked == true)
            {
                bx += "1";
            }
            else bx += "0";
            if (this.radioButton_bx_12_1.Checked == true)
            {
                bx += "1";
            }
            else bx += "0";
            if (this.radioButton_bx_11_1.Checked == true)
            {
                bx += "1";
            }
            else bx += "0";
            if (this.radioButton_bx_10_1.Checked == true)
            {
                bx += "1";
            }
            else bx += "0";
            if (this.radioButton_bx_9_1.Checked == true)
            {
                bx += "1";
            }
            else bx += "0";
            if (this.radioButton_bx_8_1.Checked == true)
            {
                bx += "1";
            }
            else bx += "0";

            //bx += " ";

            if (this.radioButton_bx_7_1.Checked == true)
            {
                bx += "1";
            }
            else bx += "0";
            if (this.radioButton_bx_6_1.Checked == true)
            {
                bx += "1";
            }
            else bx += "0";
            if (this.radioButton_bx_5_1.Checked == true)
            {
                bx += "1";
            }
            else bx += "0";
            if (this.radioButton_bx_4_1.Checked == true)
            {
                bx += "1";
            }
            else bx += "0";
            if (this.radioButton_bx_3_1.Checked == true)
            {
                bx += "1";
            }
            else bx += "0";
            if (this.radioButton_bx_2_1.Checked == true)
            {
                bx += "1";
            }
            else bx += "0";
            if (this.radioButton_bx_1_1.Checked == true)
            {
                bx += "1";
            }
            else bx += "0";
            if (this.radioButton_bx_0_1.Checked == true)
            {
                bx += "1";
            }
            else bx += "0";
            this.label_bx.Text = bx;
        }

        private void button_bx_Click(object sender, EventArgs e)
        {
            bx_rejestr = this.label_bx.Text;
            //this.label_bx_wartosc.Text = this.label_bx.Text;
            rozdziel_rejestr(bx_rejestr, ref bh_rejestr, ref bl_rejestr);
            this.label_bh_wartosc.Text = bh_rejestr;
            this.label_bl_wartosc.Text = bl_rejestr;
        }

        private void radio_cx_click(object sender, EventArgs e)
        {
            string cx = "";
            if (this.radioButton_cx_15_1.Checked == true)
            {
                cx += "1";
            }
            else cx += "0";
            if (this.radioButton_cx_14_1.Checked == true)
            {
                cx += "1";
            }
            else cx += "0";
            if (this.radioButton_cx_13_1.Checked == true)
            {
                cx += "1";
            }
            else cx += "0";
            if (this.radioButton_cx_12_1.Checked == true)
            {
                cx += "1";
            }
            else cx += "0";
            if (this.radioButton_cx_11_1.Checked == true)
            {
                cx += "1";
            }
            else cx += "0";
            if (this.radioButton_cx_10_1.Checked == true)
            {
                cx += "1";
            }
            else cx += "0";
            if (this.radioButton_cx_9_1.Checked == true)
            {
                cx += "1";
            }
            else cx += "0";
            if (this.radioButton_cx_8_1.Checked == true)
            {
                cx += "1";
            }
            else cx += "0";

            //cx += " ";

            if (this.radioButton_cx_7_1.Checked == true)
            {
                cx += "1";
            }
            else cx += "0";
            if (this.radioButton_cx_6_1.Checked == true)
            {
                cx += "1";
            }
            else cx += "0";
            if (this.radioButton_cx_5_1.Checked == true)
            {
                cx += "1";
            }
            else cx += "0";
            if (this.radioButton_cx_4_1.Checked == true)
            {
                cx += "1";
            }
            else cx += "0";
            if (this.radioButton_cx_3_1.Checked == true)
            {
                cx += "1";
            }
            else cx += "0";
            if (this.radioButton_cx_2_1.Checked == true)
            {
                cx += "1";
            }
            else cx += "0";
            if (this.radioButton_cx_1_1.Checked == true)
            {
                cx += "1";
            }
            else cx += "0";
            if (this.radioButton_cx_0_1.Checked == true)
            {
                cx += "1";
            }
            else cx += "0";
            this.label_cx.Text = cx;
        }

        private void button_cx_Click(object sender, EventArgs e)
        {
            cx_rejestr = this.label_cx.Text;
            //this.label_cx_wartosc.Text = this.label_cx.Text;
            rozdziel_rejestr(cx_rejestr, ref ch_rejestr, ref cl_rejestr);
            this.label_ch_wartosc.Text = ch_rejestr;
            this.label_cl_wartosc.Text = cl_rejestr;
        }

        private void radio_dx_click(object sender, EventArgs e)
        {
            string dx = "";
            if (this.radioButton_dx_15_1.Checked == true)
            {
                dx += "1";
            }
            else dx += "0";
            if (this.radioButton_dx_14_1.Checked == true)
            {
                dx += "1";
            }
            else dx += "0";
            if (this.radioButton_dx_13_1.Checked == true)
            {
                dx += "1";
            }
            else dx += "0";
            if (this.radioButton_dx_12_1.Checked == true)
            {
                dx += "1";
            }
            else dx += "0";
            if (this.radioButton_dx_11_1.Checked == true)
            {
                dx += "1";
            }
            else dx += "0";
            if (this.radioButton_dx_10_1.Checked == true)
            {
                dx += "1";
            }
            else dx += "0";
            if (this.radioButton_dx_9_1.Checked == true)
            {
                dx += "1";
            }
            else dx += "0";
            if (this.radioButton_dx_8_1.Checked == true)
            {
                dx += "1";
            }
            else dx += "0";

            //dx += " ";

            if (this.radioButton_dx_7_1.Checked == true)
            {
                dx += "1";
            }
            else dx += "0";
            if (this.radioButton_dx_6_1.Checked == true)
            {
                dx += "1";
            }
            else dx += "0";
            if (this.radioButton_dx_5_1.Checked == true)
            {
                dx += "1";
            }
            else dx += "0";
            if (this.radioButton_dx_4_1.Checked == true)
            {
                dx += "1";
            }
            else dx += "0";
            if (this.radioButton_dx_3_1.Checked == true)
            {
                dx += "1";
            }
            else dx += "0";
            if (this.radioButton_dx_2_1.Checked == true)
            {
                dx += "1";
            }
            else dx += "0";
            if (this.radioButton_dx_1_1.Checked == true)
            {
                dx += "1";
            }
            else dx += "0";
            if (this.radioButton_dx_0_1.Checked == true)
            {
                dx += "1";
            }
            else dx += "0";
            this.label_dx.Text = dx;
        }

        private void button_dx_Click(object sender, EventArgs e)
        {
            dx_rejestr = this.label_dx.Text;
            //this.label_dx_wartosc.Text = this.label_dx.Text;
            rozdziel_rejestr(dx_rejestr, ref dh_rejestr, ref dl_rejestr);
            this.label_dh_wartosc.Text = dh_rejestr;
            this.label_dl_wartosc.Text = dl_rejestr;
        }

        private void radio_in_click(object sender, EventArgs e)
        {
            string in_ = "";
            if (this.radioButton_in_15_1.Checked == true)
            {
                in_ += "1";
            }
            else in_ += "0";
            if (this.radioButton_in_14_1.Checked == true)
            {
                in_ += "1";
            }
            else in_ += "0";
            if (this.radioButton_in_13_1.Checked == true)
            {
                in_ += "1";
            }
            else in_ += "0";
            if (this.radioButton_in_12_1.Checked == true)
            {
                in_ += "1";
            }
            else in_ += "0";
            if (this.radioButton_in_11_1.Checked == true)
            {
                in_ += "1";
            }
            else in_ += "0";
            if (this.radioButton_in_10_1.Checked == true)
            {
                in_ += "1";
            }
            else in_ += "0";
            if (this.radioButton_in_9_1.Checked == true)
            {
                in_ += "1";
            }
            else in_ += "0";
            if (this.radioButton_in_8_1.Checked == true)
            {
                in_ += "1";
            }
            else in_ += "0";

            //in_ += " ";

            if (this.radioButton_in_7_1.Checked == true)
            {
                in_ += "1";
            }
            else in_ += "0";
            if (this.radioButton_in_6_1.Checked == true)
            {
                in_ += "1";
            }
            else in_ += "0";
            if (this.radioButton_in_5_1.Checked == true)
            {
                in_ += "1";
            }
            else in_ += "0";
            if (this.radioButton_in_4_1.Checked == true)
            {
                in_ += "1";
            }
            else in_ += "0";
            if (this.radioButton_in_3_1.Checked == true)
            {
                in_ += "1";
            }
            else in_ += "0";
            if (this.radioButton_in_2_1.Checked == true)
            {
                in_ += "1";
            }
            else in_ += "0";
            if (this.radioButton_in_1_1.Checked == true)
            {
                in_ += "1";
            }
            else in_ += "0";
            if (this.radioButton_in_0_1.Checked == true)
            {
                in_ += "1";
            }
            else in_ += "0";
            //this.label_in.Text = in_;

            in_rejestr = in_;
            //this.label_dx_wartosc.Text = this.label_dx.Text;
            rozdziel_rejestr(in_rejestr, ref inh_rejestr, ref inl_rejestr);
            this.label_inh_wartosc.Text = inh_rejestr;
            this.label_inl_wartosc.Text = inl_rejestr;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string instrukcja = "";
            string arg1 = "";
            string arg2 = "";
            if (this.comboBox_instrukcja.Text != "Instrukcja" && this.comboBox_arg1.Text != "1. argument" && this.comboBox_arg2.Text != "2. argument")
            {
                if (this.comboBox_arg2.Text != "Argument natychmiastowy")
                {
                    if ((this.comboBox_arg1.Text[1] == this.comboBox_arg2.Text[1]) || (this.comboBox_arg1.Text[1] == 'L' && this.comboBox_arg2.Text[1] == 'H') || (this.comboBox_arg1.Text[1] == 'H' && this.comboBox_arg2.Text[1] == 'L'))
                    {
                        instrukcja = this.comboBox_instrukcja.Text;
                        arg1 = this.comboBox_arg1.Text;
                        arg2 = this.comboBox_arg2.Text;
                        if (instrukcja == "MOV")
                        {
                            mov(arg1, arg2);
                        }
                        else if (instrukcja == "ADD")
                        {
                            add(arg1, arg2);
                        }
                        else if (instrukcja == "SUB")
                        {
                            sub(arg1, arg2);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Rozmiary rejestrów są niezgodne");
                    }
                }
                else if (this.comboBox_arg2.Text == "Argument natychmiastowy")
                {
                    instrukcja = this.comboBox_instrukcja.Text;
                    arg1 = this.comboBox_arg1.Text;
                    arg2 = this.comboBox_arg2.Text;
                    if (instrukcja == "MOV")
                    {
                        mov(arg1, arg2);
                    }
                    else if (instrukcja == "ADD")
                    {
                        add(arg1, arg2);
                    }
                    else if (instrukcja == "SUB")
                    {
                        sub(arg1, arg2);
                    }
                }
            }
            else
            {
                MessageBox.Show("Niepełna instrukcja");
            }
        }

        private void mov(string arg1, string arg2)
        {
            string rejestr = "";
            switch (arg2)
            {
                case "AX":
                    rejestr = ax_rejestr;
                    break;
                case "AL":
                    rejestr = al_rejestr;
                    break;
                case "AH":
                    rejestr = ah_rejestr;
                    break;
                case "BX":
                    rejestr = bx_rejestr;
                    break;
                case "BL":
                    rejestr = bl_rejestr;
                    break;
                case "BH":
                    rejestr = bh_rejestr;
                    break;
                case "CX":
                    rejestr = cx_rejestr;
                    break;
                case "CL":
                    rejestr = cl_rejestr;
                    break;
                case "CH":
                    rejestr = ch_rejestr;
                    break;
                case "DX":
                    rejestr = dx_rejestr;
                    break;
                case "DL":
                    rejestr = dl_rejestr;
                    break;
                case "DH":
                    rejestr = dh_rejestr;
                    break;
                case "Argument natychmiastowy":
                    if (arg1[1] == 'L' || arg1[1] == 'H')
                    {
                        rejestr = inl_rejestr;
                    }
                    else if (arg1[1] == 'X')
                    {
                        rejestr = in_rejestr;
                    }
                    break;
                default:
                    break;
            }
            switch (arg1)
            {
                case "AX":
                    ax_rejestr = rejestr;
                    this.label_ax.Text = ax_rejestr;
                    rozdziel_rejestr(ax_rejestr, ref ah_rejestr, ref al_rejestr);
                    this.label_ah_wartosc.Text = ah_rejestr;
                    this.label_al_wartosc.Text = al_rejestr;
                    break;
                case "AL":
                    al_rejestr = rejestr;
                    this.label_al_wartosc.Text = al_rejestr;
                    break;
                case "AH":
                    ah_rejestr = rejestr;
                    this.label_ah_wartosc.Text = ah_rejestr;
                    break;
                case "BX":
                    bx_rejestr = rejestr;
                    this.label_bx.Text = bx_rejestr;
                    rozdziel_rejestr(bx_rejestr, ref bh_rejestr, ref bl_rejestr);
                    this.label_bh_wartosc.Text = bh_rejestr;
                    this.label_bl_wartosc.Text = bl_rejestr;
                    break;
                case "BL":
                    bl_rejestr = rejestr;
                    this.label_bl_wartosc.Text = bl_rejestr;
                    break;
                case "BH":
                    bh_rejestr = rejestr;
                    this.label_bh_wartosc.Text = bh_rejestr;
                    break;
                case "CX":
                    cx_rejestr = rejestr;
                    this.label_cx.Text = cx_rejestr;
                    rozdziel_rejestr(cx_rejestr, ref ch_rejestr, ref cl_rejestr);
                    this.label_ch_wartosc.Text = ch_rejestr;
                    this.label_cl_wartosc.Text = cl_rejestr;
                    break;
                case "CL":
                    cl_rejestr = rejestr;
                    this.label_cl_wartosc.Text = cl_rejestr;
                    break;
                case "CH":
                    ch_rejestr = rejestr;
                    this.label_ch_wartosc.Text = ch_rejestr;
                    break;
                case "DX":
                    dx_rejestr = rejestr;
                    this.label_dx.Text = dx_rejestr;
                    rozdziel_rejestr(dx_rejestr, ref dh_rejestr, ref dl_rejestr);
                    this.label_dh_wartosc.Text = dh_rejestr;
                    this.label_dl_wartosc.Text = dl_rejestr;
                    break;
                case "DL":
                    dl_rejestr = rejestr;
                    this.label_dl_wartosc.Text = dl_rejestr;
                    break;
                case "DH":
                    dh_rejestr = rejestr;
                    this.label_dh_wartosc.Text = dh_rejestr;
                    break;
                default:
                    break;
            }
        }

        private void rozdziel_rejestr(string x_rejestr, ref string h_rejestr, ref string l_rejestr)
        {
            h_rejestr = "";
            l_rejestr = "";
            for (int i = 0; i < 8; i++)
            {
                h_rejestr += x_rejestr[i];
                l_rejestr += x_rejestr[i + 8];
            }
        }

        private void add(string arg1, string arg2)
        {
            int liczba1 = 0;
            int liczba2 = 0;
            int wynik = 0;
            string wynik_bit = "";
            switch (arg2)
            {
                case "AX":
                    liczba2 = zamien_na_int(ax_rejestr);
                    break;
                case "AH":
                    liczba2 = zamien_na_int(ah_rejestr);
                    break;
                case "AL":
                    liczba2 = zamien_na_int(al_rejestr);
                    break;
                case "BX":
                    liczba2 = zamien_na_int(bx_rejestr);
                    break;
                case "BH":
                    liczba2 = zamien_na_int(bh_rejestr);
                    break;
                case "BL":
                    liczba2 = zamien_na_int(bl_rejestr);
                    break;
                case "CX":
                    liczba2 = zamien_na_int(cx_rejestr);
                    break;
                case "CH":
                    liczba2 = zamien_na_int(ch_rejestr);
                    break;
                case "CL":
                    liczba2 = zamien_na_int(cl_rejestr);
                    break;
                case "DX":
                    liczba2 = zamien_na_int(dx_rejestr);
                    break;
                case "DH":
                    liczba2 = zamien_na_int(dh_rejestr);
                    break;
                case "DL":
                    liczba2 = zamien_na_int(dl_rejestr);
                    break;
                case "Argument natychmiastowy":
                    if (arg1[1] == 'L' || arg1[1] == 'H')
                    {
                        liczba2 = zamien_na_int(inl_rejestr);
                    }
                    else if (arg1[1] == 'X')
                    {
                        liczba2 = zamien_na_int(in_rejestr);
                    }
                    break;
            }
            switch (arg1)
            {
                case "AX":
                    liczba1 = zamien_na_int(ax_rejestr);
                    wynik = liczba1 + liczba2;
                    wynik_bit = zamien_na_bit(wynik, 16);
                    ax_rejestr = wynik_bit;
                    this.label_ax.Text = ax_rejestr;
                    rozdziel_rejestr(ax_rejestr, ref ah_rejestr, ref al_rejestr);
                    this.label_ah_wartosc.Text = ah_rejestr;
                    this.label_al_wartosc.Text = al_rejestr;
                    break;
                case "AH":
                    liczba1 = zamien_na_int(ah_rejestr);
                    wynik = liczba1 + liczba2;
                    wynik_bit = zamien_na_bit(wynik, 8);
                    ah_rejestr = wynik_bit;
                    this.label_ah_wartosc.Text = ah_rejestr;
                    break;
                case "AL":
                    liczba1 = zamien_na_int(al_rejestr);
                    wynik = liczba1 + liczba2;
                    wynik_bit = zamien_na_bit(wynik, 8);
                    al_rejestr = wynik_bit;
                    this.label_al_wartosc.Text = al_rejestr;
                    break;
                case "BX":
                    liczba1 = zamien_na_int(bx_rejestr);
                    wynik = liczba1 + liczba2;
                    wynik_bit = zamien_na_bit(wynik, 16);
                    bx_rejestr = wynik_bit;
                    this.label_bx.Text = bx_rejestr;
                    rozdziel_rejestr(bx_rejestr, ref bh_rejestr, ref bl_rejestr);
                    this.label_bh_wartosc.Text = bh_rejestr;
                    this.label_bl_wartosc.Text = bl_rejestr;
                    break;
                case "BH":
                    liczba1 = zamien_na_int(bh_rejestr);
                    wynik = liczba1 + liczba2;
                    wynik_bit = zamien_na_bit(wynik, 8);
                    bh_rejestr = wynik_bit;
                    this.label_bh_wartosc.Text = bh_rejestr;
                    break;
                case "BL":
                    liczba1 = zamien_na_int(bl_rejestr);
                    wynik = liczba1 + liczba2;
                    wynik_bit = zamien_na_bit(wynik, 8);
                    bl_rejestr = wynik_bit;
                    this.label_bl_wartosc.Text = bl_rejestr;
                    break;
                case "CX":
                    liczba1 = zamien_na_int(cx_rejestr);
                    wynik = liczba1 + liczba2;
                    wynik_bit = zamien_na_bit(wynik, 16);
                    cx_rejestr = wynik_bit;
                    this.label_cx.Text = cx_rejestr;
                    rozdziel_rejestr(cx_rejestr, ref ch_rejestr, ref cl_rejestr);
                    this.label_ch_wartosc.Text = ch_rejestr;
                    this.label_cl_wartosc.Text = cl_rejestr;
                    break;
                case "CH":
                    liczba1 = zamien_na_int(ch_rejestr);
                    wynik = liczba1 + liczba2;
                    wynik_bit = zamien_na_bit(wynik, 8);
                    ch_rejestr = wynik_bit;
                    this.label_ch_wartosc.Text = ch_rejestr;
                    break;
                case "CL":
                    liczba1 = zamien_na_int(cl_rejestr);
                    wynik = liczba1 + liczba2;
                    wynik_bit = zamien_na_bit(wynik, 8);
                    cl_rejestr = wynik_bit;
                    this.label_cl_wartosc.Text = cl_rejestr;
                    break;
                case "DX":
                    liczba1 = zamien_na_int(dx_rejestr);
                    wynik = liczba1 + liczba2;
                    wynik_bit = zamien_na_bit(wynik, 16);
                    dx_rejestr = wynik_bit;
                    this.label_dx.Text = dx_rejestr;
                    rozdziel_rejestr(dx_rejestr, ref dh_rejestr, ref dl_rejestr);
                    this.label_dh_wartosc.Text = dh_rejestr;
                    this.label_dl_wartosc.Text = dl_rejestr;
                    break;
                case "DH":
                    liczba1 = zamien_na_int(dh_rejestr);
                    wynik = liczba1 + liczba2;
                    wynik_bit = zamien_na_bit(wynik, 8);
                    dh_rejestr = wynik_bit;
                    this.label_dh_wartosc.Text = dh_rejestr;
                    break;
                case "DL":
                    liczba1 = zamien_na_int(dl_rejestr);
                    wynik = liczba1 + liczba2;
                    wynik_bit = zamien_na_bit(wynik, 8);
                    dl_rejestr = wynik_bit;
                    this.label_dl_wartosc.Text = bl_rejestr;
                    break;
                default:
                    break;
            }
        }

        private void sub(string arg1, string arg2)
        {
            int liczba1 = 0;
            int liczba2 = 0;
            int wynik = 0;
            string wynik_bit = "";
            switch (arg2)
            {
                case "AX":
                    liczba2 = zamien_na_int(ax_rejestr);
                    break;
                case "AH":
                    liczba2 = zamien_na_int(ah_rejestr);
                    break;
                case "AL":
                    liczba2 = zamien_na_int(al_rejestr);
                    break;
                case "BX":
                    liczba2 = zamien_na_int(bx_rejestr);
                    break;
                case "BH":
                    liczba2 = zamien_na_int(bh_rejestr);
                    break;
                case "BL":
                    liczba2 = zamien_na_int(bl_rejestr);
                    break;
                case "CX":
                    liczba2 = zamien_na_int(cx_rejestr);
                    break;
                case "CH":
                    liczba2 = zamien_na_int(ch_rejestr);
                    break;
                case "CL":
                    liczba2 = zamien_na_int(cl_rejestr);
                    break;
                case "DX":
                    liczba2 = zamien_na_int(dx_rejestr);
                    break;
                case "DH":
                    liczba2 = zamien_na_int(dh_rejestr);
                    break;
                case "DL":
                    liczba2 = zamien_na_int(dl_rejestr);
                    break;
                case "Argument natychmiastowy":
                    if (arg1[1] == 'L' || arg1[1] == 'H')
                    {
                        liczba2 = zamien_na_int(inl_rejestr);
                    }
                    else if (arg1[1] == 'X')
                    {
                        liczba2 = zamien_na_int(in_rejestr);
                    }
                    break;
                default:
                    break;
            }
            switch (arg1)
            {
                case "AX":
                    liczba1 = zamien_na_int(ax_rejestr);
                    if (liczba1 >= liczba2)
                    {
                        wynik = liczba1 - liczba2;
                    }
                    else wynik = liczba2 - liczba1;
                    wynik_bit = zamien_na_bit(wynik, 16);
                    ax_rejestr = wynik_bit;
                    this.label_ax.Text = ax_rejestr;
                    rozdziel_rejestr(ax_rejestr, ref ah_rejestr, ref al_rejestr);
                    this.label_ah_wartosc.Text = ah_rejestr;
                    this.label_al_wartosc.Text = al_rejestr;
                    break;
                case "AH":
                    liczba1 = zamien_na_int(ah_rejestr);
                    if (liczba1 >= liczba2)
                    {
                        wynik = liczba1 - liczba2;
                    }
                    else wynik = liczba2 - liczba1;
                    wynik_bit = zamien_na_bit(wynik, 8);
                    ah_rejestr = wynik_bit;
                    this.label_ah_wartosc.Text = ah_rejestr;
                    break;
                case "AL":
                    liczba1 = zamien_na_int(al_rejestr);
                    if (liczba1 >= liczba2)
                    {
                        wynik = liczba1 - liczba2;
                    }
                    else wynik = liczba2 - liczba1;
                    wynik_bit = zamien_na_bit(wynik, 8);
                    al_rejestr = wynik_bit;
                    this.label_al_wartosc.Text = al_rejestr;
                    break;
                case "BX":
                    liczba1 = zamien_na_int(bx_rejestr);
                    if (liczba1 >= liczba2)
                    {
                        wynik = liczba1 - liczba2;
                    }
                    else wynik = liczba2 - liczba1;
                    wynik_bit = zamien_na_bit(wynik, 16);
                    bx_rejestr = wynik_bit;
                    this.label_bx.Text = bx_rejestr;
                    rozdziel_rejestr(bx_rejestr, ref bh_rejestr, ref bl_rejestr);
                    this.label_bh_wartosc.Text = bh_rejestr;
                    this.label_bl_wartosc.Text = bl_rejestr;
                    break;
                case "BH":
                    liczba1 = zamien_na_int(bh_rejestr);
                    if (liczba1 >= liczba2)
                    {
                        wynik = liczba1 - liczba2;
                    }
                    else wynik = liczba2 - liczba1;
                    wynik_bit = zamien_na_bit(wynik, 8);
                    bh_rejestr = wynik_bit;
                    this.label_bh_wartosc.Text = bh_rejestr;
                    break;
                case "BL":
                    liczba1 = zamien_na_int(bl_rejestr);
                    if (liczba1 >= liczba2)
                    {
                        wynik = liczba1 - liczba2;
                    }
                    else wynik = liczba2 - liczba1;
                    wynik_bit = zamien_na_bit(wynik, 8);
                    bl_rejestr = wynik_bit;
                    this.label_bl_wartosc.Text = bl_rejestr;
                    break;
                case "CX":
                    liczba1 = zamien_na_int(cx_rejestr);
                    if (liczba1 >= liczba2)
                    {
                        wynik = liczba1 - liczba2;
                    }
                    else wynik = liczba2 - liczba1;
                    wynik_bit = zamien_na_bit(wynik, 16);
                    cx_rejestr = wynik_bit;
                    this.label_cx.Text = cx_rejestr;
                    rozdziel_rejestr(cx_rejestr, ref ch_rejestr, ref cl_rejestr);
                    this.label_ch_wartosc.Text = ch_rejestr;
                    this.label_cl_wartosc.Text = cl_rejestr;
                    break;
                case "CH":
                    liczba1 = zamien_na_int(ch_rejestr);
                    if (liczba1 >= liczba2)
                    {
                        wynik = liczba1 - liczba2;
                    }
                    else wynik = liczba2 - liczba1;
                    wynik_bit = zamien_na_bit(wynik, 8);
                    ch_rejestr = wynik_bit;
                    this.label_ch_wartosc.Text = ch_rejestr;
                    break;
                case "CL":
                    liczba1 = zamien_na_int(cl_rejestr);
                    if (liczba1 >= liczba2)
                    {
                        wynik = liczba1 - liczba2;
                    }
                    else wynik = liczba2 - liczba1;
                    wynik_bit = zamien_na_bit(wynik, 8);
                    cl_rejestr = wynik_bit;
                    this.label_cl_wartosc.Text = cl_rejestr;
                    break;
                case "DX":
                    liczba1 = zamien_na_int(dx_rejestr);
                    if (liczba1 >= liczba2)
                    {
                        wynik = liczba1 - liczba2;
                    }
                    else wynik = liczba2 - liczba1;
                    wynik_bit = zamien_na_bit(wynik, 16);
                    dx_rejestr = wynik_bit;
                    this.label_dx.Text = dx_rejestr;
                    rozdziel_rejestr(dx_rejestr, ref dh_rejestr, ref dl_rejestr);
                    this.label_dh_wartosc.Text = dh_rejestr;
                    this.label_dl_wartosc.Text = dl_rejestr;
                    break;
                case "DH":
                    liczba1 = zamien_na_int(dh_rejestr);
                    if (liczba1 >= liczba2)
                    {
                        wynik = liczba1 - liczba2;
                    }
                    else wynik = liczba2 - liczba1;
                    wynik_bit = zamien_na_bit(wynik, 8);
                    dh_rejestr = wynik_bit;
                    this.label_dh_wartosc.Text = dh_rejestr;
                    break;
                case "DL":
                    liczba1 = zamien_na_int(dl_rejestr);
                    if (liczba1 >= liczba2)
                    {
                        wynik = liczba1 - liczba2;
                    }
                    else wynik = liczba2 - liczba1;
                    wynik_bit = zamien_na_bit(wynik, 8);
                    dl_rejestr = wynik_bit;
                    this.label_dl_wartosc.Text = dl_rejestr;
                    break;
            }
        }

        private int zamien_na_int(string rejestr)
        {
            int wartosc = 0;
            for (int i = 0; i < rejestr.Length; i++)
            {
                if (rejestr[i] == '1')
                {
                    wartosc += Convert.ToInt32(Math.Pow(2, rejestr.Length - 1 - i));
                }
            }
            return wartosc;
        }

        private string zamien_na_bit(int liczba, int dlugosc)
        {
            string wynik = "";
            for (int i = dlugosc - 1; i > -1; i--)
            {
                if (liczba % 2 == 1)
                {
                    wynik += "1";
                }
                else
                {
                    wynik += "0";
                }
                liczba = liczba / 2;
            }
            char[] charArray = wynik.ToCharArray();
            Array.Reverse(charArray);
            wynik = new string(charArray);
            //wynik.Reverse(); // tutaj jest zle
            return wynik;
        }
    }
}
