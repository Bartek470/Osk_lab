﻿
namespace Sym_mikroprocesora5
{
    partial class Form1
    {
        /// <summary>
        /// Wymagana zmienna projektanta.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        public string ax_rejestr;
        public string al_rejestr;
        public string ah_rejestr;
        public string bx_rejestr;
        public string bl_rejestr;
        public string bh_rejestr;
        public string cx_rejestr;
        public string cl_rejestr;
        public string ch_rejestr;
        public string dx_rejestr;
        public string dl_rejestr;
        public string dh_rejestr;
        public string inl_rejestr;
        public string inh_rejestr;
        public string in_rejestr;
        public string instrukcjaa;
        public string argument_1;
        public string argument_2;
        public Form2 kod_programu;
        

        /// <summary>
        /// Wyczyść wszystkie używane zasoby.
        /// </summary>
        /// <param name="disposing">prawda, jeżeli zarządzane zasoby powinny zostać zlikwidowane; Fałsz w przeciwnym wypadku.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kod generowany przez Projektanta formularzy systemu Windows

        /// <summary>
        /// Metoda wymagana do obsługi projektanta — nie należy modyfikować
        /// jej zawartości w edytorze kodu.
        /// </summary>
        private void InitializeComponent()
        {
            this.label_ax_1 = new System.Windows.Forms.Label();
            this.label_ax_0 = new System.Windows.Forms.Label();
            this.groupBox_ax_15 = new System.Windows.Forms.GroupBox();
            this.radioButton_ax_15_0 = new System.Windows.Forms.RadioButton();
            this.radioButton_ax_15_1 = new System.Windows.Forms.RadioButton();
            this.groupBox_ax_10 = new System.Windows.Forms.GroupBox();
            this.radioButton_ax_10_0 = new System.Windows.Forms.RadioButton();
            this.radioButton_ax_10_1 = new System.Windows.Forms.RadioButton();
            this.groupBox_ax_14 = new System.Windows.Forms.GroupBox();
            this.radioButton_ax_14_0 = new System.Windows.Forms.RadioButton();
            this.radioButton_ax_14_1 = new System.Windows.Forms.RadioButton();
            this.groupBox_ax_8 = new System.Windows.Forms.GroupBox();
            this.radioButton_ax_8_0 = new System.Windows.Forms.RadioButton();
            this.radioButton_ax_8_1 = new System.Windows.Forms.RadioButton();
            this.groupBox_ax_12 = new System.Windows.Forms.GroupBox();
            this.radioButton_ax_12_0 = new System.Windows.Forms.RadioButton();
            this.radioButton_ax_12_1 = new System.Windows.Forms.RadioButton();
            this.groupBox_ax_11 = new System.Windows.Forms.GroupBox();
            this.radioButton_ax_11_0 = new System.Windows.Forms.RadioButton();
            this.radioButton_ax_11_1 = new System.Windows.Forms.RadioButton();
            this.groupBox_ax_9 = new System.Windows.Forms.GroupBox();
            this.radioButton_ax_9_0 = new System.Windows.Forms.RadioButton();
            this.radioButton_ax_9_1 = new System.Windows.Forms.RadioButton();
            this.groupBox_ax_13 = new System.Windows.Forms.GroupBox();
            this.radioButton_ax_13_0 = new System.Windows.Forms.RadioButton();
            this.radioButton_ax_13_1 = new System.Windows.Forms.RadioButton();
            this.label_ax = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox_ax_1 = new System.Windows.Forms.GroupBox();
            this.radioButton_ax_1_0 = new System.Windows.Forms.RadioButton();
            this.radioButton_ax_1_1 = new System.Windows.Forms.RadioButton();
            this.groupBox_ax_0 = new System.Windows.Forms.GroupBox();
            this.radioButton_ax_0_0 = new System.Windows.Forms.RadioButton();
            this.radioButton_ax_0_1 = new System.Windows.Forms.RadioButton();
            this.groupBox_ax_4 = new System.Windows.Forms.GroupBox();
            this.radioButton_ax_4_0 = new System.Windows.Forms.RadioButton();
            this.radioButton_ax_4_1 = new System.Windows.Forms.RadioButton();
            this.groupBox_ax_3 = new System.Windows.Forms.GroupBox();
            this.radioButton_ax_3_0 = new System.Windows.Forms.RadioButton();
            this.radioButton_ax_3_1 = new System.Windows.Forms.RadioButton();
            this.groupBox_ax_2 = new System.Windows.Forms.GroupBox();
            this.radioButton_ax_2_0 = new System.Windows.Forms.RadioButton();
            this.radioButton_ax_2_1 = new System.Windows.Forms.RadioButton();
            this.groupBox_ax_6 = new System.Windows.Forms.GroupBox();
            this.radioButton_ax_6_0 = new System.Windows.Forms.RadioButton();
            this.radioButton_ax_6_1 = new System.Windows.Forms.RadioButton();
            this.groupBox_ax_5 = new System.Windows.Forms.GroupBox();
            this.radioButton_ax_5_0 = new System.Windows.Forms.RadioButton();
            this.radioButton_ax_5_1 = new System.Windows.Forms.RadioButton();
            this.groupBox_ax_7 = new System.Windows.Forms.GroupBox();
            this.radioButton_ax_7_0 = new System.Windows.Forms.RadioButton();
            this.radioButton_ax_7_1 = new System.Windows.Forms.RadioButton();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.button_ax = new System.Windows.Forms.Button();
            this.label_al_wartosc = new System.Windows.Forms.Label();
            this.label_ah_wartosc = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label_bh_wartosc = new System.Windows.Forms.Label();
            this.label_bl_wartosc = new System.Windows.Forms.Label();
            this.button_bx = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.groupBox_bx_1 = new System.Windows.Forms.GroupBox();
            this.radioButton_bx_1_0 = new System.Windows.Forms.RadioButton();
            this.radioButton_bx_1_1 = new System.Windows.Forms.RadioButton();
            this.label15 = new System.Windows.Forms.Label();
            this.groupBox_bx_0 = new System.Windows.Forms.GroupBox();
            this.radioButton_bx_0_0 = new System.Windows.Forms.RadioButton();
            this.radioButton_bx_0_1 = new System.Windows.Forms.RadioButton();
            this.label16 = new System.Windows.Forms.Label();
            this.groupBox_bx_4 = new System.Windows.Forms.GroupBox();
            this.radioButton_bx_4_0 = new System.Windows.Forms.RadioButton();
            this.radioButton_bx_4_1 = new System.Windows.Forms.RadioButton();
            this.label_bx = new System.Windows.Forms.Label();
            this.groupBox_bx_3 = new System.Windows.Forms.GroupBox();
            this.radioButton_bx_3_0 = new System.Windows.Forms.RadioButton();
            this.radioButton_bx_3_1 = new System.Windows.Forms.RadioButton();
            this.groupBox_bx_9 = new System.Windows.Forms.GroupBox();
            this.radioButton_bx_9_0 = new System.Windows.Forms.RadioButton();
            this.radioButton_bx_9_1 = new System.Windows.Forms.RadioButton();
            this.groupBox_bx_2 = new System.Windows.Forms.GroupBox();
            this.radioButton_bx_2_0 = new System.Windows.Forms.RadioButton();
            this.radioButton_bx_2_1 = new System.Windows.Forms.RadioButton();
            this.groupBox_bx_8 = new System.Windows.Forms.GroupBox();
            this.radioButton_bx_8_0 = new System.Windows.Forms.RadioButton();
            this.radioButton_bx_8_1 = new System.Windows.Forms.RadioButton();
            this.groupBox_bx_6 = new System.Windows.Forms.GroupBox();
            this.radioButton_bx_6_0 = new System.Windows.Forms.RadioButton();
            this.radioButton_bx_6_1 = new System.Windows.Forms.RadioButton();
            this.groupBox_bx_12 = new System.Windows.Forms.GroupBox();
            this.radioButton_bx_12_0 = new System.Windows.Forms.RadioButton();
            this.radioButton_bx_12_1 = new System.Windows.Forms.RadioButton();
            this.groupBox_bx_5 = new System.Windows.Forms.GroupBox();
            this.radioButton_bx_5_0 = new System.Windows.Forms.RadioButton();
            this.radioButton_bx_5_1 = new System.Windows.Forms.RadioButton();
            this.groupBox_bx_11 = new System.Windows.Forms.GroupBox();
            this.radioButton_bx_11_0 = new System.Windows.Forms.RadioButton();
            this.radioButton_bx_11_1 = new System.Windows.Forms.RadioButton();
            this.groupBox_bx_7 = new System.Windows.Forms.GroupBox();
            this.radioButton_bx_7_0 = new System.Windows.Forms.RadioButton();
            this.radioButton_bx_7_1 = new System.Windows.Forms.RadioButton();
            this.groupBox_bx_10 = new System.Windows.Forms.GroupBox();
            this.radioButton_bx_10_0 = new System.Windows.Forms.RadioButton();
            this.radioButton_bx_10_1 = new System.Windows.Forms.RadioButton();
            this.groupBox_bx_14 = new System.Windows.Forms.GroupBox();
            this.radioButton_bx_14_0 = new System.Windows.Forms.RadioButton();
            this.radioButton_bx_14_1 = new System.Windows.Forms.RadioButton();
            this.groupBox_bx_13 = new System.Windows.Forms.GroupBox();
            this.radioButton_bx_13_0 = new System.Windows.Forms.RadioButton();
            this.radioButton_bx_13_1 = new System.Windows.Forms.RadioButton();
            this.groupBox_bx_15 = new System.Windows.Forms.GroupBox();
            this.radioButton_bx_15_0 = new System.Windows.Forms.RadioButton();
            this.radioButton_bx_15_1 = new System.Windows.Forms.RadioButton();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label_dh_wartosc = new System.Windows.Forms.Label();
            this.label_dl_wartosc = new System.Windows.Forms.Label();
            this.button_dx = new System.Windows.Forms.Button();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.groupBox_dx_1 = new System.Windows.Forms.GroupBox();
            this.radioButton_dx_1_0 = new System.Windows.Forms.RadioButton();
            this.radioButton_dx_1_1 = new System.Windows.Forms.RadioButton();
            this.label24 = new System.Windows.Forms.Label();
            this.groupBox_dx_0 = new System.Windows.Forms.GroupBox();
            this.radioButton_dx_0_0 = new System.Windows.Forms.RadioButton();
            this.radioButton_dx_0_1 = new System.Windows.Forms.RadioButton();
            this.label25 = new System.Windows.Forms.Label();
            this.groupBox_dx_4 = new System.Windows.Forms.GroupBox();
            this.radioButton_dx_4_0 = new System.Windows.Forms.RadioButton();
            this.radioButton_dx_4_1 = new System.Windows.Forms.RadioButton();
            this.label_dx = new System.Windows.Forms.Label();
            this.groupBox_dx_3 = new System.Windows.Forms.GroupBox();
            this.radioButton_dx_3_0 = new System.Windows.Forms.RadioButton();
            this.radioButton_dx_3_1 = new System.Windows.Forms.RadioButton();
            this.groupBox_dx_9 = new System.Windows.Forms.GroupBox();
            this.radioButton_dx_9_0 = new System.Windows.Forms.RadioButton();
            this.radioButton_dx_9_1 = new System.Windows.Forms.RadioButton();
            this.groupBox_dx_2 = new System.Windows.Forms.GroupBox();
            this.radioButton_dx_2_0 = new System.Windows.Forms.RadioButton();
            this.radioButton_dx_2_1 = new System.Windows.Forms.RadioButton();
            this.groupBox_dx_8 = new System.Windows.Forms.GroupBox();
            this.radioButton_dx_8_0 = new System.Windows.Forms.RadioButton();
            this.radioButton_dx_8_1 = new System.Windows.Forms.RadioButton();
            this.groupBox_dx_6 = new System.Windows.Forms.GroupBox();
            this.radioButton_dx_6_0 = new System.Windows.Forms.RadioButton();
            this.radioButton_dx_6_1 = new System.Windows.Forms.RadioButton();
            this.groupBox_dx_12 = new System.Windows.Forms.GroupBox();
            this.radioButton_dx_12_0 = new System.Windows.Forms.RadioButton();
            this.radioButton_dx_12_1 = new System.Windows.Forms.RadioButton();
            this.groupBox_dx_5 = new System.Windows.Forms.GroupBox();
            this.radioButton_dx_5_0 = new System.Windows.Forms.RadioButton();
            this.radioButton_dx_5_1 = new System.Windows.Forms.RadioButton();
            this.groupBox_dx_11 = new System.Windows.Forms.GroupBox();
            this.radioButton_dx_11_0 = new System.Windows.Forms.RadioButton();
            this.radioButton_dx_11_1 = new System.Windows.Forms.RadioButton();
            this.groupBox_dx_7 = new System.Windows.Forms.GroupBox();
            this.radioButton_dx_7_0 = new System.Windows.Forms.RadioButton();
            this.radioButton_dx_7_1 = new System.Windows.Forms.RadioButton();
            this.groupBox_dx_10 = new System.Windows.Forms.GroupBox();
            this.radioButton_dx_10_0 = new System.Windows.Forms.RadioButton();
            this.radioButton_dx_10_1 = new System.Windows.Forms.RadioButton();
            this.groupBox_dx_14 = new System.Windows.Forms.GroupBox();
            this.radioButton_dx_14_0 = new System.Windows.Forms.RadioButton();
            this.radioButton_dx_14_1 = new System.Windows.Forms.RadioButton();
            this.groupBox_dx_13 = new System.Windows.Forms.GroupBox();
            this.radioButton_dx_13_0 = new System.Windows.Forms.RadioButton();
            this.radioButton_dx_13_1 = new System.Windows.Forms.RadioButton();
            this.groupBox_dx_15 = new System.Windows.Forms.GroupBox();
            this.radioButton_dx_15_0 = new System.Windows.Forms.RadioButton();
            this.radioButton_dx_15_1 = new System.Windows.Forms.RadioButton();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label_ch_wartosc = new System.Windows.Forms.Label();
            this.label_cl_wartosc = new System.Windows.Forms.Label();
            this.button_cx = new System.Windows.Forms.Button();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.groupBox_cx_1 = new System.Windows.Forms.GroupBox();
            this.radioButton_cx_1_0 = new System.Windows.Forms.RadioButton();
            this.radioButton_cx_1_1 = new System.Windows.Forms.RadioButton();
            this.label36 = new System.Windows.Forms.Label();
            this.groupBox_cx_0 = new System.Windows.Forms.GroupBox();
            this.radioButton_cx_0_0 = new System.Windows.Forms.RadioButton();
            this.radioButton_cx_0_1 = new System.Windows.Forms.RadioButton();
            this.label37 = new System.Windows.Forms.Label();
            this.groupBox_cx_4 = new System.Windows.Forms.GroupBox();
            this.radioButton_cx_4_0 = new System.Windows.Forms.RadioButton();
            this.radioButton_cx_4_1 = new System.Windows.Forms.RadioButton();
            this.label_cx = new System.Windows.Forms.Label();
            this.groupBox_cx_3 = new System.Windows.Forms.GroupBox();
            this.radioButton_cx_3_0 = new System.Windows.Forms.RadioButton();
            this.radioButton_cx_3_1 = new System.Windows.Forms.RadioButton();
            this.groupBox_cx_9 = new System.Windows.Forms.GroupBox();
            this.radioButton_cx_9_0 = new System.Windows.Forms.RadioButton();
            this.radioButton_cx_9_1 = new System.Windows.Forms.RadioButton();
            this.groupBox_cx_2 = new System.Windows.Forms.GroupBox();
            this.radioButton_cx_2_0 = new System.Windows.Forms.RadioButton();
            this.radioButton_cx_2_1 = new System.Windows.Forms.RadioButton();
            this.groupBox_cx_8 = new System.Windows.Forms.GroupBox();
            this.radioButton_cx_8_0 = new System.Windows.Forms.RadioButton();
            this.radioButton_cx_8_1 = new System.Windows.Forms.RadioButton();
            this.groupBox_cx_6 = new System.Windows.Forms.GroupBox();
            this.radioButton_cx_6_0 = new System.Windows.Forms.RadioButton();
            this.radioButton_cx_6_1 = new System.Windows.Forms.RadioButton();
            this.groupBox_cx_12 = new System.Windows.Forms.GroupBox();
            this.radioButton_cx_12_0 = new System.Windows.Forms.RadioButton();
            this.radioButton_cx_12_1 = new System.Windows.Forms.RadioButton();
            this.groupBox_cx_5 = new System.Windows.Forms.GroupBox();
            this.radioButton_cx_5_0 = new System.Windows.Forms.RadioButton();
            this.radioButton_cx_5_1 = new System.Windows.Forms.RadioButton();
            this.groupBox_cx_11 = new System.Windows.Forms.GroupBox();
            this.radioButton_cx_11_0 = new System.Windows.Forms.RadioButton();
            this.radioButton_cx_11_1 = new System.Windows.Forms.RadioButton();
            this.groupBox_cx_7 = new System.Windows.Forms.GroupBox();
            this.radioButton_cx_7_0 = new System.Windows.Forms.RadioButton();
            this.radioButton_cx_7_1 = new System.Windows.Forms.RadioButton();
            this.groupBox_cx_10 = new System.Windows.Forms.GroupBox();
            this.radioButton_cx_10_0 = new System.Windows.Forms.RadioButton();
            this.radioButton_cx_10_1 = new System.Windows.Forms.RadioButton();
            this.groupBox_cx_14 = new System.Windows.Forms.GroupBox();
            this.radioButton_cx_14_0 = new System.Windows.Forms.RadioButton();
            this.radioButton_cx_14_1 = new System.Windows.Forms.RadioButton();
            this.groupBox_cx_13 = new System.Windows.Forms.GroupBox();
            this.radioButton_cx_13_0 = new System.Windows.Forms.RadioButton();
            this.radioButton_cx_13_1 = new System.Windows.Forms.RadioButton();
            this.groupBox_cx_15 = new System.Windows.Forms.GroupBox();
            this.radioButton_cx_15_0 = new System.Windows.Forms.RadioButton();
            this.radioButton_cx_15_1 = new System.Windows.Forms.RadioButton();
            this.label39 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label_inh_wartosc = new System.Windows.Forms.Label();
            this.label_inl_wartosc = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.groupBox_in_1 = new System.Windows.Forms.GroupBox();
            this.radioButton_in_1_0 = new System.Windows.Forms.RadioButton();
            this.radioButton_in_1_1 = new System.Windows.Forms.RadioButton();
            this.label42 = new System.Windows.Forms.Label();
            this.groupBox_in_0 = new System.Windows.Forms.GroupBox();
            this.radioButton_in_0_0 = new System.Windows.Forms.RadioButton();
            this.radioButton_in_0_1 = new System.Windows.Forms.RadioButton();
            this.label43 = new System.Windows.Forms.Label();
            this.groupBox_in_4 = new System.Windows.Forms.GroupBox();
            this.radioButton_in_4_0 = new System.Windows.Forms.RadioButton();
            this.radioButton_in_4_1 = new System.Windows.Forms.RadioButton();
            this.groupBox_in_3 = new System.Windows.Forms.GroupBox();
            this.radioButton_in_3_0 = new System.Windows.Forms.RadioButton();
            this.radioButton_in_3_1 = new System.Windows.Forms.RadioButton();
            this.groupBox_in_9 = new System.Windows.Forms.GroupBox();
            this.radioButton_in_9_0 = new System.Windows.Forms.RadioButton();
            this.radioButton_in_9_1 = new System.Windows.Forms.RadioButton();
            this.groupBox_in_2 = new System.Windows.Forms.GroupBox();
            this.radioButton_in_2_0 = new System.Windows.Forms.RadioButton();
            this.radioButton_in_2_1 = new System.Windows.Forms.RadioButton();
            this.groupBox_in_8 = new System.Windows.Forms.GroupBox();
            this.radioButton_in_8_0 = new System.Windows.Forms.RadioButton();
            this.radioButton_in_8_1 = new System.Windows.Forms.RadioButton();
            this.groupBox_in_6 = new System.Windows.Forms.GroupBox();
            this.radioButton_in_6_0 = new System.Windows.Forms.RadioButton();
            this.radioButton_in_6_1 = new System.Windows.Forms.RadioButton();
            this.groupBox_in_12 = new System.Windows.Forms.GroupBox();
            this.radioButton_in_12_0 = new System.Windows.Forms.RadioButton();
            this.radioButton_in_12_1 = new System.Windows.Forms.RadioButton();
            this.groupBox_in_5 = new System.Windows.Forms.GroupBox();
            this.radioButton_in_5_0 = new System.Windows.Forms.RadioButton();
            this.radioButton_in_5_1 = new System.Windows.Forms.RadioButton();
            this.groupBox_in_11 = new System.Windows.Forms.GroupBox();
            this.radioButton_in_11_0 = new System.Windows.Forms.RadioButton();
            this.radioButton_in_11_1 = new System.Windows.Forms.RadioButton();
            this.groupBox_in_7 = new System.Windows.Forms.GroupBox();
            this.radioButton_in_7_0 = new System.Windows.Forms.RadioButton();
            this.radioButton_in_7_1 = new System.Windows.Forms.RadioButton();
            this.groupBox_in_10 = new System.Windows.Forms.GroupBox();
            this.radioButton_in_10_0 = new System.Windows.Forms.RadioButton();
            this.radioButton_in_10_1 = new System.Windows.Forms.RadioButton();
            this.groupBox_in_14 = new System.Windows.Forms.GroupBox();
            this.radioButton_in_14_0 = new System.Windows.Forms.RadioButton();
            this.radioButton_in_14_1 = new System.Windows.Forms.RadioButton();
            this.groupBox_in_13 = new System.Windows.Forms.GroupBox();
            this.radioButton_in_13_0 = new System.Windows.Forms.RadioButton();
            this.radioButton_in_13_1 = new System.Windows.Forms.RadioButton();
            this.groupBox_in_15 = new System.Windows.Forms.GroupBox();
            this.radioButton_in_15_0 = new System.Windows.Forms.RadioButton();
            this.radioButton_in_15_1 = new System.Windows.Forms.RadioButton();
            this.label45 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.comboBox_instrukcja = new System.Windows.Forms.ComboBox();
            this.comboBox_arg1 = new System.Windows.Forms.ComboBox();
            this.comboBox_arg2 = new System.Windows.Forms.ComboBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.groupBox_ax_15.SuspendLayout();
            this.groupBox_ax_10.SuspendLayout();
            this.groupBox_ax_14.SuspendLayout();
            this.groupBox_ax_8.SuspendLayout();
            this.groupBox_ax_12.SuspendLayout();
            this.groupBox_ax_11.SuspendLayout();
            this.groupBox_ax_9.SuspendLayout();
            this.groupBox_ax_13.SuspendLayout();
            this.groupBox_ax_1.SuspendLayout();
            this.groupBox_ax_0.SuspendLayout();
            this.groupBox_ax_4.SuspendLayout();
            this.groupBox_ax_3.SuspendLayout();
            this.groupBox_ax_2.SuspendLayout();
            this.groupBox_ax_6.SuspendLayout();
            this.groupBox_ax_5.SuspendLayout();
            this.groupBox_ax_7.SuspendLayout();
            this.groupBox_bx_1.SuspendLayout();
            this.groupBox_bx_0.SuspendLayout();
            this.groupBox_bx_4.SuspendLayout();
            this.groupBox_bx_3.SuspendLayout();
            this.groupBox_bx_9.SuspendLayout();
            this.groupBox_bx_2.SuspendLayout();
            this.groupBox_bx_8.SuspendLayout();
            this.groupBox_bx_6.SuspendLayout();
            this.groupBox_bx_12.SuspendLayout();
            this.groupBox_bx_5.SuspendLayout();
            this.groupBox_bx_11.SuspendLayout();
            this.groupBox_bx_7.SuspendLayout();
            this.groupBox_bx_10.SuspendLayout();
            this.groupBox_bx_14.SuspendLayout();
            this.groupBox_bx_13.SuspendLayout();
            this.groupBox_bx_15.SuspendLayout();
            this.groupBox_dx_1.SuspendLayout();
            this.groupBox_dx_0.SuspendLayout();
            this.groupBox_dx_4.SuspendLayout();
            this.groupBox_dx_3.SuspendLayout();
            this.groupBox_dx_9.SuspendLayout();
            this.groupBox_dx_2.SuspendLayout();
            this.groupBox_dx_8.SuspendLayout();
            this.groupBox_dx_6.SuspendLayout();
            this.groupBox_dx_12.SuspendLayout();
            this.groupBox_dx_5.SuspendLayout();
            this.groupBox_dx_11.SuspendLayout();
            this.groupBox_dx_7.SuspendLayout();
            this.groupBox_dx_10.SuspendLayout();
            this.groupBox_dx_14.SuspendLayout();
            this.groupBox_dx_13.SuspendLayout();
            this.groupBox_dx_15.SuspendLayout();
            this.groupBox_cx_1.SuspendLayout();
            this.groupBox_cx_0.SuspendLayout();
            this.groupBox_cx_4.SuspendLayout();
            this.groupBox_cx_3.SuspendLayout();
            this.groupBox_cx_9.SuspendLayout();
            this.groupBox_cx_2.SuspendLayout();
            this.groupBox_cx_8.SuspendLayout();
            this.groupBox_cx_6.SuspendLayout();
            this.groupBox_cx_12.SuspendLayout();
            this.groupBox_cx_5.SuspendLayout();
            this.groupBox_cx_11.SuspendLayout();
            this.groupBox_cx_7.SuspendLayout();
            this.groupBox_cx_10.SuspendLayout();
            this.groupBox_cx_14.SuspendLayout();
            this.groupBox_cx_13.SuspendLayout();
            this.groupBox_cx_15.SuspendLayout();
            this.groupBox_in_1.SuspendLayout();
            this.groupBox_in_0.SuspendLayout();
            this.groupBox_in_4.SuspendLayout();
            this.groupBox_in_3.SuspendLayout();
            this.groupBox_in_9.SuspendLayout();
            this.groupBox_in_2.SuspendLayout();
            this.groupBox_in_8.SuspendLayout();
            this.groupBox_in_6.SuspendLayout();
            this.groupBox_in_12.SuspendLayout();
            this.groupBox_in_5.SuspendLayout();
            this.groupBox_in_11.SuspendLayout();
            this.groupBox_in_7.SuspendLayout();
            this.groupBox_in_10.SuspendLayout();
            this.groupBox_in_14.SuspendLayout();
            this.groupBox_in_13.SuspendLayout();
            this.groupBox_in_15.SuspendLayout();
            this.SuspendLayout();
            // 
            // label_ax_1
            // 
            this.label_ax_1.AutoSize = true;
            this.label_ax_1.Location = new System.Drawing.Point(147, 95);
            this.label_ax_1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_ax_1.Name = "label_ax_1";
            this.label_ax_1.Size = new System.Drawing.Size(18, 20);
            this.label_ax_1.TabIndex = 16;
            this.label_ax_1.Text = "1";
            // 
            // label_ax_0
            // 
            this.label_ax_0.AutoSize = true;
            this.label_ax_0.Location = new System.Drawing.Point(147, 125);
            this.label_ax_0.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_ax_0.Name = "label_ax_0";
            this.label_ax_0.Size = new System.Drawing.Size(18, 20);
            this.label_ax_0.TabIndex = 17;
            this.label_ax_0.Text = "0";
            // 
            // groupBox_ax_15
            // 
            this.groupBox_ax_15.Controls.Add(this.radioButton_ax_15_0);
            this.groupBox_ax_15.Controls.Add(this.radioButton_ax_15_1);
            this.groupBox_ax_15.Location = new System.Drawing.Point(176, 72);
            this.groupBox_ax_15.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_ax_15.Name = "groupBox_ax_15";
            this.groupBox_ax_15.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_ax_15.Size = new System.Drawing.Size(40, 94);
            this.groupBox_ax_15.TabIndex = 18;
            this.groupBox_ax_15.TabStop = false;
            // 
            // radioButton_ax_15_0
            // 
            this.radioButton_ax_15_0.AutoSize = true;
            this.radioButton_ax_15_0.Checked = true;
            this.radioButton_ax_15_0.Location = new System.Drawing.Point(9, 52);
            this.radioButton_ax_15_0.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_ax_15_0.Name = "radioButton_ax_15_0";
            this.radioButton_ax_15_0.Size = new System.Drawing.Size(21, 20);
            this.radioButton_ax_15_0.TabIndex = 1;
            this.radioButton_ax_15_0.TabStop = true;
            this.radioButton_ax_15_0.UseVisualStyleBackColor = true;
            this.radioButton_ax_15_0.CheckedChanged += new System.EventHandler(this.radio_ax_click);
            // 
            // radioButton_ax_15_1
            // 
            this.radioButton_ax_15_1.AutoSize = true;
            this.radioButton_ax_15_1.Location = new System.Drawing.Point(9, 23);
            this.radioButton_ax_15_1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_ax_15_1.Name = "radioButton_ax_15_1";
            this.radioButton_ax_15_1.Size = new System.Drawing.Size(21, 20);
            this.radioButton_ax_15_1.TabIndex = 0;
            this.radioButton_ax_15_1.UseVisualStyleBackColor = true;
            this.radioButton_ax_15_1.CheckedChanged += new System.EventHandler(this.radio_ax_click);
            // 
            // groupBox_ax_10
            // 
            this.groupBox_ax_10.Controls.Add(this.radioButton_ax_10_0);
            this.groupBox_ax_10.Controls.Add(this.radioButton_ax_10_1);
            this.groupBox_ax_10.Location = new System.Drawing.Point(423, 72);
            this.groupBox_ax_10.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_ax_10.Name = "groupBox_ax_10";
            this.groupBox_ax_10.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_ax_10.Size = new System.Drawing.Size(40, 94);
            this.groupBox_ax_10.TabIndex = 19;
            this.groupBox_ax_10.TabStop = false;
            // 
            // radioButton_ax_10_0
            // 
            this.radioButton_ax_10_0.AutoSize = true;
            this.radioButton_ax_10_0.Checked = true;
            this.radioButton_ax_10_0.Location = new System.Drawing.Point(9, 52);
            this.radioButton_ax_10_0.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_ax_10_0.Name = "radioButton_ax_10_0";
            this.radioButton_ax_10_0.Size = new System.Drawing.Size(21, 20);
            this.radioButton_ax_10_0.TabIndex = 1;
            this.radioButton_ax_10_0.TabStop = true;
            this.radioButton_ax_10_0.UseVisualStyleBackColor = true;
            this.radioButton_ax_10_0.CheckedChanged += new System.EventHandler(this.radio_ax_click);
            // 
            // radioButton_ax_10_1
            // 
            this.radioButton_ax_10_1.AutoSize = true;
            this.radioButton_ax_10_1.Location = new System.Drawing.Point(9, 23);
            this.radioButton_ax_10_1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_ax_10_1.Name = "radioButton_ax_10_1";
            this.radioButton_ax_10_1.Size = new System.Drawing.Size(21, 20);
            this.radioButton_ax_10_1.TabIndex = 0;
            this.radioButton_ax_10_1.UseVisualStyleBackColor = true;
            this.radioButton_ax_10_1.CheckedChanged += new System.EventHandler(this.radio_ax_click);
            // 
            // groupBox_ax_14
            // 
            this.groupBox_ax_14.Controls.Add(this.radioButton_ax_14_0);
            this.groupBox_ax_14.Controls.Add(this.radioButton_ax_14_1);
            this.groupBox_ax_14.Location = new System.Drawing.Point(225, 72);
            this.groupBox_ax_14.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_ax_14.Name = "groupBox_ax_14";
            this.groupBox_ax_14.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_ax_14.Size = new System.Drawing.Size(40, 94);
            this.groupBox_ax_14.TabIndex = 19;
            this.groupBox_ax_14.TabStop = false;
            // 
            // radioButton_ax_14_0
            // 
            this.radioButton_ax_14_0.AutoSize = true;
            this.radioButton_ax_14_0.Checked = true;
            this.radioButton_ax_14_0.Location = new System.Drawing.Point(9, 52);
            this.radioButton_ax_14_0.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_ax_14_0.Name = "radioButton_ax_14_0";
            this.radioButton_ax_14_0.Size = new System.Drawing.Size(21, 20);
            this.radioButton_ax_14_0.TabIndex = 1;
            this.radioButton_ax_14_0.TabStop = true;
            this.radioButton_ax_14_0.UseVisualStyleBackColor = true;
            this.radioButton_ax_14_0.CheckedChanged += new System.EventHandler(this.radio_ax_click);
            // 
            // radioButton_ax_14_1
            // 
            this.radioButton_ax_14_1.AutoSize = true;
            this.radioButton_ax_14_1.Location = new System.Drawing.Point(9, 23);
            this.radioButton_ax_14_1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_ax_14_1.Name = "radioButton_ax_14_1";
            this.radioButton_ax_14_1.Size = new System.Drawing.Size(21, 20);
            this.radioButton_ax_14_1.TabIndex = 0;
            this.radioButton_ax_14_1.UseVisualStyleBackColor = true;
            this.radioButton_ax_14_1.CheckedChanged += new System.EventHandler(this.radio_ax_click);
            // 
            // groupBox_ax_8
            // 
            this.groupBox_ax_8.Controls.Add(this.radioButton_ax_8_0);
            this.groupBox_ax_8.Controls.Add(this.radioButton_ax_8_1);
            this.groupBox_ax_8.Location = new System.Drawing.Point(522, 72);
            this.groupBox_ax_8.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_ax_8.Name = "groupBox_ax_8";
            this.groupBox_ax_8.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_ax_8.Size = new System.Drawing.Size(40, 94);
            this.groupBox_ax_8.TabIndex = 19;
            this.groupBox_ax_8.TabStop = false;
            // 
            // radioButton_ax_8_0
            // 
            this.radioButton_ax_8_0.AutoSize = true;
            this.radioButton_ax_8_0.Checked = true;
            this.radioButton_ax_8_0.Location = new System.Drawing.Point(9, 52);
            this.radioButton_ax_8_0.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_ax_8_0.Name = "radioButton_ax_8_0";
            this.radioButton_ax_8_0.Size = new System.Drawing.Size(21, 20);
            this.radioButton_ax_8_0.TabIndex = 1;
            this.radioButton_ax_8_0.TabStop = true;
            this.radioButton_ax_8_0.UseVisualStyleBackColor = true;
            this.radioButton_ax_8_0.CheckedChanged += new System.EventHandler(this.radio_ax_click);
            // 
            // radioButton_ax_8_1
            // 
            this.radioButton_ax_8_1.AutoSize = true;
            this.radioButton_ax_8_1.Location = new System.Drawing.Point(9, 23);
            this.radioButton_ax_8_1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_ax_8_1.Name = "radioButton_ax_8_1";
            this.radioButton_ax_8_1.Size = new System.Drawing.Size(21, 20);
            this.radioButton_ax_8_1.TabIndex = 0;
            this.radioButton_ax_8_1.UseVisualStyleBackColor = true;
            this.radioButton_ax_8_1.CheckedChanged += new System.EventHandler(this.radio_ax_click);
            // 
            // groupBox_ax_12
            // 
            this.groupBox_ax_12.Controls.Add(this.radioButton_ax_12_0);
            this.groupBox_ax_12.Controls.Add(this.radioButton_ax_12_1);
            this.groupBox_ax_12.Location = new System.Drawing.Point(324, 72);
            this.groupBox_ax_12.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_ax_12.Name = "groupBox_ax_12";
            this.groupBox_ax_12.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_ax_12.Size = new System.Drawing.Size(40, 94);
            this.groupBox_ax_12.TabIndex = 19;
            this.groupBox_ax_12.TabStop = false;
            // 
            // radioButton_ax_12_0
            // 
            this.radioButton_ax_12_0.AutoSize = true;
            this.radioButton_ax_12_0.Checked = true;
            this.radioButton_ax_12_0.Location = new System.Drawing.Point(9, 52);
            this.radioButton_ax_12_0.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_ax_12_0.Name = "radioButton_ax_12_0";
            this.radioButton_ax_12_0.Size = new System.Drawing.Size(21, 20);
            this.radioButton_ax_12_0.TabIndex = 1;
            this.radioButton_ax_12_0.TabStop = true;
            this.radioButton_ax_12_0.UseVisualStyleBackColor = true;
            this.radioButton_ax_12_0.CheckedChanged += new System.EventHandler(this.radio_ax_click);
            // 
            // radioButton_ax_12_1
            // 
            this.radioButton_ax_12_1.AutoSize = true;
            this.radioButton_ax_12_1.Location = new System.Drawing.Point(9, 23);
            this.radioButton_ax_12_1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_ax_12_1.Name = "radioButton_ax_12_1";
            this.radioButton_ax_12_1.Size = new System.Drawing.Size(21, 20);
            this.radioButton_ax_12_1.TabIndex = 0;
            this.radioButton_ax_12_1.UseVisualStyleBackColor = true;
            this.radioButton_ax_12_1.CheckedChanged += new System.EventHandler(this.radio_ax_click);
            // 
            // groupBox_ax_11
            // 
            this.groupBox_ax_11.Controls.Add(this.radioButton_ax_11_0);
            this.groupBox_ax_11.Controls.Add(this.radioButton_ax_11_1);
            this.groupBox_ax_11.Location = new System.Drawing.Point(374, 72);
            this.groupBox_ax_11.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_ax_11.Name = "groupBox_ax_11";
            this.groupBox_ax_11.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_ax_11.Size = new System.Drawing.Size(40, 94);
            this.groupBox_ax_11.TabIndex = 19;
            this.groupBox_ax_11.TabStop = false;
            // 
            // radioButton_ax_11_0
            // 
            this.radioButton_ax_11_0.AutoSize = true;
            this.radioButton_ax_11_0.Checked = true;
            this.radioButton_ax_11_0.Location = new System.Drawing.Point(9, 52);
            this.radioButton_ax_11_0.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_ax_11_0.Name = "radioButton_ax_11_0";
            this.radioButton_ax_11_0.Size = new System.Drawing.Size(21, 20);
            this.radioButton_ax_11_0.TabIndex = 1;
            this.radioButton_ax_11_0.TabStop = true;
            this.radioButton_ax_11_0.UseVisualStyleBackColor = true;
            this.radioButton_ax_11_0.CheckedChanged += new System.EventHandler(this.radio_ax_click);
            // 
            // radioButton_ax_11_1
            // 
            this.radioButton_ax_11_1.AutoSize = true;
            this.radioButton_ax_11_1.Location = new System.Drawing.Point(9, 23);
            this.radioButton_ax_11_1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_ax_11_1.Name = "radioButton_ax_11_1";
            this.radioButton_ax_11_1.Size = new System.Drawing.Size(21, 20);
            this.radioButton_ax_11_1.TabIndex = 0;
            this.radioButton_ax_11_1.UseVisualStyleBackColor = true;
            this.radioButton_ax_11_1.CheckedChanged += new System.EventHandler(this.radio_ax_click);
            // 
            // groupBox_ax_9
            // 
            this.groupBox_ax_9.Controls.Add(this.radioButton_ax_9_0);
            this.groupBox_ax_9.Controls.Add(this.radioButton_ax_9_1);
            this.groupBox_ax_9.Location = new System.Drawing.Point(472, 72);
            this.groupBox_ax_9.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_ax_9.Name = "groupBox_ax_9";
            this.groupBox_ax_9.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_ax_9.Size = new System.Drawing.Size(40, 94);
            this.groupBox_ax_9.TabIndex = 19;
            this.groupBox_ax_9.TabStop = false;
            // 
            // radioButton_ax_9_0
            // 
            this.radioButton_ax_9_0.AutoSize = true;
            this.radioButton_ax_9_0.Checked = true;
            this.radioButton_ax_9_0.Location = new System.Drawing.Point(9, 52);
            this.radioButton_ax_9_0.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_ax_9_0.Name = "radioButton_ax_9_0";
            this.radioButton_ax_9_0.Size = new System.Drawing.Size(21, 20);
            this.radioButton_ax_9_0.TabIndex = 1;
            this.radioButton_ax_9_0.TabStop = true;
            this.radioButton_ax_9_0.UseVisualStyleBackColor = true;
            this.radioButton_ax_9_0.CheckedChanged += new System.EventHandler(this.radio_ax_click);
            // 
            // radioButton_ax_9_1
            // 
            this.radioButton_ax_9_1.AutoSize = true;
            this.radioButton_ax_9_1.Location = new System.Drawing.Point(9, 23);
            this.radioButton_ax_9_1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_ax_9_1.Name = "radioButton_ax_9_1";
            this.radioButton_ax_9_1.Size = new System.Drawing.Size(21, 20);
            this.radioButton_ax_9_1.TabIndex = 0;
            this.radioButton_ax_9_1.UseVisualStyleBackColor = true;
            this.radioButton_ax_9_1.CheckedChanged += new System.EventHandler(this.radio_ax_click);
            // 
            // groupBox_ax_13
            // 
            this.groupBox_ax_13.Controls.Add(this.radioButton_ax_13_0);
            this.groupBox_ax_13.Controls.Add(this.radioButton_ax_13_1);
            this.groupBox_ax_13.Location = new System.Drawing.Point(274, 72);
            this.groupBox_ax_13.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_ax_13.Name = "groupBox_ax_13";
            this.groupBox_ax_13.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_ax_13.Size = new System.Drawing.Size(40, 94);
            this.groupBox_ax_13.TabIndex = 19;
            this.groupBox_ax_13.TabStop = false;
            // 
            // radioButton_ax_13_0
            // 
            this.radioButton_ax_13_0.AutoSize = true;
            this.radioButton_ax_13_0.Checked = true;
            this.radioButton_ax_13_0.Location = new System.Drawing.Point(9, 52);
            this.radioButton_ax_13_0.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_ax_13_0.Name = "radioButton_ax_13_0";
            this.radioButton_ax_13_0.Size = new System.Drawing.Size(21, 20);
            this.radioButton_ax_13_0.TabIndex = 1;
            this.radioButton_ax_13_0.TabStop = true;
            this.radioButton_ax_13_0.UseVisualStyleBackColor = true;
            this.radioButton_ax_13_0.CheckedChanged += new System.EventHandler(this.radio_ax_click);
            // 
            // radioButton_ax_13_1
            // 
            this.radioButton_ax_13_1.AutoSize = true;
            this.radioButton_ax_13_1.Location = new System.Drawing.Point(9, 23);
            this.radioButton_ax_13_1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_ax_13_1.Name = "radioButton_ax_13_1";
            this.radioButton_ax_13_1.Size = new System.Drawing.Size(21, 20);
            this.radioButton_ax_13_1.TabIndex = 0;
            this.radioButton_ax_13_1.UseVisualStyleBackColor = true;
            this.radioButton_ax_13_1.CheckedChanged += new System.EventHandler(this.radio_ax_click);
            // 
            // label_ax
            // 
            this.label_ax.AutoSize = true;
            this.label_ax.Location = new System.Drawing.Point(378, 202);
            this.label_ax.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_ax.Name = "label_ax";
            this.label_ax.Size = new System.Drawing.Size(153, 20);
            this.label_ax.TabIndex = 20;
            this.label_ax.Text = "0000000000000000";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(112, 172);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(49, 20);
            this.label1.TabIndex = 21;
            this.label1.Text = "15-bit";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(495, 37);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(138, 29);
            this.label2.TabIndex = 22;
            this.label2.Text = "Rejestr AX";
            // 
            // groupBox_ax_1
            // 
            this.groupBox_ax_1.Controls.Add(this.radioButton_ax_1_0);
            this.groupBox_ax_1.Controls.Add(this.radioButton_ax_1_1);
            this.groupBox_ax_1.Location = new System.Drawing.Point(896, 72);
            this.groupBox_ax_1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_ax_1.Name = "groupBox_ax_1";
            this.groupBox_ax_1.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_ax_1.Size = new System.Drawing.Size(40, 94);
            this.groupBox_ax_1.TabIndex = 21;
            this.groupBox_ax_1.TabStop = false;
            // 
            // radioButton_ax_1_0
            // 
            this.radioButton_ax_1_0.AutoSize = true;
            this.radioButton_ax_1_0.Checked = true;
            this.radioButton_ax_1_0.Location = new System.Drawing.Point(9, 52);
            this.radioButton_ax_1_0.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_ax_1_0.Name = "radioButton_ax_1_0";
            this.radioButton_ax_1_0.Size = new System.Drawing.Size(21, 20);
            this.radioButton_ax_1_0.TabIndex = 1;
            this.radioButton_ax_1_0.TabStop = true;
            this.radioButton_ax_1_0.UseVisualStyleBackColor = true;
            this.radioButton_ax_1_0.CheckedChanged += new System.EventHandler(this.radio_ax_click);
            // 
            // radioButton_ax_1_1
            // 
            this.radioButton_ax_1_1.AutoSize = true;
            this.radioButton_ax_1_1.Location = new System.Drawing.Point(9, 23);
            this.radioButton_ax_1_1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_ax_1_1.Name = "radioButton_ax_1_1";
            this.radioButton_ax_1_1.Size = new System.Drawing.Size(21, 20);
            this.radioButton_ax_1_1.TabIndex = 0;
            this.radioButton_ax_1_1.UseVisualStyleBackColor = true;
            this.radioButton_ax_1_1.CheckedChanged += new System.EventHandler(this.radio_ax_click);
            // 
            // groupBox_ax_0
            // 
            this.groupBox_ax_0.Controls.Add(this.radioButton_ax_0_0);
            this.groupBox_ax_0.Controls.Add(this.radioButton_ax_0_1);
            this.groupBox_ax_0.Location = new System.Drawing.Point(945, 72);
            this.groupBox_ax_0.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_ax_0.Name = "groupBox_ax_0";
            this.groupBox_ax_0.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_ax_0.Size = new System.Drawing.Size(40, 94);
            this.groupBox_ax_0.TabIndex = 22;
            this.groupBox_ax_0.TabStop = false;
            // 
            // radioButton_ax_0_0
            // 
            this.radioButton_ax_0_0.AutoSize = true;
            this.radioButton_ax_0_0.Checked = true;
            this.radioButton_ax_0_0.Location = new System.Drawing.Point(9, 52);
            this.radioButton_ax_0_0.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_ax_0_0.Name = "radioButton_ax_0_0";
            this.radioButton_ax_0_0.Size = new System.Drawing.Size(21, 20);
            this.radioButton_ax_0_0.TabIndex = 1;
            this.radioButton_ax_0_0.TabStop = true;
            this.radioButton_ax_0_0.UseVisualStyleBackColor = true;
            this.radioButton_ax_0_0.CheckedChanged += new System.EventHandler(this.radio_ax_click);
            // 
            // radioButton_ax_0_1
            // 
            this.radioButton_ax_0_1.AutoSize = true;
            this.radioButton_ax_0_1.Location = new System.Drawing.Point(9, 23);
            this.radioButton_ax_0_1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_ax_0_1.Name = "radioButton_ax_0_1";
            this.radioButton_ax_0_1.Size = new System.Drawing.Size(21, 20);
            this.radioButton_ax_0_1.TabIndex = 0;
            this.radioButton_ax_0_1.UseVisualStyleBackColor = true;
            this.radioButton_ax_0_1.CheckedChanged += new System.EventHandler(this.radio_ax_click);
            // 
            // groupBox_ax_4
            // 
            this.groupBox_ax_4.Controls.Add(this.radioButton_ax_4_0);
            this.groupBox_ax_4.Controls.Add(this.radioButton_ax_4_1);
            this.groupBox_ax_4.Location = new System.Drawing.Point(747, 72);
            this.groupBox_ax_4.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_ax_4.Name = "groupBox_ax_4";
            this.groupBox_ax_4.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_ax_4.Size = new System.Drawing.Size(40, 94);
            this.groupBox_ax_4.TabIndex = 23;
            this.groupBox_ax_4.TabStop = false;
            // 
            // radioButton_ax_4_0
            // 
            this.radioButton_ax_4_0.AutoSize = true;
            this.radioButton_ax_4_0.Checked = true;
            this.radioButton_ax_4_0.Location = new System.Drawing.Point(9, 52);
            this.radioButton_ax_4_0.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_ax_4_0.Name = "radioButton_ax_4_0";
            this.radioButton_ax_4_0.Size = new System.Drawing.Size(21, 20);
            this.radioButton_ax_4_0.TabIndex = 1;
            this.radioButton_ax_4_0.TabStop = true;
            this.radioButton_ax_4_0.UseVisualStyleBackColor = true;
            this.radioButton_ax_4_0.CheckedChanged += new System.EventHandler(this.radio_ax_click);
            // 
            // radioButton_ax_4_1
            // 
            this.radioButton_ax_4_1.AutoSize = true;
            this.radioButton_ax_4_1.Location = new System.Drawing.Point(9, 23);
            this.radioButton_ax_4_1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_ax_4_1.Name = "radioButton_ax_4_1";
            this.radioButton_ax_4_1.Size = new System.Drawing.Size(21, 20);
            this.radioButton_ax_4_1.TabIndex = 0;
            this.radioButton_ax_4_1.UseVisualStyleBackColor = true;
            this.radioButton_ax_4_1.CheckedChanged += new System.EventHandler(this.radio_ax_click);
            // 
            // groupBox_ax_3
            // 
            this.groupBox_ax_3.Controls.Add(this.radioButton_ax_3_0);
            this.groupBox_ax_3.Controls.Add(this.radioButton_ax_3_1);
            this.groupBox_ax_3.Location = new System.Drawing.Point(796, 72);
            this.groupBox_ax_3.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_ax_3.Name = "groupBox_ax_3";
            this.groupBox_ax_3.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_ax_3.Size = new System.Drawing.Size(40, 94);
            this.groupBox_ax_3.TabIndex = 24;
            this.groupBox_ax_3.TabStop = false;
            // 
            // radioButton_ax_3_0
            // 
            this.radioButton_ax_3_0.AutoSize = true;
            this.radioButton_ax_3_0.Checked = true;
            this.radioButton_ax_3_0.Location = new System.Drawing.Point(9, 52);
            this.radioButton_ax_3_0.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_ax_3_0.Name = "radioButton_ax_3_0";
            this.radioButton_ax_3_0.Size = new System.Drawing.Size(21, 20);
            this.radioButton_ax_3_0.TabIndex = 1;
            this.radioButton_ax_3_0.TabStop = true;
            this.radioButton_ax_3_0.UseVisualStyleBackColor = true;
            this.radioButton_ax_3_0.CheckedChanged += new System.EventHandler(this.radio_ax_click);
            // 
            // radioButton_ax_3_1
            // 
            this.radioButton_ax_3_1.AutoSize = true;
            this.radioButton_ax_3_1.Location = new System.Drawing.Point(9, 23);
            this.radioButton_ax_3_1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_ax_3_1.Name = "radioButton_ax_3_1";
            this.radioButton_ax_3_1.Size = new System.Drawing.Size(21, 20);
            this.radioButton_ax_3_1.TabIndex = 0;
            this.radioButton_ax_3_1.UseVisualStyleBackColor = true;
            this.radioButton_ax_3_1.CheckedChanged += new System.EventHandler(this.radio_ax_click);
            // 
            // groupBox_ax_2
            // 
            this.groupBox_ax_2.Controls.Add(this.radioButton_ax_2_0);
            this.groupBox_ax_2.Controls.Add(this.radioButton_ax_2_1);
            this.groupBox_ax_2.Location = new System.Drawing.Point(846, 72);
            this.groupBox_ax_2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_ax_2.Name = "groupBox_ax_2";
            this.groupBox_ax_2.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_ax_2.Size = new System.Drawing.Size(40, 94);
            this.groupBox_ax_2.TabIndex = 25;
            this.groupBox_ax_2.TabStop = false;
            // 
            // radioButton_ax_2_0
            // 
            this.radioButton_ax_2_0.AutoSize = true;
            this.radioButton_ax_2_0.Checked = true;
            this.radioButton_ax_2_0.Location = new System.Drawing.Point(9, 52);
            this.radioButton_ax_2_0.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_ax_2_0.Name = "radioButton_ax_2_0";
            this.radioButton_ax_2_0.Size = new System.Drawing.Size(21, 20);
            this.radioButton_ax_2_0.TabIndex = 1;
            this.radioButton_ax_2_0.TabStop = true;
            this.radioButton_ax_2_0.UseVisualStyleBackColor = true;
            this.radioButton_ax_2_0.CheckedChanged += new System.EventHandler(this.radio_ax_click);
            // 
            // radioButton_ax_2_1
            // 
            this.radioButton_ax_2_1.AutoSize = true;
            this.radioButton_ax_2_1.Location = new System.Drawing.Point(9, 23);
            this.radioButton_ax_2_1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_ax_2_1.Name = "radioButton_ax_2_1";
            this.radioButton_ax_2_1.Size = new System.Drawing.Size(21, 20);
            this.radioButton_ax_2_1.TabIndex = 0;
            this.radioButton_ax_2_1.UseVisualStyleBackColor = true;
            this.radioButton_ax_2_1.CheckedChanged += new System.EventHandler(this.radio_ax_click);
            // 
            // groupBox_ax_6
            // 
            this.groupBox_ax_6.Controls.Add(this.radioButton_ax_6_0);
            this.groupBox_ax_6.Controls.Add(this.radioButton_ax_6_1);
            this.groupBox_ax_6.Location = new System.Drawing.Point(648, 72);
            this.groupBox_ax_6.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_ax_6.Name = "groupBox_ax_6";
            this.groupBox_ax_6.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_ax_6.Size = new System.Drawing.Size(40, 94);
            this.groupBox_ax_6.TabIndex = 26;
            this.groupBox_ax_6.TabStop = false;
            // 
            // radioButton_ax_6_0
            // 
            this.radioButton_ax_6_0.AutoSize = true;
            this.radioButton_ax_6_0.Checked = true;
            this.radioButton_ax_6_0.Location = new System.Drawing.Point(9, 52);
            this.radioButton_ax_6_0.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_ax_6_0.Name = "radioButton_ax_6_0";
            this.radioButton_ax_6_0.Size = new System.Drawing.Size(21, 20);
            this.radioButton_ax_6_0.TabIndex = 1;
            this.radioButton_ax_6_0.TabStop = true;
            this.radioButton_ax_6_0.UseVisualStyleBackColor = true;
            this.radioButton_ax_6_0.CheckedChanged += new System.EventHandler(this.radio_ax_click);
            // 
            // radioButton_ax_6_1
            // 
            this.radioButton_ax_6_1.AutoSize = true;
            this.radioButton_ax_6_1.Location = new System.Drawing.Point(9, 23);
            this.radioButton_ax_6_1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_ax_6_1.Name = "radioButton_ax_6_1";
            this.radioButton_ax_6_1.Size = new System.Drawing.Size(21, 20);
            this.radioButton_ax_6_1.TabIndex = 0;
            this.radioButton_ax_6_1.UseVisualStyleBackColor = true;
            this.radioButton_ax_6_1.CheckedChanged += new System.EventHandler(this.radio_ax_click);
            // 
            // groupBox_ax_5
            // 
            this.groupBox_ax_5.Controls.Add(this.radioButton_ax_5_0);
            this.groupBox_ax_5.Controls.Add(this.radioButton_ax_5_1);
            this.groupBox_ax_5.Location = new System.Drawing.Point(698, 72);
            this.groupBox_ax_5.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_ax_5.Name = "groupBox_ax_5";
            this.groupBox_ax_5.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_ax_5.Size = new System.Drawing.Size(40, 94);
            this.groupBox_ax_5.TabIndex = 27;
            this.groupBox_ax_5.TabStop = false;
            // 
            // radioButton_ax_5_0
            // 
            this.radioButton_ax_5_0.AutoSize = true;
            this.radioButton_ax_5_0.Checked = true;
            this.radioButton_ax_5_0.Location = new System.Drawing.Point(9, 52);
            this.radioButton_ax_5_0.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_ax_5_0.Name = "radioButton_ax_5_0";
            this.radioButton_ax_5_0.Size = new System.Drawing.Size(21, 20);
            this.radioButton_ax_5_0.TabIndex = 1;
            this.radioButton_ax_5_0.TabStop = true;
            this.radioButton_ax_5_0.UseVisualStyleBackColor = true;
            this.radioButton_ax_5_0.CheckedChanged += new System.EventHandler(this.radio_ax_click);
            // 
            // radioButton_ax_5_1
            // 
            this.radioButton_ax_5_1.AutoSize = true;
            this.radioButton_ax_5_1.Location = new System.Drawing.Point(9, 23);
            this.radioButton_ax_5_1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_ax_5_1.Name = "radioButton_ax_5_1";
            this.radioButton_ax_5_1.Size = new System.Drawing.Size(21, 20);
            this.radioButton_ax_5_1.TabIndex = 0;
            this.radioButton_ax_5_1.UseVisualStyleBackColor = true;
            this.radioButton_ax_5_1.CheckedChanged += new System.EventHandler(this.radio_ax_click);
            // 
            // groupBox_ax_7
            // 
            this.groupBox_ax_7.Controls.Add(this.radioButton_ax_7_0);
            this.groupBox_ax_7.Controls.Add(this.radioButton_ax_7_1);
            this.groupBox_ax_7.Location = new System.Drawing.Point(598, 72);
            this.groupBox_ax_7.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_ax_7.Name = "groupBox_ax_7";
            this.groupBox_ax_7.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_ax_7.Size = new System.Drawing.Size(40, 94);
            this.groupBox_ax_7.TabIndex = 20;
            this.groupBox_ax_7.TabStop = false;
            // 
            // radioButton_ax_7_0
            // 
            this.radioButton_ax_7_0.AutoSize = true;
            this.radioButton_ax_7_0.Checked = true;
            this.radioButton_ax_7_0.Location = new System.Drawing.Point(9, 52);
            this.radioButton_ax_7_0.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_ax_7_0.Name = "radioButton_ax_7_0";
            this.radioButton_ax_7_0.Size = new System.Drawing.Size(21, 20);
            this.radioButton_ax_7_0.TabIndex = 1;
            this.radioButton_ax_7_0.TabStop = true;
            this.radioButton_ax_7_0.UseVisualStyleBackColor = true;
            this.radioButton_ax_7_0.CheckedChanged += new System.EventHandler(this.radio_ax_click);
            // 
            // radioButton_ax_7_1
            // 
            this.radioButton_ax_7_1.AutoSize = true;
            this.radioButton_ax_7_1.Location = new System.Drawing.Point(9, 23);
            this.radioButton_ax_7_1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_ax_7_1.Name = "radioButton_ax_7_1";
            this.radioButton_ax_7_1.Size = new System.Drawing.Size(21, 20);
            this.radioButton_ax_7_1.TabIndex = 0;
            this.radioButton_ax_7_1.UseVisualStyleBackColor = true;
            this.radioButton_ax_7_1.CheckedChanged += new System.EventHandler(this.radio_ax_click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(994, 125);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(18, 20);
            this.label3.TabIndex = 29;
            this.label3.Text = "0";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(994, 95);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(18, 20);
            this.label4.TabIndex = 28;
            this.label4.Text = "1";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(994, 172);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(40, 20);
            this.label5.TabIndex = 30;
            this.label5.Text = "0-bit";
            // 
            // button_ax
            // 
            this.button_ax.Location = new System.Drawing.Point(608, 194);
            this.button_ax.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button_ax.Name = "button_ax";
            this.button_ax.Size = new System.Drawing.Size(112, 35);
            this.button_ax.TabIndex = 31;
            this.button_ax.Text = "WPISZ";
            this.button_ax.UseVisualStyleBackColor = true;
            this.button_ax.Click += new System.EventHandler(this.button_ax_Click);
            // 
            // label_al_wartosc
            // 
            this.label_al_wartosc.AutoSize = true;
            this.label_al_wartosc.BackColor = System.Drawing.SystemColors.ControlDark;
            this.label_al_wartosc.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_al_wartosc.Location = new System.Drawing.Point(592, 272);
            this.label_al_wartosc.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_al_wartosc.Name = "label_al_wartosc";
            this.label_al_wartosc.Size = new System.Drawing.Size(151, 33);
            this.label_al_wartosc.TabIndex = 33;
            this.label_al_wartosc.Text = "00000000";
            // 
            // label_ah_wartosc
            // 
            this.label_ah_wartosc.AutoSize = true;
            this.label_ah_wartosc.BackColor = System.Drawing.SystemColors.ControlDark;
            this.label_ah_wartosc.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_ah_wartosc.Location = new System.Drawing.Point(436, 272);
            this.label_ah_wartosc.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_ah_wartosc.Name = "label_ah_wartosc";
            this.label_ah_wartosc.Size = new System.Drawing.Size(151, 33);
            this.label_ah_wartosc.TabIndex = 34;
            this.label_ah_wartosc.Text = "00000000";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(402, 314);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(32, 20);
            this.label6.TabIndex = 35;
            this.label6.Text = "AH";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(742, 314);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(29, 20);
            this.label7.TabIndex = 36;
            this.label7.Text = "AL";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(1724, 314);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(29, 20);
            this.label8.TabIndex = 65;
            this.label8.Text = "BL";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(1383, 314);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(32, 20);
            this.label9.TabIndex = 64;
            this.label9.Text = "BH";
            // 
            // label_bh_wartosc
            // 
            this.label_bh_wartosc.AutoSize = true;
            this.label_bh_wartosc.BackColor = System.Drawing.SystemColors.ControlDark;
            this.label_bh_wartosc.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_bh_wartosc.Location = new System.Drawing.Point(1418, 272);
            this.label_bh_wartosc.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_bh_wartosc.Name = "label_bh_wartosc";
            this.label_bh_wartosc.Size = new System.Drawing.Size(151, 33);
            this.label_bh_wartosc.TabIndex = 63;
            this.label_bh_wartosc.Text = "00000000";
            // 
            // label_bl_wartosc
            // 
            this.label_bl_wartosc.AutoSize = true;
            this.label_bl_wartosc.BackColor = System.Drawing.SystemColors.ControlDark;
            this.label_bl_wartosc.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_bl_wartosc.Location = new System.Drawing.Point(1574, 272);
            this.label_bl_wartosc.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_bl_wartosc.Name = "label_bl_wartosc";
            this.label_bl_wartosc.Size = new System.Drawing.Size(151, 33);
            this.label_bl_wartosc.TabIndex = 62;
            this.label_bl_wartosc.Text = "00000000";
            // 
            // button_bx
            // 
            this.button_bx.Location = new System.Drawing.Point(1588, 194);
            this.button_bx.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button_bx.Name = "button_bx";
            this.button_bx.Size = new System.Drawing.Size(112, 35);
            this.button_bx.TabIndex = 61;
            this.button_bx.Text = "WPISZ";
            this.button_bx.UseVisualStyleBackColor = true;
            this.button_bx.Click += new System.EventHandler(this.button_bx_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(1976, 172);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(40, 20);
            this.label12.TabIndex = 60;
            this.label12.Text = "0-bit";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(1976, 125);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(18, 20);
            this.label13.TabIndex = 59;
            this.label13.Text = "0";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(1976, 95);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(18, 20);
            this.label14.TabIndex = 58;
            this.label14.Text = "1";
            // 
            // groupBox_bx_1
            // 
            this.groupBox_bx_1.Controls.Add(this.radioButton_bx_1_0);
            this.groupBox_bx_1.Controls.Add(this.radioButton_bx_1_1);
            this.groupBox_bx_1.Location = new System.Drawing.Point(1876, 72);
            this.groupBox_bx_1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_bx_1.Name = "groupBox_bx_1";
            this.groupBox_bx_1.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_bx_1.Size = new System.Drawing.Size(40, 94);
            this.groupBox_bx_1.TabIndex = 50;
            this.groupBox_bx_1.TabStop = false;
            // 
            // radioButton_bx_1_0
            // 
            this.radioButton_bx_1_0.AutoSize = true;
            this.radioButton_bx_1_0.Checked = true;
            this.radioButton_bx_1_0.Location = new System.Drawing.Point(9, 52);
            this.radioButton_bx_1_0.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_bx_1_0.Name = "radioButton_bx_1_0";
            this.radioButton_bx_1_0.Size = new System.Drawing.Size(21, 20);
            this.radioButton_bx_1_0.TabIndex = 1;
            this.radioButton_bx_1_0.TabStop = true;
            this.radioButton_bx_1_0.UseVisualStyleBackColor = true;
            this.radioButton_bx_1_0.CheckedChanged += new System.EventHandler(this.radio_bx_click);
            // 
            // radioButton_bx_1_1
            // 
            this.radioButton_bx_1_1.AutoSize = true;
            this.radioButton_bx_1_1.Location = new System.Drawing.Point(9, 23);
            this.radioButton_bx_1_1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_bx_1_1.Name = "radioButton_bx_1_1";
            this.radioButton_bx_1_1.Size = new System.Drawing.Size(21, 20);
            this.radioButton_bx_1_1.TabIndex = 0;
            this.radioButton_bx_1_1.UseVisualStyleBackColor = true;
            this.radioButton_bx_1_1.CheckedChanged += new System.EventHandler(this.radio_bx_click);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(1476, 37);
            this.label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(139, 29);
            this.label15.TabIndex = 51;
            this.label15.Text = "Rejestr BX";
            // 
            // groupBox_bx_0
            // 
            this.groupBox_bx_0.Controls.Add(this.radioButton_bx_0_0);
            this.groupBox_bx_0.Controls.Add(this.radioButton_bx_0_1);
            this.groupBox_bx_0.Location = new System.Drawing.Point(1926, 72);
            this.groupBox_bx_0.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_bx_0.Name = "groupBox_bx_0";
            this.groupBox_bx_0.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_bx_0.Size = new System.Drawing.Size(40, 94);
            this.groupBox_bx_0.TabIndex = 52;
            this.groupBox_bx_0.TabStop = false;
            // 
            // radioButton_bx_0_0
            // 
            this.radioButton_bx_0_0.AutoSize = true;
            this.radioButton_bx_0_0.Checked = true;
            this.radioButton_bx_0_0.Location = new System.Drawing.Point(9, 52);
            this.radioButton_bx_0_0.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_bx_0_0.Name = "radioButton_bx_0_0";
            this.radioButton_bx_0_0.Size = new System.Drawing.Size(21, 20);
            this.radioButton_bx_0_0.TabIndex = 1;
            this.radioButton_bx_0_0.TabStop = true;
            this.radioButton_bx_0_0.UseVisualStyleBackColor = true;
            this.radioButton_bx_0_0.CheckedChanged += new System.EventHandler(this.radio_bx_click);
            // 
            // radioButton_bx_0_1
            // 
            this.radioButton_bx_0_1.AutoSize = true;
            this.radioButton_bx_0_1.Location = new System.Drawing.Point(9, 23);
            this.radioButton_bx_0_1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_bx_0_1.Name = "radioButton_bx_0_1";
            this.radioButton_bx_0_1.Size = new System.Drawing.Size(21, 20);
            this.radioButton_bx_0_1.TabIndex = 0;
            this.radioButton_bx_0_1.UseVisualStyleBackColor = true;
            this.radioButton_bx_0_1.CheckedChanged += new System.EventHandler(this.radio_bx_click);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(1094, 172);
            this.label16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(49, 20);
            this.label16.TabIndex = 49;
            this.label16.Text = "15-bit";
            // 
            // groupBox_bx_4
            // 
            this.groupBox_bx_4.Controls.Add(this.radioButton_bx_4_0);
            this.groupBox_bx_4.Controls.Add(this.radioButton_bx_4_1);
            this.groupBox_bx_4.Location = new System.Drawing.Point(1728, 72);
            this.groupBox_bx_4.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_bx_4.Name = "groupBox_bx_4";
            this.groupBox_bx_4.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_bx_4.Size = new System.Drawing.Size(40, 94);
            this.groupBox_bx_4.TabIndex = 53;
            this.groupBox_bx_4.TabStop = false;
            // 
            // radioButton_bx_4_0
            // 
            this.radioButton_bx_4_0.AutoSize = true;
            this.radioButton_bx_4_0.Checked = true;
            this.radioButton_bx_4_0.Location = new System.Drawing.Point(9, 52);
            this.radioButton_bx_4_0.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_bx_4_0.Name = "radioButton_bx_4_0";
            this.radioButton_bx_4_0.Size = new System.Drawing.Size(21, 20);
            this.radioButton_bx_4_0.TabIndex = 1;
            this.radioButton_bx_4_0.TabStop = true;
            this.radioButton_bx_4_0.UseVisualStyleBackColor = true;
            this.radioButton_bx_4_0.CheckedChanged += new System.EventHandler(this.radio_bx_click);
            // 
            // radioButton_bx_4_1
            // 
            this.radioButton_bx_4_1.AutoSize = true;
            this.radioButton_bx_4_1.Location = new System.Drawing.Point(9, 23);
            this.radioButton_bx_4_1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_bx_4_1.Name = "radioButton_bx_4_1";
            this.radioButton_bx_4_1.Size = new System.Drawing.Size(21, 20);
            this.radioButton_bx_4_1.TabIndex = 0;
            this.radioButton_bx_4_1.UseVisualStyleBackColor = true;
            this.radioButton_bx_4_1.CheckedChanged += new System.EventHandler(this.radio_bx_click);
            // 
            // label_bx
            // 
            this.label_bx.AutoSize = true;
            this.label_bx.Location = new System.Drawing.Point(1359, 202);
            this.label_bx.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_bx.Name = "label_bx";
            this.label_bx.Size = new System.Drawing.Size(153, 20);
            this.label_bx.TabIndex = 47;
            this.label_bx.Text = "0000000000000000";
            // 
            // groupBox_bx_3
            // 
            this.groupBox_bx_3.Controls.Add(this.radioButton_bx_3_0);
            this.groupBox_bx_3.Controls.Add(this.radioButton_bx_3_1);
            this.groupBox_bx_3.Location = new System.Drawing.Point(1778, 72);
            this.groupBox_bx_3.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_bx_3.Name = "groupBox_bx_3";
            this.groupBox_bx_3.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_bx_3.Size = new System.Drawing.Size(40, 94);
            this.groupBox_bx_3.TabIndex = 54;
            this.groupBox_bx_3.TabStop = false;
            // 
            // radioButton_bx_3_0
            // 
            this.radioButton_bx_3_0.AutoSize = true;
            this.radioButton_bx_3_0.Checked = true;
            this.radioButton_bx_3_0.Location = new System.Drawing.Point(9, 52);
            this.radioButton_bx_3_0.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_bx_3_0.Name = "radioButton_bx_3_0";
            this.radioButton_bx_3_0.Size = new System.Drawing.Size(21, 20);
            this.radioButton_bx_3_0.TabIndex = 1;
            this.radioButton_bx_3_0.TabStop = true;
            this.radioButton_bx_3_0.UseVisualStyleBackColor = true;
            this.radioButton_bx_3_0.CheckedChanged += new System.EventHandler(this.radio_bx_click);
            // 
            // radioButton_bx_3_1
            // 
            this.radioButton_bx_3_1.AutoSize = true;
            this.radioButton_bx_3_1.Location = new System.Drawing.Point(9, 23);
            this.radioButton_bx_3_1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_bx_3_1.Name = "radioButton_bx_3_1";
            this.radioButton_bx_3_1.Size = new System.Drawing.Size(21, 20);
            this.radioButton_bx_3_1.TabIndex = 0;
            this.radioButton_bx_3_1.UseVisualStyleBackColor = true;
            this.radioButton_bx_3_1.CheckedChanged += new System.EventHandler(this.radio_bx_click);
            // 
            // groupBox_bx_9
            // 
            this.groupBox_bx_9.Controls.Add(this.radioButton_bx_9_0);
            this.groupBox_bx_9.Controls.Add(this.radioButton_bx_9_1);
            this.groupBox_bx_9.Location = new System.Drawing.Point(1454, 72);
            this.groupBox_bx_9.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_bx_9.Name = "groupBox_bx_9";
            this.groupBox_bx_9.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_bx_9.Size = new System.Drawing.Size(40, 94);
            this.groupBox_bx_9.TabIndex = 40;
            this.groupBox_bx_9.TabStop = false;
            // 
            // radioButton_bx_9_0
            // 
            this.radioButton_bx_9_0.AutoSize = true;
            this.radioButton_bx_9_0.Checked = true;
            this.radioButton_bx_9_0.Location = new System.Drawing.Point(9, 52);
            this.radioButton_bx_9_0.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_bx_9_0.Name = "radioButton_bx_9_0";
            this.radioButton_bx_9_0.Size = new System.Drawing.Size(21, 20);
            this.radioButton_bx_9_0.TabIndex = 1;
            this.radioButton_bx_9_0.TabStop = true;
            this.radioButton_bx_9_0.UseVisualStyleBackColor = true;
            this.radioButton_bx_9_0.CheckedChanged += new System.EventHandler(this.radio_bx_click);
            // 
            // radioButton_bx_9_1
            // 
            this.radioButton_bx_9_1.AutoSize = true;
            this.radioButton_bx_9_1.Location = new System.Drawing.Point(9, 23);
            this.radioButton_bx_9_1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_bx_9_1.Name = "radioButton_bx_9_1";
            this.radioButton_bx_9_1.Size = new System.Drawing.Size(21, 20);
            this.radioButton_bx_9_1.TabIndex = 0;
            this.radioButton_bx_9_1.UseVisualStyleBackColor = true;
            this.radioButton_bx_9_1.CheckedChanged += new System.EventHandler(this.radio_bx_click);
            // 
            // groupBox_bx_2
            // 
            this.groupBox_bx_2.Controls.Add(this.radioButton_bx_2_0);
            this.groupBox_bx_2.Controls.Add(this.radioButton_bx_2_1);
            this.groupBox_bx_2.Location = new System.Drawing.Point(1827, 72);
            this.groupBox_bx_2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_bx_2.Name = "groupBox_bx_2";
            this.groupBox_bx_2.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_bx_2.Size = new System.Drawing.Size(40, 94);
            this.groupBox_bx_2.TabIndex = 55;
            this.groupBox_bx_2.TabStop = false;
            // 
            // radioButton_bx_2_0
            // 
            this.radioButton_bx_2_0.AutoSize = true;
            this.radioButton_bx_2_0.Checked = true;
            this.radioButton_bx_2_0.Location = new System.Drawing.Point(9, 52);
            this.radioButton_bx_2_0.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_bx_2_0.Name = "radioButton_bx_2_0";
            this.radioButton_bx_2_0.Size = new System.Drawing.Size(21, 20);
            this.radioButton_bx_2_0.TabIndex = 1;
            this.radioButton_bx_2_0.TabStop = true;
            this.radioButton_bx_2_0.UseVisualStyleBackColor = true;
            this.radioButton_bx_2_0.CheckedChanged += new System.EventHandler(this.radio_bx_click);
            // 
            // radioButton_bx_2_1
            // 
            this.radioButton_bx_2_1.AutoSize = true;
            this.radioButton_bx_2_1.Location = new System.Drawing.Point(9, 23);
            this.radioButton_bx_2_1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_bx_2_1.Name = "radioButton_bx_2_1";
            this.radioButton_bx_2_1.Size = new System.Drawing.Size(21, 20);
            this.radioButton_bx_2_1.TabIndex = 0;
            this.radioButton_bx_2_1.UseVisualStyleBackColor = true;
            this.radioButton_bx_2_1.CheckedChanged += new System.EventHandler(this.radio_bx_click);
            // 
            // groupBox_bx_8
            // 
            this.groupBox_bx_8.Controls.Add(this.radioButton_bx_8_0);
            this.groupBox_bx_8.Controls.Add(this.radioButton_bx_8_1);
            this.groupBox_bx_8.Location = new System.Drawing.Point(1503, 72);
            this.groupBox_bx_8.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_bx_8.Name = "groupBox_bx_8";
            this.groupBox_bx_8.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_bx_8.Size = new System.Drawing.Size(40, 94);
            this.groupBox_bx_8.TabIndex = 43;
            this.groupBox_bx_8.TabStop = false;
            // 
            // radioButton_bx_8_0
            // 
            this.radioButton_bx_8_0.AutoSize = true;
            this.radioButton_bx_8_0.Checked = true;
            this.radioButton_bx_8_0.Location = new System.Drawing.Point(9, 52);
            this.radioButton_bx_8_0.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_bx_8_0.Name = "radioButton_bx_8_0";
            this.radioButton_bx_8_0.Size = new System.Drawing.Size(21, 20);
            this.radioButton_bx_8_0.TabIndex = 1;
            this.radioButton_bx_8_0.TabStop = true;
            this.radioButton_bx_8_0.UseVisualStyleBackColor = true;
            this.radioButton_bx_8_0.CheckedChanged += new System.EventHandler(this.radio_bx_click);
            // 
            // radioButton_bx_8_1
            // 
            this.radioButton_bx_8_1.AutoSize = true;
            this.radioButton_bx_8_1.Location = new System.Drawing.Point(9, 23);
            this.radioButton_bx_8_1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_bx_8_1.Name = "radioButton_bx_8_1";
            this.radioButton_bx_8_1.Size = new System.Drawing.Size(21, 20);
            this.radioButton_bx_8_1.TabIndex = 0;
            this.radioButton_bx_8_1.UseVisualStyleBackColor = true;
            this.radioButton_bx_8_1.CheckedChanged += new System.EventHandler(this.radio_bx_click);
            // 
            // groupBox_bx_6
            // 
            this.groupBox_bx_6.Controls.Add(this.radioButton_bx_6_0);
            this.groupBox_bx_6.Controls.Add(this.radioButton_bx_6_1);
            this.groupBox_bx_6.Location = new System.Drawing.Point(1629, 72);
            this.groupBox_bx_6.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_bx_6.Name = "groupBox_bx_6";
            this.groupBox_bx_6.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_bx_6.Size = new System.Drawing.Size(40, 94);
            this.groupBox_bx_6.TabIndex = 56;
            this.groupBox_bx_6.TabStop = false;
            // 
            // radioButton_bx_6_0
            // 
            this.radioButton_bx_6_0.AutoSize = true;
            this.radioButton_bx_6_0.Checked = true;
            this.radioButton_bx_6_0.Location = new System.Drawing.Point(9, 52);
            this.radioButton_bx_6_0.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_bx_6_0.Name = "radioButton_bx_6_0";
            this.radioButton_bx_6_0.Size = new System.Drawing.Size(21, 20);
            this.radioButton_bx_6_0.TabIndex = 1;
            this.radioButton_bx_6_0.TabStop = true;
            this.radioButton_bx_6_0.UseVisualStyleBackColor = true;
            this.radioButton_bx_6_0.CheckedChanged += new System.EventHandler(this.radio_bx_click);
            // 
            // radioButton_bx_6_1
            // 
            this.radioButton_bx_6_1.AutoSize = true;
            this.radioButton_bx_6_1.Location = new System.Drawing.Point(9, 23);
            this.radioButton_bx_6_1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_bx_6_1.Name = "radioButton_bx_6_1";
            this.radioButton_bx_6_1.Size = new System.Drawing.Size(21, 20);
            this.radioButton_bx_6_1.TabIndex = 0;
            this.radioButton_bx_6_1.UseVisualStyleBackColor = true;
            this.radioButton_bx_6_1.CheckedChanged += new System.EventHandler(this.radio_bx_click);
            // 
            // groupBox_bx_12
            // 
            this.groupBox_bx_12.Controls.Add(this.radioButton_bx_12_0);
            this.groupBox_bx_12.Controls.Add(this.radioButton_bx_12_1);
            this.groupBox_bx_12.Location = new System.Drawing.Point(1305, 72);
            this.groupBox_bx_12.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_bx_12.Name = "groupBox_bx_12";
            this.groupBox_bx_12.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_bx_12.Size = new System.Drawing.Size(40, 94);
            this.groupBox_bx_12.TabIndex = 41;
            this.groupBox_bx_12.TabStop = false;
            // 
            // radioButton_bx_12_0
            // 
            this.radioButton_bx_12_0.AutoSize = true;
            this.radioButton_bx_12_0.Checked = true;
            this.radioButton_bx_12_0.Location = new System.Drawing.Point(9, 52);
            this.radioButton_bx_12_0.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_bx_12_0.Name = "radioButton_bx_12_0";
            this.radioButton_bx_12_0.Size = new System.Drawing.Size(21, 20);
            this.radioButton_bx_12_0.TabIndex = 1;
            this.radioButton_bx_12_0.TabStop = true;
            this.radioButton_bx_12_0.UseVisualStyleBackColor = true;
            this.radioButton_bx_12_0.CheckedChanged += new System.EventHandler(this.radio_bx_click);
            // 
            // radioButton_bx_12_1
            // 
            this.radioButton_bx_12_1.AutoSize = true;
            this.radioButton_bx_12_1.Location = new System.Drawing.Point(9, 23);
            this.radioButton_bx_12_1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_bx_12_1.Name = "radioButton_bx_12_1";
            this.radioButton_bx_12_1.Size = new System.Drawing.Size(21, 20);
            this.radioButton_bx_12_1.TabIndex = 0;
            this.radioButton_bx_12_1.UseVisualStyleBackColor = true;
            this.radioButton_bx_12_1.CheckedChanged += new System.EventHandler(this.radio_bx_click);
            // 
            // groupBox_bx_5
            // 
            this.groupBox_bx_5.Controls.Add(this.radioButton_bx_5_0);
            this.groupBox_bx_5.Controls.Add(this.radioButton_bx_5_1);
            this.groupBox_bx_5.Location = new System.Drawing.Point(1678, 72);
            this.groupBox_bx_5.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_bx_5.Name = "groupBox_bx_5";
            this.groupBox_bx_5.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_bx_5.Size = new System.Drawing.Size(40, 94);
            this.groupBox_bx_5.TabIndex = 57;
            this.groupBox_bx_5.TabStop = false;
            // 
            // radioButton_bx_5_0
            // 
            this.radioButton_bx_5_0.AutoSize = true;
            this.radioButton_bx_5_0.Checked = true;
            this.radioButton_bx_5_0.Location = new System.Drawing.Point(9, 52);
            this.radioButton_bx_5_0.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_bx_5_0.Name = "radioButton_bx_5_0";
            this.radioButton_bx_5_0.Size = new System.Drawing.Size(21, 20);
            this.radioButton_bx_5_0.TabIndex = 1;
            this.radioButton_bx_5_0.TabStop = true;
            this.radioButton_bx_5_0.UseVisualStyleBackColor = true;
            this.radioButton_bx_5_0.CheckedChanged += new System.EventHandler(this.radio_bx_click);
            // 
            // radioButton_bx_5_1
            // 
            this.radioButton_bx_5_1.AutoSize = true;
            this.radioButton_bx_5_1.Location = new System.Drawing.Point(9, 23);
            this.radioButton_bx_5_1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_bx_5_1.Name = "radioButton_bx_5_1";
            this.radioButton_bx_5_1.Size = new System.Drawing.Size(21, 20);
            this.radioButton_bx_5_1.TabIndex = 0;
            this.radioButton_bx_5_1.UseVisualStyleBackColor = true;
            this.radioButton_bx_5_1.CheckedChanged += new System.EventHandler(this.radio_bx_click);
            // 
            // groupBox_bx_11
            // 
            this.groupBox_bx_11.Controls.Add(this.radioButton_bx_11_0);
            this.groupBox_bx_11.Controls.Add(this.radioButton_bx_11_1);
            this.groupBox_bx_11.Location = new System.Drawing.Point(1354, 72);
            this.groupBox_bx_11.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_bx_11.Name = "groupBox_bx_11";
            this.groupBox_bx_11.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_bx_11.Size = new System.Drawing.Size(40, 94);
            this.groupBox_bx_11.TabIndex = 42;
            this.groupBox_bx_11.TabStop = false;
            // 
            // radioButton_bx_11_0
            // 
            this.radioButton_bx_11_0.AutoSize = true;
            this.radioButton_bx_11_0.Checked = true;
            this.radioButton_bx_11_0.Location = new System.Drawing.Point(9, 52);
            this.radioButton_bx_11_0.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_bx_11_0.Name = "radioButton_bx_11_0";
            this.radioButton_bx_11_0.Size = new System.Drawing.Size(21, 20);
            this.radioButton_bx_11_0.TabIndex = 1;
            this.radioButton_bx_11_0.TabStop = true;
            this.radioButton_bx_11_0.UseVisualStyleBackColor = true;
            this.radioButton_bx_11_0.CheckedChanged += new System.EventHandler(this.radio_bx_click);
            // 
            // radioButton_bx_11_1
            // 
            this.radioButton_bx_11_1.AutoSize = true;
            this.radioButton_bx_11_1.Location = new System.Drawing.Point(9, 23);
            this.radioButton_bx_11_1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_bx_11_1.Name = "radioButton_bx_11_1";
            this.radioButton_bx_11_1.Size = new System.Drawing.Size(21, 20);
            this.radioButton_bx_11_1.TabIndex = 0;
            this.radioButton_bx_11_1.UseVisualStyleBackColor = true;
            this.radioButton_bx_11_1.CheckedChanged += new System.EventHandler(this.radio_bx_click);
            // 
            // groupBox_bx_7
            // 
            this.groupBox_bx_7.Controls.Add(this.radioButton_bx_7_0);
            this.groupBox_bx_7.Controls.Add(this.radioButton_bx_7_1);
            this.groupBox_bx_7.Location = new System.Drawing.Point(1580, 72);
            this.groupBox_bx_7.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_bx_7.Name = "groupBox_bx_7";
            this.groupBox_bx_7.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_bx_7.Size = new System.Drawing.Size(40, 94);
            this.groupBox_bx_7.TabIndex = 48;
            this.groupBox_bx_7.TabStop = false;
            // 
            // radioButton_bx_7_0
            // 
            this.radioButton_bx_7_0.AutoSize = true;
            this.radioButton_bx_7_0.Checked = true;
            this.radioButton_bx_7_0.Location = new System.Drawing.Point(9, 52);
            this.radioButton_bx_7_0.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_bx_7_0.Name = "radioButton_bx_7_0";
            this.radioButton_bx_7_0.Size = new System.Drawing.Size(21, 20);
            this.radioButton_bx_7_0.TabIndex = 1;
            this.radioButton_bx_7_0.TabStop = true;
            this.radioButton_bx_7_0.UseVisualStyleBackColor = true;
            this.radioButton_bx_7_0.CheckedChanged += new System.EventHandler(this.radio_bx_click);
            // 
            // radioButton_bx_7_1
            // 
            this.radioButton_bx_7_1.AutoSize = true;
            this.radioButton_bx_7_1.Location = new System.Drawing.Point(9, 23);
            this.radioButton_bx_7_1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_bx_7_1.Name = "radioButton_bx_7_1";
            this.radioButton_bx_7_1.Size = new System.Drawing.Size(21, 20);
            this.radioButton_bx_7_1.TabIndex = 0;
            this.radioButton_bx_7_1.UseVisualStyleBackColor = true;
            this.radioButton_bx_7_1.CheckedChanged += new System.EventHandler(this.radio_bx_click);
            // 
            // groupBox_bx_10
            // 
            this.groupBox_bx_10.Controls.Add(this.radioButton_bx_10_0);
            this.groupBox_bx_10.Controls.Add(this.radioButton_bx_10_1);
            this.groupBox_bx_10.Location = new System.Drawing.Point(1404, 72);
            this.groupBox_bx_10.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_bx_10.Name = "groupBox_bx_10";
            this.groupBox_bx_10.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_bx_10.Size = new System.Drawing.Size(40, 94);
            this.groupBox_bx_10.TabIndex = 44;
            this.groupBox_bx_10.TabStop = false;
            // 
            // radioButton_bx_10_0
            // 
            this.radioButton_bx_10_0.AutoSize = true;
            this.radioButton_bx_10_0.Checked = true;
            this.radioButton_bx_10_0.Location = new System.Drawing.Point(9, 52);
            this.radioButton_bx_10_0.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_bx_10_0.Name = "radioButton_bx_10_0";
            this.radioButton_bx_10_0.Size = new System.Drawing.Size(21, 20);
            this.radioButton_bx_10_0.TabIndex = 1;
            this.radioButton_bx_10_0.TabStop = true;
            this.radioButton_bx_10_0.UseVisualStyleBackColor = true;
            this.radioButton_bx_10_0.CheckedChanged += new System.EventHandler(this.radio_bx_click);
            // 
            // radioButton_bx_10_1
            // 
            this.radioButton_bx_10_1.AutoSize = true;
            this.radioButton_bx_10_1.Location = new System.Drawing.Point(9, 23);
            this.radioButton_bx_10_1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_bx_10_1.Name = "radioButton_bx_10_1";
            this.radioButton_bx_10_1.Size = new System.Drawing.Size(21, 20);
            this.radioButton_bx_10_1.TabIndex = 0;
            this.radioButton_bx_10_1.UseVisualStyleBackColor = true;
            this.radioButton_bx_10_1.CheckedChanged += new System.EventHandler(this.radio_bx_click);
            // 
            // groupBox_bx_14
            // 
            this.groupBox_bx_14.Controls.Add(this.radioButton_bx_14_0);
            this.groupBox_bx_14.Controls.Add(this.radioButton_bx_14_1);
            this.groupBox_bx_14.Location = new System.Drawing.Point(1206, 72);
            this.groupBox_bx_14.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_bx_14.Name = "groupBox_bx_14";
            this.groupBox_bx_14.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_bx_14.Size = new System.Drawing.Size(40, 94);
            this.groupBox_bx_14.TabIndex = 45;
            this.groupBox_bx_14.TabStop = false;
            // 
            // radioButton_bx_14_0
            // 
            this.radioButton_bx_14_0.AutoSize = true;
            this.radioButton_bx_14_0.Checked = true;
            this.radioButton_bx_14_0.Location = new System.Drawing.Point(9, 52);
            this.radioButton_bx_14_0.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_bx_14_0.Name = "radioButton_bx_14_0";
            this.radioButton_bx_14_0.Size = new System.Drawing.Size(21, 20);
            this.radioButton_bx_14_0.TabIndex = 1;
            this.radioButton_bx_14_0.TabStop = true;
            this.radioButton_bx_14_0.UseVisualStyleBackColor = true;
            this.radioButton_bx_14_0.CheckedChanged += new System.EventHandler(this.radio_bx_click);
            // 
            // radioButton_bx_14_1
            // 
            this.radioButton_bx_14_1.AutoSize = true;
            this.radioButton_bx_14_1.Location = new System.Drawing.Point(9, 23);
            this.radioButton_bx_14_1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_bx_14_1.Name = "radioButton_bx_14_1";
            this.radioButton_bx_14_1.Size = new System.Drawing.Size(21, 20);
            this.radioButton_bx_14_1.TabIndex = 0;
            this.radioButton_bx_14_1.UseVisualStyleBackColor = true;
            this.radioButton_bx_14_1.CheckedChanged += new System.EventHandler(this.radio_bx_click);
            // 
            // groupBox_bx_13
            // 
            this.groupBox_bx_13.Controls.Add(this.radioButton_bx_13_0);
            this.groupBox_bx_13.Controls.Add(this.radioButton_bx_13_1);
            this.groupBox_bx_13.Location = new System.Drawing.Point(1256, 72);
            this.groupBox_bx_13.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_bx_13.Name = "groupBox_bx_13";
            this.groupBox_bx_13.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_bx_13.Size = new System.Drawing.Size(40, 94);
            this.groupBox_bx_13.TabIndex = 46;
            this.groupBox_bx_13.TabStop = false;
            // 
            // radioButton_bx_13_0
            // 
            this.radioButton_bx_13_0.AutoSize = true;
            this.radioButton_bx_13_0.Checked = true;
            this.radioButton_bx_13_0.Location = new System.Drawing.Point(9, 52);
            this.radioButton_bx_13_0.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_bx_13_0.Name = "radioButton_bx_13_0";
            this.radioButton_bx_13_0.Size = new System.Drawing.Size(21, 20);
            this.radioButton_bx_13_0.TabIndex = 1;
            this.radioButton_bx_13_0.TabStop = true;
            this.radioButton_bx_13_0.UseVisualStyleBackColor = true;
            this.radioButton_bx_13_0.CheckedChanged += new System.EventHandler(this.radio_bx_click);
            // 
            // radioButton_bx_13_1
            // 
            this.radioButton_bx_13_1.AutoSize = true;
            this.radioButton_bx_13_1.Location = new System.Drawing.Point(9, 23);
            this.radioButton_bx_13_1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_bx_13_1.Name = "radioButton_bx_13_1";
            this.radioButton_bx_13_1.Size = new System.Drawing.Size(21, 20);
            this.radioButton_bx_13_1.TabIndex = 0;
            this.radioButton_bx_13_1.UseVisualStyleBackColor = true;
            this.radioButton_bx_13_1.CheckedChanged += new System.EventHandler(this.radio_bx_click);
            // 
            // groupBox_bx_15
            // 
            this.groupBox_bx_15.Controls.Add(this.radioButton_bx_15_0);
            this.groupBox_bx_15.Controls.Add(this.radioButton_bx_15_1);
            this.groupBox_bx_15.Location = new System.Drawing.Point(1156, 72);
            this.groupBox_bx_15.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_bx_15.Name = "groupBox_bx_15";
            this.groupBox_bx_15.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_bx_15.Size = new System.Drawing.Size(40, 94);
            this.groupBox_bx_15.TabIndex = 39;
            this.groupBox_bx_15.TabStop = false;
            // 
            // radioButton_bx_15_0
            // 
            this.radioButton_bx_15_0.AutoSize = true;
            this.radioButton_bx_15_0.Checked = true;
            this.radioButton_bx_15_0.Location = new System.Drawing.Point(9, 52);
            this.radioButton_bx_15_0.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_bx_15_0.Name = "radioButton_bx_15_0";
            this.radioButton_bx_15_0.Size = new System.Drawing.Size(21, 20);
            this.radioButton_bx_15_0.TabIndex = 1;
            this.radioButton_bx_15_0.TabStop = true;
            this.radioButton_bx_15_0.UseVisualStyleBackColor = true;
            this.radioButton_bx_15_0.CheckedChanged += new System.EventHandler(this.radio_bx_click);
            // 
            // radioButton_bx_15_1
            // 
            this.radioButton_bx_15_1.AutoSize = true;
            this.radioButton_bx_15_1.Location = new System.Drawing.Point(9, 23);
            this.radioButton_bx_15_1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_bx_15_1.Name = "radioButton_bx_15_1";
            this.radioButton_bx_15_1.Size = new System.Drawing.Size(21, 20);
            this.radioButton_bx_15_1.TabIndex = 0;
            this.radioButton_bx_15_1.UseVisualStyleBackColor = true;
            this.radioButton_bx_15_1.CheckedChanged += new System.EventHandler(this.radio_bx_click);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(1128, 125);
            this.label18.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(18, 20);
            this.label18.TabIndex = 38;
            this.label18.Text = "0";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(1128, 95);
            this.label19.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(18, 20);
            this.label19.TabIndex = 37;
            this.label19.Text = "1";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(1724, 651);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(30, 20);
            this.label10.TabIndex = 123;
            this.label10.Text = "DL";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(1383, 651);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(33, 20);
            this.label11.TabIndex = 122;
            this.label11.Text = "DH";
            // 
            // label_dh_wartosc
            // 
            this.label_dh_wartosc.AutoSize = true;
            this.label_dh_wartosc.BackColor = System.Drawing.SystemColors.ControlDark;
            this.label_dh_wartosc.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_dh_wartosc.Location = new System.Drawing.Point(1418, 609);
            this.label_dh_wartosc.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_dh_wartosc.Name = "label_dh_wartosc";
            this.label_dh_wartosc.Size = new System.Drawing.Size(151, 33);
            this.label_dh_wartosc.TabIndex = 121;
            this.label_dh_wartosc.Text = "00000000";
            // 
            // label_dl_wartosc
            // 
            this.label_dl_wartosc.AutoSize = true;
            this.label_dl_wartosc.BackColor = System.Drawing.SystemColors.ControlDark;
            this.label_dl_wartosc.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_dl_wartosc.Location = new System.Drawing.Point(1574, 609);
            this.label_dl_wartosc.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_dl_wartosc.Name = "label_dl_wartosc";
            this.label_dl_wartosc.Size = new System.Drawing.Size(151, 33);
            this.label_dl_wartosc.TabIndex = 120;
            this.label_dl_wartosc.Text = "00000000";
            // 
            // button_dx
            // 
            this.button_dx.Location = new System.Drawing.Point(1588, 531);
            this.button_dx.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button_dx.Name = "button_dx";
            this.button_dx.Size = new System.Drawing.Size(112, 35);
            this.button_dx.TabIndex = 119;
            this.button_dx.Text = "WPISZ";
            this.button_dx.UseVisualStyleBackColor = true;
            this.button_dx.Click += new System.EventHandler(this.button_dx_Click);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(1976, 509);
            this.label21.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(40, 20);
            this.label21.TabIndex = 118;
            this.label21.Text = "0-bit";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(1976, 462);
            this.label22.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(18, 20);
            this.label22.TabIndex = 117;
            this.label22.Text = "0";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(1976, 432);
            this.label23.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(18, 20);
            this.label23.TabIndex = 116;
            this.label23.Text = "1";
            // 
            // groupBox_dx_1
            // 
            this.groupBox_dx_1.Controls.Add(this.radioButton_dx_1_0);
            this.groupBox_dx_1.Controls.Add(this.radioButton_dx_1_1);
            this.groupBox_dx_1.Location = new System.Drawing.Point(1876, 409);
            this.groupBox_dx_1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_dx_1.Name = "groupBox_dx_1";
            this.groupBox_dx_1.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_dx_1.Size = new System.Drawing.Size(40, 94);
            this.groupBox_dx_1.TabIndex = 108;
            this.groupBox_dx_1.TabStop = false;
            // 
            // radioButton_dx_1_0
            // 
            this.radioButton_dx_1_0.AutoSize = true;
            this.radioButton_dx_1_0.Checked = true;
            this.radioButton_dx_1_0.Location = new System.Drawing.Point(9, 52);
            this.radioButton_dx_1_0.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_dx_1_0.Name = "radioButton_dx_1_0";
            this.radioButton_dx_1_0.Size = new System.Drawing.Size(21, 20);
            this.radioButton_dx_1_0.TabIndex = 1;
            this.radioButton_dx_1_0.TabStop = true;
            this.radioButton_dx_1_0.UseVisualStyleBackColor = true;
            this.radioButton_dx_1_0.CheckedChanged += new System.EventHandler(this.radio_dx_click);
            // 
            // radioButton_dx_1_1
            // 
            this.radioButton_dx_1_1.AutoSize = true;
            this.radioButton_dx_1_1.Location = new System.Drawing.Point(9, 23);
            this.radioButton_dx_1_1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_dx_1_1.Name = "radioButton_dx_1_1";
            this.radioButton_dx_1_1.Size = new System.Drawing.Size(21, 20);
            this.radioButton_dx_1_1.TabIndex = 0;
            this.radioButton_dx_1_1.UseVisualStyleBackColor = true;
            this.radioButton_dx_1_1.CheckedChanged += new System.EventHandler(this.radio_dx_click);
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(1476, 374);
            this.label24.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(140, 29);
            this.label24.TabIndex = 109;
            this.label24.Text = "Rejestr DX";
            // 
            // groupBox_dx_0
            // 
            this.groupBox_dx_0.Controls.Add(this.radioButton_dx_0_0);
            this.groupBox_dx_0.Controls.Add(this.radioButton_dx_0_1);
            this.groupBox_dx_0.Location = new System.Drawing.Point(1926, 409);
            this.groupBox_dx_0.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_dx_0.Name = "groupBox_dx_0";
            this.groupBox_dx_0.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_dx_0.Size = new System.Drawing.Size(40, 94);
            this.groupBox_dx_0.TabIndex = 110;
            this.groupBox_dx_0.TabStop = false;
            // 
            // radioButton_dx_0_0
            // 
            this.radioButton_dx_0_0.AutoSize = true;
            this.radioButton_dx_0_0.Checked = true;
            this.radioButton_dx_0_0.Location = new System.Drawing.Point(9, 52);
            this.radioButton_dx_0_0.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_dx_0_0.Name = "radioButton_dx_0_0";
            this.radioButton_dx_0_0.Size = new System.Drawing.Size(21, 20);
            this.radioButton_dx_0_0.TabIndex = 1;
            this.radioButton_dx_0_0.TabStop = true;
            this.radioButton_dx_0_0.UseVisualStyleBackColor = true;
            this.radioButton_dx_0_0.CheckedChanged += new System.EventHandler(this.radio_dx_click);
            // 
            // radioButton_dx_0_1
            // 
            this.radioButton_dx_0_1.AutoSize = true;
            this.radioButton_dx_0_1.Location = new System.Drawing.Point(9, 23);
            this.radioButton_dx_0_1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_dx_0_1.Name = "radioButton_dx_0_1";
            this.radioButton_dx_0_1.Size = new System.Drawing.Size(21, 20);
            this.radioButton_dx_0_1.TabIndex = 0;
            this.radioButton_dx_0_1.UseVisualStyleBackColor = true;
            this.radioButton_dx_0_1.CheckedChanged += new System.EventHandler(this.radio_dx_click);
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(1094, 509);
            this.label25.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(49, 20);
            this.label25.TabIndex = 107;
            this.label25.Text = "15-bit";
            // 
            // groupBox_dx_4
            // 
            this.groupBox_dx_4.Controls.Add(this.radioButton_dx_4_0);
            this.groupBox_dx_4.Controls.Add(this.radioButton_dx_4_1);
            this.groupBox_dx_4.Location = new System.Drawing.Point(1728, 409);
            this.groupBox_dx_4.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_dx_4.Name = "groupBox_dx_4";
            this.groupBox_dx_4.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_dx_4.Size = new System.Drawing.Size(40, 94);
            this.groupBox_dx_4.TabIndex = 111;
            this.groupBox_dx_4.TabStop = false;
            // 
            // radioButton_dx_4_0
            // 
            this.radioButton_dx_4_0.AutoSize = true;
            this.radioButton_dx_4_0.Checked = true;
            this.radioButton_dx_4_0.Location = new System.Drawing.Point(9, 52);
            this.radioButton_dx_4_0.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_dx_4_0.Name = "radioButton_dx_4_0";
            this.radioButton_dx_4_0.Size = new System.Drawing.Size(21, 20);
            this.radioButton_dx_4_0.TabIndex = 1;
            this.radioButton_dx_4_0.TabStop = true;
            this.radioButton_dx_4_0.UseVisualStyleBackColor = true;
            this.radioButton_dx_4_0.CheckedChanged += new System.EventHandler(this.radio_dx_click);
            // 
            // radioButton_dx_4_1
            // 
            this.radioButton_dx_4_1.AutoSize = true;
            this.radioButton_dx_4_1.Location = new System.Drawing.Point(9, 23);
            this.radioButton_dx_4_1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_dx_4_1.Name = "radioButton_dx_4_1";
            this.radioButton_dx_4_1.Size = new System.Drawing.Size(21, 20);
            this.radioButton_dx_4_1.TabIndex = 0;
            this.radioButton_dx_4_1.UseVisualStyleBackColor = true;
            this.radioButton_dx_4_1.CheckedChanged += new System.EventHandler(this.radio_dx_click);
            // 
            // label_dx
            // 
            this.label_dx.AutoSize = true;
            this.label_dx.Location = new System.Drawing.Point(1359, 538);
            this.label_dx.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_dx.Name = "label_dx";
            this.label_dx.Size = new System.Drawing.Size(153, 20);
            this.label_dx.TabIndex = 105;
            this.label_dx.Text = "0000000000000000";
            // 
            // groupBox_dx_3
            // 
            this.groupBox_dx_3.Controls.Add(this.radioButton_dx_3_0);
            this.groupBox_dx_3.Controls.Add(this.radioButton_dx_3_1);
            this.groupBox_dx_3.Location = new System.Drawing.Point(1778, 409);
            this.groupBox_dx_3.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_dx_3.Name = "groupBox_dx_3";
            this.groupBox_dx_3.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_dx_3.Size = new System.Drawing.Size(40, 94);
            this.groupBox_dx_3.TabIndex = 112;
            this.groupBox_dx_3.TabStop = false;
            // 
            // radioButton_dx_3_0
            // 
            this.radioButton_dx_3_0.AutoSize = true;
            this.radioButton_dx_3_0.Checked = true;
            this.radioButton_dx_3_0.Location = new System.Drawing.Point(9, 52);
            this.radioButton_dx_3_0.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_dx_3_0.Name = "radioButton_dx_3_0";
            this.radioButton_dx_3_0.Size = new System.Drawing.Size(21, 20);
            this.radioButton_dx_3_0.TabIndex = 1;
            this.radioButton_dx_3_0.TabStop = true;
            this.radioButton_dx_3_0.UseVisualStyleBackColor = true;
            this.radioButton_dx_3_0.CheckedChanged += new System.EventHandler(this.radio_dx_click);
            // 
            // radioButton_dx_3_1
            // 
            this.radioButton_dx_3_1.AutoSize = true;
            this.radioButton_dx_3_1.Location = new System.Drawing.Point(9, 23);
            this.radioButton_dx_3_1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_dx_3_1.Name = "radioButton_dx_3_1";
            this.radioButton_dx_3_1.Size = new System.Drawing.Size(21, 20);
            this.radioButton_dx_3_1.TabIndex = 0;
            this.radioButton_dx_3_1.UseVisualStyleBackColor = true;
            this.radioButton_dx_3_1.CheckedChanged += new System.EventHandler(this.radio_dx_click);
            // 
            // groupBox_dx_9
            // 
            this.groupBox_dx_9.Controls.Add(this.radioButton_dx_9_0);
            this.groupBox_dx_9.Controls.Add(this.radioButton_dx_9_1);
            this.groupBox_dx_9.Location = new System.Drawing.Point(1454, 409);
            this.groupBox_dx_9.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_dx_9.Name = "groupBox_dx_9";
            this.groupBox_dx_9.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_dx_9.Size = new System.Drawing.Size(40, 94);
            this.groupBox_dx_9.TabIndex = 98;
            this.groupBox_dx_9.TabStop = false;
            // 
            // radioButton_dx_9_0
            // 
            this.radioButton_dx_9_0.AutoSize = true;
            this.radioButton_dx_9_0.Checked = true;
            this.radioButton_dx_9_0.Location = new System.Drawing.Point(9, 52);
            this.radioButton_dx_9_0.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_dx_9_0.Name = "radioButton_dx_9_0";
            this.radioButton_dx_9_0.Size = new System.Drawing.Size(21, 20);
            this.radioButton_dx_9_0.TabIndex = 1;
            this.radioButton_dx_9_0.TabStop = true;
            this.radioButton_dx_9_0.UseVisualStyleBackColor = true;
            this.radioButton_dx_9_0.CheckedChanged += new System.EventHandler(this.radio_dx_click);
            // 
            // radioButton_dx_9_1
            // 
            this.radioButton_dx_9_1.AutoSize = true;
            this.radioButton_dx_9_1.Location = new System.Drawing.Point(9, 23);
            this.radioButton_dx_9_1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_dx_9_1.Name = "radioButton_dx_9_1";
            this.radioButton_dx_9_1.Size = new System.Drawing.Size(21, 20);
            this.radioButton_dx_9_1.TabIndex = 0;
            this.radioButton_dx_9_1.UseVisualStyleBackColor = true;
            this.radioButton_dx_9_1.CheckedChanged += new System.EventHandler(this.radio_dx_click);
            // 
            // groupBox_dx_2
            // 
            this.groupBox_dx_2.Controls.Add(this.radioButton_dx_2_0);
            this.groupBox_dx_2.Controls.Add(this.radioButton_dx_2_1);
            this.groupBox_dx_2.Location = new System.Drawing.Point(1827, 409);
            this.groupBox_dx_2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_dx_2.Name = "groupBox_dx_2";
            this.groupBox_dx_2.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_dx_2.Size = new System.Drawing.Size(40, 94);
            this.groupBox_dx_2.TabIndex = 113;
            this.groupBox_dx_2.TabStop = false;
            // 
            // radioButton_dx_2_0
            // 
            this.radioButton_dx_2_0.AutoSize = true;
            this.radioButton_dx_2_0.Checked = true;
            this.radioButton_dx_2_0.Location = new System.Drawing.Point(9, 52);
            this.radioButton_dx_2_0.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_dx_2_0.Name = "radioButton_dx_2_0";
            this.radioButton_dx_2_0.Size = new System.Drawing.Size(21, 20);
            this.radioButton_dx_2_0.TabIndex = 1;
            this.radioButton_dx_2_0.TabStop = true;
            this.radioButton_dx_2_0.UseVisualStyleBackColor = true;
            this.radioButton_dx_2_0.CheckedChanged += new System.EventHandler(this.radio_dx_click);
            // 
            // radioButton_dx_2_1
            // 
            this.radioButton_dx_2_1.AutoSize = true;
            this.radioButton_dx_2_1.Location = new System.Drawing.Point(9, 23);
            this.radioButton_dx_2_1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_dx_2_1.Name = "radioButton_dx_2_1";
            this.radioButton_dx_2_1.Size = new System.Drawing.Size(21, 20);
            this.radioButton_dx_2_1.TabIndex = 0;
            this.radioButton_dx_2_1.UseVisualStyleBackColor = true;
            this.radioButton_dx_2_1.CheckedChanged += new System.EventHandler(this.radio_dx_click);
            // 
            // groupBox_dx_8
            // 
            this.groupBox_dx_8.Controls.Add(this.radioButton_dx_8_0);
            this.groupBox_dx_8.Controls.Add(this.radioButton_dx_8_1);
            this.groupBox_dx_8.Location = new System.Drawing.Point(1503, 409);
            this.groupBox_dx_8.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_dx_8.Name = "groupBox_dx_8";
            this.groupBox_dx_8.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_dx_8.Size = new System.Drawing.Size(40, 94);
            this.groupBox_dx_8.TabIndex = 101;
            this.groupBox_dx_8.TabStop = false;
            // 
            // radioButton_dx_8_0
            // 
            this.radioButton_dx_8_0.AutoSize = true;
            this.radioButton_dx_8_0.Checked = true;
            this.radioButton_dx_8_0.Location = new System.Drawing.Point(9, 52);
            this.radioButton_dx_8_0.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_dx_8_0.Name = "radioButton_dx_8_0";
            this.radioButton_dx_8_0.Size = new System.Drawing.Size(21, 20);
            this.radioButton_dx_8_0.TabIndex = 1;
            this.radioButton_dx_8_0.TabStop = true;
            this.radioButton_dx_8_0.UseVisualStyleBackColor = true;
            this.radioButton_dx_8_0.CheckedChanged += new System.EventHandler(this.radio_dx_click);
            // 
            // radioButton_dx_8_1
            // 
            this.radioButton_dx_8_1.AutoSize = true;
            this.radioButton_dx_8_1.Location = new System.Drawing.Point(9, 23);
            this.radioButton_dx_8_1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_dx_8_1.Name = "radioButton_dx_8_1";
            this.radioButton_dx_8_1.Size = new System.Drawing.Size(21, 20);
            this.radioButton_dx_8_1.TabIndex = 0;
            this.radioButton_dx_8_1.UseVisualStyleBackColor = true;
            this.radioButton_dx_8_1.CheckedChanged += new System.EventHandler(this.radio_dx_click);
            // 
            // groupBox_dx_6
            // 
            this.groupBox_dx_6.Controls.Add(this.radioButton_dx_6_0);
            this.groupBox_dx_6.Controls.Add(this.radioButton_dx_6_1);
            this.groupBox_dx_6.Location = new System.Drawing.Point(1629, 409);
            this.groupBox_dx_6.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_dx_6.Name = "groupBox_dx_6";
            this.groupBox_dx_6.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_dx_6.Size = new System.Drawing.Size(40, 94);
            this.groupBox_dx_6.TabIndex = 114;
            this.groupBox_dx_6.TabStop = false;
            // 
            // radioButton_dx_6_0
            // 
            this.radioButton_dx_6_0.AutoSize = true;
            this.radioButton_dx_6_0.Checked = true;
            this.radioButton_dx_6_0.Location = new System.Drawing.Point(9, 52);
            this.radioButton_dx_6_0.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_dx_6_0.Name = "radioButton_dx_6_0";
            this.radioButton_dx_6_0.Size = new System.Drawing.Size(21, 20);
            this.radioButton_dx_6_0.TabIndex = 1;
            this.radioButton_dx_6_0.TabStop = true;
            this.radioButton_dx_6_0.UseVisualStyleBackColor = true;
            this.radioButton_dx_6_0.CheckedChanged += new System.EventHandler(this.radio_dx_click);
            // 
            // radioButton_dx_6_1
            // 
            this.radioButton_dx_6_1.AutoSize = true;
            this.radioButton_dx_6_1.Location = new System.Drawing.Point(9, 23);
            this.radioButton_dx_6_1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_dx_6_1.Name = "radioButton_dx_6_1";
            this.radioButton_dx_6_1.Size = new System.Drawing.Size(21, 20);
            this.radioButton_dx_6_1.TabIndex = 0;
            this.radioButton_dx_6_1.UseVisualStyleBackColor = true;
            this.radioButton_dx_6_1.CheckedChanged += new System.EventHandler(this.radio_dx_click);
            // 
            // groupBox_dx_12
            // 
            this.groupBox_dx_12.Controls.Add(this.radioButton_dx_12_0);
            this.groupBox_dx_12.Controls.Add(this.radioButton_dx_12_1);
            this.groupBox_dx_12.Location = new System.Drawing.Point(1305, 409);
            this.groupBox_dx_12.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_dx_12.Name = "groupBox_dx_12";
            this.groupBox_dx_12.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_dx_12.Size = new System.Drawing.Size(40, 94);
            this.groupBox_dx_12.TabIndex = 99;
            this.groupBox_dx_12.TabStop = false;
            // 
            // radioButton_dx_12_0
            // 
            this.radioButton_dx_12_0.AutoSize = true;
            this.radioButton_dx_12_0.Checked = true;
            this.radioButton_dx_12_0.Location = new System.Drawing.Point(9, 52);
            this.radioButton_dx_12_0.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_dx_12_0.Name = "radioButton_dx_12_0";
            this.radioButton_dx_12_0.Size = new System.Drawing.Size(21, 20);
            this.radioButton_dx_12_0.TabIndex = 1;
            this.radioButton_dx_12_0.TabStop = true;
            this.radioButton_dx_12_0.UseVisualStyleBackColor = true;
            this.radioButton_dx_12_0.CheckedChanged += new System.EventHandler(this.radio_dx_click);
            // 
            // radioButton_dx_12_1
            // 
            this.radioButton_dx_12_1.AutoSize = true;
            this.radioButton_dx_12_1.Location = new System.Drawing.Point(9, 23);
            this.radioButton_dx_12_1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_dx_12_1.Name = "radioButton_dx_12_1";
            this.radioButton_dx_12_1.Size = new System.Drawing.Size(21, 20);
            this.radioButton_dx_12_1.TabIndex = 0;
            this.radioButton_dx_12_1.UseVisualStyleBackColor = true;
            this.radioButton_dx_12_1.CheckedChanged += new System.EventHandler(this.radio_dx_click);
            // 
            // groupBox_dx_5
            // 
            this.groupBox_dx_5.Controls.Add(this.radioButton_dx_5_0);
            this.groupBox_dx_5.Controls.Add(this.radioButton_dx_5_1);
            this.groupBox_dx_5.Location = new System.Drawing.Point(1678, 409);
            this.groupBox_dx_5.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_dx_5.Name = "groupBox_dx_5";
            this.groupBox_dx_5.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_dx_5.Size = new System.Drawing.Size(40, 94);
            this.groupBox_dx_5.TabIndex = 115;
            this.groupBox_dx_5.TabStop = false;
            // 
            // radioButton_dx_5_0
            // 
            this.radioButton_dx_5_0.AutoSize = true;
            this.radioButton_dx_5_0.Checked = true;
            this.radioButton_dx_5_0.Location = new System.Drawing.Point(9, 52);
            this.radioButton_dx_5_0.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_dx_5_0.Name = "radioButton_dx_5_0";
            this.radioButton_dx_5_0.Size = new System.Drawing.Size(21, 20);
            this.radioButton_dx_5_0.TabIndex = 1;
            this.radioButton_dx_5_0.TabStop = true;
            this.radioButton_dx_5_0.UseVisualStyleBackColor = true;
            this.radioButton_dx_5_0.CheckedChanged += new System.EventHandler(this.radio_dx_click);
            // 
            // radioButton_dx_5_1
            // 
            this.radioButton_dx_5_1.AutoSize = true;
            this.radioButton_dx_5_1.Location = new System.Drawing.Point(9, 23);
            this.radioButton_dx_5_1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_dx_5_1.Name = "radioButton_dx_5_1";
            this.radioButton_dx_5_1.Size = new System.Drawing.Size(21, 20);
            this.radioButton_dx_5_1.TabIndex = 0;
            this.radioButton_dx_5_1.UseVisualStyleBackColor = true;
            this.radioButton_dx_5_1.CheckedChanged += new System.EventHandler(this.radio_dx_click);
            // 
            // groupBox_dx_11
            // 
            this.groupBox_dx_11.Controls.Add(this.radioButton_dx_11_0);
            this.groupBox_dx_11.Controls.Add(this.radioButton_dx_11_1);
            this.groupBox_dx_11.Location = new System.Drawing.Point(1354, 409);
            this.groupBox_dx_11.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_dx_11.Name = "groupBox_dx_11";
            this.groupBox_dx_11.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_dx_11.Size = new System.Drawing.Size(40, 94);
            this.groupBox_dx_11.TabIndex = 100;
            this.groupBox_dx_11.TabStop = false;
            // 
            // radioButton_dx_11_0
            // 
            this.radioButton_dx_11_0.AutoSize = true;
            this.radioButton_dx_11_0.Checked = true;
            this.radioButton_dx_11_0.Location = new System.Drawing.Point(9, 52);
            this.radioButton_dx_11_0.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_dx_11_0.Name = "radioButton_dx_11_0";
            this.radioButton_dx_11_0.Size = new System.Drawing.Size(21, 20);
            this.radioButton_dx_11_0.TabIndex = 1;
            this.radioButton_dx_11_0.TabStop = true;
            this.radioButton_dx_11_0.UseVisualStyleBackColor = true;
            this.radioButton_dx_11_0.CheckedChanged += new System.EventHandler(this.radio_dx_click);
            // 
            // radioButton_dx_11_1
            // 
            this.radioButton_dx_11_1.AutoSize = true;
            this.radioButton_dx_11_1.Location = new System.Drawing.Point(9, 23);
            this.radioButton_dx_11_1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_dx_11_1.Name = "radioButton_dx_11_1";
            this.radioButton_dx_11_1.Size = new System.Drawing.Size(21, 20);
            this.radioButton_dx_11_1.TabIndex = 0;
            this.radioButton_dx_11_1.UseVisualStyleBackColor = true;
            this.radioButton_dx_11_1.CheckedChanged += new System.EventHandler(this.radio_dx_click);
            // 
            // groupBox_dx_7
            // 
            this.groupBox_dx_7.Controls.Add(this.radioButton_dx_7_0);
            this.groupBox_dx_7.Controls.Add(this.radioButton_dx_7_1);
            this.groupBox_dx_7.Location = new System.Drawing.Point(1580, 409);
            this.groupBox_dx_7.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_dx_7.Name = "groupBox_dx_7";
            this.groupBox_dx_7.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_dx_7.Size = new System.Drawing.Size(40, 94);
            this.groupBox_dx_7.TabIndex = 106;
            this.groupBox_dx_7.TabStop = false;
            // 
            // radioButton_dx_7_0
            // 
            this.radioButton_dx_7_0.AutoSize = true;
            this.radioButton_dx_7_0.Checked = true;
            this.radioButton_dx_7_0.Location = new System.Drawing.Point(9, 52);
            this.radioButton_dx_7_0.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_dx_7_0.Name = "radioButton_dx_7_0";
            this.radioButton_dx_7_0.Size = new System.Drawing.Size(21, 20);
            this.radioButton_dx_7_0.TabIndex = 1;
            this.radioButton_dx_7_0.TabStop = true;
            this.radioButton_dx_7_0.UseVisualStyleBackColor = true;
            this.radioButton_dx_7_0.CheckedChanged += new System.EventHandler(this.radio_dx_click);
            // 
            // radioButton_dx_7_1
            // 
            this.radioButton_dx_7_1.AutoSize = true;
            this.radioButton_dx_7_1.Location = new System.Drawing.Point(9, 23);
            this.radioButton_dx_7_1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_dx_7_1.Name = "radioButton_dx_7_1";
            this.radioButton_dx_7_1.Size = new System.Drawing.Size(21, 20);
            this.radioButton_dx_7_1.TabIndex = 0;
            this.radioButton_dx_7_1.UseVisualStyleBackColor = true;
            this.radioButton_dx_7_1.CheckedChanged += new System.EventHandler(this.radio_dx_click);
            // 
            // groupBox_dx_10
            // 
            this.groupBox_dx_10.Controls.Add(this.radioButton_dx_10_0);
            this.groupBox_dx_10.Controls.Add(this.radioButton_dx_10_1);
            this.groupBox_dx_10.Location = new System.Drawing.Point(1404, 409);
            this.groupBox_dx_10.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_dx_10.Name = "groupBox_dx_10";
            this.groupBox_dx_10.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_dx_10.Size = new System.Drawing.Size(40, 94);
            this.groupBox_dx_10.TabIndex = 102;
            this.groupBox_dx_10.TabStop = false;
            // 
            // radioButton_dx_10_0
            // 
            this.radioButton_dx_10_0.AutoSize = true;
            this.radioButton_dx_10_0.Checked = true;
            this.radioButton_dx_10_0.Location = new System.Drawing.Point(9, 52);
            this.radioButton_dx_10_0.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_dx_10_0.Name = "radioButton_dx_10_0";
            this.radioButton_dx_10_0.Size = new System.Drawing.Size(21, 20);
            this.radioButton_dx_10_0.TabIndex = 1;
            this.radioButton_dx_10_0.TabStop = true;
            this.radioButton_dx_10_0.UseVisualStyleBackColor = true;
            this.radioButton_dx_10_0.CheckedChanged += new System.EventHandler(this.radio_dx_click);
            // 
            // radioButton_dx_10_1
            // 
            this.radioButton_dx_10_1.AutoSize = true;
            this.radioButton_dx_10_1.Location = new System.Drawing.Point(9, 23);
            this.radioButton_dx_10_1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_dx_10_1.Name = "radioButton_dx_10_1";
            this.radioButton_dx_10_1.Size = new System.Drawing.Size(21, 20);
            this.radioButton_dx_10_1.TabIndex = 0;
            this.radioButton_dx_10_1.UseVisualStyleBackColor = true;
            this.radioButton_dx_10_1.CheckedChanged += new System.EventHandler(this.radio_dx_click);
            // 
            // groupBox_dx_14
            // 
            this.groupBox_dx_14.Controls.Add(this.radioButton_dx_14_0);
            this.groupBox_dx_14.Controls.Add(this.radioButton_dx_14_1);
            this.groupBox_dx_14.Location = new System.Drawing.Point(1206, 409);
            this.groupBox_dx_14.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_dx_14.Name = "groupBox_dx_14";
            this.groupBox_dx_14.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_dx_14.Size = new System.Drawing.Size(40, 94);
            this.groupBox_dx_14.TabIndex = 103;
            this.groupBox_dx_14.TabStop = false;
            // 
            // radioButton_dx_14_0
            // 
            this.radioButton_dx_14_0.AutoSize = true;
            this.radioButton_dx_14_0.Checked = true;
            this.radioButton_dx_14_0.Location = new System.Drawing.Point(9, 52);
            this.radioButton_dx_14_0.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_dx_14_0.Name = "radioButton_dx_14_0";
            this.radioButton_dx_14_0.Size = new System.Drawing.Size(21, 20);
            this.radioButton_dx_14_0.TabIndex = 1;
            this.radioButton_dx_14_0.TabStop = true;
            this.radioButton_dx_14_0.UseVisualStyleBackColor = true;
            this.radioButton_dx_14_0.CheckedChanged += new System.EventHandler(this.radio_dx_click);
            // 
            // radioButton_dx_14_1
            // 
            this.radioButton_dx_14_1.AutoSize = true;
            this.radioButton_dx_14_1.Location = new System.Drawing.Point(9, 23);
            this.radioButton_dx_14_1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_dx_14_1.Name = "radioButton_dx_14_1";
            this.radioButton_dx_14_1.Size = new System.Drawing.Size(21, 20);
            this.radioButton_dx_14_1.TabIndex = 0;
            this.radioButton_dx_14_1.UseVisualStyleBackColor = true;
            this.radioButton_dx_14_1.CheckedChanged += new System.EventHandler(this.radio_dx_click);
            // 
            // groupBox_dx_13
            // 
            this.groupBox_dx_13.Controls.Add(this.radioButton_dx_13_0);
            this.groupBox_dx_13.Controls.Add(this.radioButton_dx_13_1);
            this.groupBox_dx_13.Location = new System.Drawing.Point(1256, 409);
            this.groupBox_dx_13.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_dx_13.Name = "groupBox_dx_13";
            this.groupBox_dx_13.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_dx_13.Size = new System.Drawing.Size(40, 94);
            this.groupBox_dx_13.TabIndex = 104;
            this.groupBox_dx_13.TabStop = false;
            // 
            // radioButton_dx_13_0
            // 
            this.radioButton_dx_13_0.AutoSize = true;
            this.radioButton_dx_13_0.Checked = true;
            this.radioButton_dx_13_0.Location = new System.Drawing.Point(9, 52);
            this.radioButton_dx_13_0.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_dx_13_0.Name = "radioButton_dx_13_0";
            this.radioButton_dx_13_0.Size = new System.Drawing.Size(21, 20);
            this.radioButton_dx_13_0.TabIndex = 1;
            this.radioButton_dx_13_0.TabStop = true;
            this.radioButton_dx_13_0.UseVisualStyleBackColor = true;
            this.radioButton_dx_13_0.CheckedChanged += new System.EventHandler(this.radio_dx_click);
            // 
            // radioButton_dx_13_1
            // 
            this.radioButton_dx_13_1.AutoSize = true;
            this.radioButton_dx_13_1.Location = new System.Drawing.Point(9, 23);
            this.radioButton_dx_13_1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_dx_13_1.Name = "radioButton_dx_13_1";
            this.radioButton_dx_13_1.Size = new System.Drawing.Size(21, 20);
            this.radioButton_dx_13_1.TabIndex = 0;
            this.radioButton_dx_13_1.UseVisualStyleBackColor = true;
            this.radioButton_dx_13_1.CheckedChanged += new System.EventHandler(this.radio_dx_click);
            // 
            // groupBox_dx_15
            // 
            this.groupBox_dx_15.Controls.Add(this.radioButton_dx_15_0);
            this.groupBox_dx_15.Controls.Add(this.radioButton_dx_15_1);
            this.groupBox_dx_15.Location = new System.Drawing.Point(1156, 409);
            this.groupBox_dx_15.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_dx_15.Name = "groupBox_dx_15";
            this.groupBox_dx_15.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_dx_15.Size = new System.Drawing.Size(40, 94);
            this.groupBox_dx_15.TabIndex = 97;
            this.groupBox_dx_15.TabStop = false;
            // 
            // radioButton_dx_15_0
            // 
            this.radioButton_dx_15_0.AutoSize = true;
            this.radioButton_dx_15_0.Checked = true;
            this.radioButton_dx_15_0.Location = new System.Drawing.Point(9, 52);
            this.radioButton_dx_15_0.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_dx_15_0.Name = "radioButton_dx_15_0";
            this.radioButton_dx_15_0.Size = new System.Drawing.Size(21, 20);
            this.radioButton_dx_15_0.TabIndex = 1;
            this.radioButton_dx_15_0.TabStop = true;
            this.radioButton_dx_15_0.UseVisualStyleBackColor = true;
            this.radioButton_dx_15_0.CheckedChanged += new System.EventHandler(this.radio_dx_click);
            // 
            // radioButton_dx_15_1
            // 
            this.radioButton_dx_15_1.AutoSize = true;
            this.radioButton_dx_15_1.Location = new System.Drawing.Point(9, 23);
            this.radioButton_dx_15_1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_dx_15_1.Name = "radioButton_dx_15_1";
            this.radioButton_dx_15_1.Size = new System.Drawing.Size(21, 20);
            this.radioButton_dx_15_1.TabIndex = 0;
            this.radioButton_dx_15_1.UseVisualStyleBackColor = true;
            this.radioButton_dx_15_1.CheckedChanged += new System.EventHandler(this.radio_dx_click);
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(1128, 462);
            this.label27.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(18, 20);
            this.label27.TabIndex = 96;
            this.label27.Text = "0";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(1128, 432);
            this.label28.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(18, 20);
            this.label28.TabIndex = 95;
            this.label28.Text = "1";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(742, 651);
            this.label29.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(29, 20);
            this.label29.TabIndex = 94;
            this.label29.Text = "CL";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(402, 651);
            this.label30.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(32, 20);
            this.label30.TabIndex = 93;
            this.label30.Text = "CH";
            // 
            // label_ch_wartosc
            // 
            this.label_ch_wartosc.AutoSize = true;
            this.label_ch_wartosc.BackColor = System.Drawing.SystemColors.ControlDark;
            this.label_ch_wartosc.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_ch_wartosc.Location = new System.Drawing.Point(436, 609);
            this.label_ch_wartosc.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_ch_wartosc.Name = "label_ch_wartosc";
            this.label_ch_wartosc.Size = new System.Drawing.Size(151, 33);
            this.label_ch_wartosc.TabIndex = 92;
            this.label_ch_wartosc.Text = "00000000";
            // 
            // label_cl_wartosc
            // 
            this.label_cl_wartosc.AutoSize = true;
            this.label_cl_wartosc.BackColor = System.Drawing.SystemColors.ControlDark;
            this.label_cl_wartosc.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_cl_wartosc.Location = new System.Drawing.Point(592, 609);
            this.label_cl_wartosc.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_cl_wartosc.Name = "label_cl_wartosc";
            this.label_cl_wartosc.Size = new System.Drawing.Size(151, 33);
            this.label_cl_wartosc.TabIndex = 91;
            this.label_cl_wartosc.Text = "00000000";
            // 
            // button_cx
            // 
            this.button_cx.Location = new System.Drawing.Point(608, 531);
            this.button_cx.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button_cx.Name = "button_cx";
            this.button_cx.Size = new System.Drawing.Size(112, 35);
            this.button_cx.TabIndex = 90;
            this.button_cx.Text = "WPISZ";
            this.button_cx.UseVisualStyleBackColor = true;
            this.button_cx.Click += new System.EventHandler(this.button_cx_Click);
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(994, 509);
            this.label33.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(40, 20);
            this.label33.TabIndex = 89;
            this.label33.Text = "0-bit";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(994, 462);
            this.label34.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(18, 20);
            this.label34.TabIndex = 88;
            this.label34.Text = "0";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(994, 432);
            this.label35.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(18, 20);
            this.label35.TabIndex = 87;
            this.label35.Text = "1";
            // 
            // groupBox_cx_1
            // 
            this.groupBox_cx_1.Controls.Add(this.radioButton_cx_1_0);
            this.groupBox_cx_1.Controls.Add(this.radioButton_cx_1_1);
            this.groupBox_cx_1.Location = new System.Drawing.Point(896, 409);
            this.groupBox_cx_1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_cx_1.Name = "groupBox_cx_1";
            this.groupBox_cx_1.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_cx_1.Size = new System.Drawing.Size(40, 94);
            this.groupBox_cx_1.TabIndex = 78;
            this.groupBox_cx_1.TabStop = false;
            // 
            // radioButton_cx_1_0
            // 
            this.radioButton_cx_1_0.AutoSize = true;
            this.radioButton_cx_1_0.Checked = true;
            this.radioButton_cx_1_0.Location = new System.Drawing.Point(9, 52);
            this.radioButton_cx_1_0.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_cx_1_0.Name = "radioButton_cx_1_0";
            this.radioButton_cx_1_0.Size = new System.Drawing.Size(21, 20);
            this.radioButton_cx_1_0.TabIndex = 1;
            this.radioButton_cx_1_0.TabStop = true;
            this.radioButton_cx_1_0.UseVisualStyleBackColor = true;
            this.radioButton_cx_1_0.CheckedChanged += new System.EventHandler(this.radio_cx_click);
            // 
            // radioButton_cx_1_1
            // 
            this.radioButton_cx_1_1.AutoSize = true;
            this.radioButton_cx_1_1.Location = new System.Drawing.Point(9, 23);
            this.radioButton_cx_1_1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_cx_1_1.Name = "radioButton_cx_1_1";
            this.radioButton_cx_1_1.Size = new System.Drawing.Size(21, 20);
            this.radioButton_cx_1_1.TabIndex = 0;
            this.radioButton_cx_1_1.UseVisualStyleBackColor = true;
            this.radioButton_cx_1_1.CheckedChanged += new System.EventHandler(this.radio_cx_click);
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.Location = new System.Drawing.Point(495, 374);
            this.label36.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(140, 29);
            this.label36.TabIndex = 80;
            this.label36.Text = "Rejestr CX";
            // 
            // groupBox_cx_0
            // 
            this.groupBox_cx_0.Controls.Add(this.radioButton_cx_0_0);
            this.groupBox_cx_0.Controls.Add(this.radioButton_cx_0_1);
            this.groupBox_cx_0.Location = new System.Drawing.Point(945, 409);
            this.groupBox_cx_0.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_cx_0.Name = "groupBox_cx_0";
            this.groupBox_cx_0.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_cx_0.Size = new System.Drawing.Size(40, 94);
            this.groupBox_cx_0.TabIndex = 81;
            this.groupBox_cx_0.TabStop = false;
            // 
            // radioButton_cx_0_0
            // 
            this.radioButton_cx_0_0.AutoSize = true;
            this.radioButton_cx_0_0.Checked = true;
            this.radioButton_cx_0_0.Location = new System.Drawing.Point(9, 52);
            this.radioButton_cx_0_0.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_cx_0_0.Name = "radioButton_cx_0_0";
            this.radioButton_cx_0_0.Size = new System.Drawing.Size(21, 20);
            this.radioButton_cx_0_0.TabIndex = 1;
            this.radioButton_cx_0_0.TabStop = true;
            this.radioButton_cx_0_0.UseVisualStyleBackColor = true;
            this.radioButton_cx_0_0.CheckedChanged += new System.EventHandler(this.radio_cx_click);
            // 
            // radioButton_cx_0_1
            // 
            this.radioButton_cx_0_1.AutoSize = true;
            this.radioButton_cx_0_1.Location = new System.Drawing.Point(9, 23);
            this.radioButton_cx_0_1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_cx_0_1.Name = "radioButton_cx_0_1";
            this.radioButton_cx_0_1.Size = new System.Drawing.Size(21, 20);
            this.radioButton_cx_0_1.TabIndex = 0;
            this.radioButton_cx_0_1.UseVisualStyleBackColor = true;
            this.radioButton_cx_0_1.CheckedChanged += new System.EventHandler(this.radio_cx_click);
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(112, 509);
            this.label37.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(49, 20);
            this.label37.TabIndex = 79;
            this.label37.Text = "15-bit";
            // 
            // groupBox_cx_4
            // 
            this.groupBox_cx_4.Controls.Add(this.radioButton_cx_4_0);
            this.groupBox_cx_4.Controls.Add(this.radioButton_cx_4_1);
            this.groupBox_cx_4.Location = new System.Drawing.Point(747, 409);
            this.groupBox_cx_4.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_cx_4.Name = "groupBox_cx_4";
            this.groupBox_cx_4.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_cx_4.Size = new System.Drawing.Size(40, 94);
            this.groupBox_cx_4.TabIndex = 82;
            this.groupBox_cx_4.TabStop = false;
            // 
            // radioButton_cx_4_0
            // 
            this.radioButton_cx_4_0.AutoSize = true;
            this.radioButton_cx_4_0.Checked = true;
            this.radioButton_cx_4_0.Location = new System.Drawing.Point(9, 52);
            this.radioButton_cx_4_0.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_cx_4_0.Name = "radioButton_cx_4_0";
            this.radioButton_cx_4_0.Size = new System.Drawing.Size(21, 20);
            this.radioButton_cx_4_0.TabIndex = 1;
            this.radioButton_cx_4_0.TabStop = true;
            this.radioButton_cx_4_0.UseVisualStyleBackColor = true;
            this.radioButton_cx_4_0.CheckedChanged += new System.EventHandler(this.radio_cx_click);
            // 
            // radioButton_cx_4_1
            // 
            this.radioButton_cx_4_1.AutoSize = true;
            this.radioButton_cx_4_1.Location = new System.Drawing.Point(9, 23);
            this.radioButton_cx_4_1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_cx_4_1.Name = "radioButton_cx_4_1";
            this.radioButton_cx_4_1.Size = new System.Drawing.Size(21, 20);
            this.radioButton_cx_4_1.TabIndex = 0;
            this.radioButton_cx_4_1.UseVisualStyleBackColor = true;
            this.radioButton_cx_4_1.CheckedChanged += new System.EventHandler(this.radio_cx_click);
            // 
            // label_cx
            // 
            this.label_cx.AutoSize = true;
            this.label_cx.Location = new System.Drawing.Point(378, 538);
            this.label_cx.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_cx.Name = "label_cx";
            this.label_cx.Size = new System.Drawing.Size(153, 20);
            this.label_cx.TabIndex = 76;
            this.label_cx.Text = "0000000000000000";
            // 
            // groupBox_cx_3
            // 
            this.groupBox_cx_3.Controls.Add(this.radioButton_cx_3_0);
            this.groupBox_cx_3.Controls.Add(this.radioButton_cx_3_1);
            this.groupBox_cx_3.Location = new System.Drawing.Point(796, 409);
            this.groupBox_cx_3.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_cx_3.Name = "groupBox_cx_3";
            this.groupBox_cx_3.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_cx_3.Size = new System.Drawing.Size(40, 94);
            this.groupBox_cx_3.TabIndex = 83;
            this.groupBox_cx_3.TabStop = false;
            // 
            // radioButton_cx_3_0
            // 
            this.radioButton_cx_3_0.AutoSize = true;
            this.radioButton_cx_3_0.Checked = true;
            this.radioButton_cx_3_0.Location = new System.Drawing.Point(9, 52);
            this.radioButton_cx_3_0.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_cx_3_0.Name = "radioButton_cx_3_0";
            this.radioButton_cx_3_0.Size = new System.Drawing.Size(21, 20);
            this.radioButton_cx_3_0.TabIndex = 1;
            this.radioButton_cx_3_0.TabStop = true;
            this.radioButton_cx_3_0.UseVisualStyleBackColor = true;
            this.radioButton_cx_3_0.CheckedChanged += new System.EventHandler(this.radio_cx_click);
            // 
            // radioButton_cx_3_1
            // 
            this.radioButton_cx_3_1.AutoSize = true;
            this.radioButton_cx_3_1.Location = new System.Drawing.Point(9, 23);
            this.radioButton_cx_3_1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_cx_3_1.Name = "radioButton_cx_3_1";
            this.radioButton_cx_3_1.Size = new System.Drawing.Size(21, 20);
            this.radioButton_cx_3_1.TabIndex = 0;
            this.radioButton_cx_3_1.UseVisualStyleBackColor = true;
            this.radioButton_cx_3_1.CheckedChanged += new System.EventHandler(this.radio_cx_click);
            // 
            // groupBox_cx_9
            // 
            this.groupBox_cx_9.Controls.Add(this.radioButton_cx_9_0);
            this.groupBox_cx_9.Controls.Add(this.radioButton_cx_9_1);
            this.groupBox_cx_9.Location = new System.Drawing.Point(472, 409);
            this.groupBox_cx_9.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_cx_9.Name = "groupBox_cx_9";
            this.groupBox_cx_9.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_cx_9.Size = new System.Drawing.Size(40, 94);
            this.groupBox_cx_9.TabIndex = 73;
            this.groupBox_cx_9.TabStop = false;
            // 
            // radioButton_cx_9_0
            // 
            this.radioButton_cx_9_0.AutoSize = true;
            this.radioButton_cx_9_0.Checked = true;
            this.radioButton_cx_9_0.Location = new System.Drawing.Point(9, 52);
            this.radioButton_cx_9_0.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_cx_9_0.Name = "radioButton_cx_9_0";
            this.radioButton_cx_9_0.Size = new System.Drawing.Size(21, 20);
            this.radioButton_cx_9_0.TabIndex = 1;
            this.radioButton_cx_9_0.TabStop = true;
            this.radioButton_cx_9_0.UseVisualStyleBackColor = true;
            this.radioButton_cx_9_0.CheckedChanged += new System.EventHandler(this.radio_cx_click);
            // 
            // radioButton_cx_9_1
            // 
            this.radioButton_cx_9_1.AutoSize = true;
            this.radioButton_cx_9_1.Location = new System.Drawing.Point(9, 23);
            this.radioButton_cx_9_1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_cx_9_1.Name = "radioButton_cx_9_1";
            this.radioButton_cx_9_1.Size = new System.Drawing.Size(21, 20);
            this.radioButton_cx_9_1.TabIndex = 0;
            this.radioButton_cx_9_1.UseVisualStyleBackColor = true;
            this.radioButton_cx_9_1.CheckedChanged += new System.EventHandler(this.radio_cx_click);
            // 
            // groupBox_cx_2
            // 
            this.groupBox_cx_2.Controls.Add(this.radioButton_cx_2_0);
            this.groupBox_cx_2.Controls.Add(this.radioButton_cx_2_1);
            this.groupBox_cx_2.Location = new System.Drawing.Point(846, 409);
            this.groupBox_cx_2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_cx_2.Name = "groupBox_cx_2";
            this.groupBox_cx_2.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_cx_2.Size = new System.Drawing.Size(40, 94);
            this.groupBox_cx_2.TabIndex = 84;
            this.groupBox_cx_2.TabStop = false;
            // 
            // radioButton_cx_2_0
            // 
            this.radioButton_cx_2_0.AutoSize = true;
            this.radioButton_cx_2_0.Checked = true;
            this.radioButton_cx_2_0.Location = new System.Drawing.Point(9, 52);
            this.radioButton_cx_2_0.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_cx_2_0.Name = "radioButton_cx_2_0";
            this.radioButton_cx_2_0.Size = new System.Drawing.Size(21, 20);
            this.radioButton_cx_2_0.TabIndex = 1;
            this.radioButton_cx_2_0.TabStop = true;
            this.radioButton_cx_2_0.UseVisualStyleBackColor = true;
            this.radioButton_cx_2_0.CheckedChanged += new System.EventHandler(this.radio_cx_click);
            // 
            // radioButton_cx_2_1
            // 
            this.radioButton_cx_2_1.AutoSize = true;
            this.radioButton_cx_2_1.Location = new System.Drawing.Point(9, 23);
            this.radioButton_cx_2_1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_cx_2_1.Name = "radioButton_cx_2_1";
            this.radioButton_cx_2_1.Size = new System.Drawing.Size(21, 20);
            this.radioButton_cx_2_1.TabIndex = 0;
            this.radioButton_cx_2_1.UseVisualStyleBackColor = true;
            this.radioButton_cx_2_1.CheckedChanged += new System.EventHandler(this.radio_cx_click);
            // 
            // groupBox_cx_8
            // 
            this.groupBox_cx_8.Controls.Add(this.radioButton_cx_8_0);
            this.groupBox_cx_8.Controls.Add(this.radioButton_cx_8_1);
            this.groupBox_cx_8.Location = new System.Drawing.Point(522, 409);
            this.groupBox_cx_8.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_cx_8.Name = "groupBox_cx_8";
            this.groupBox_cx_8.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_cx_8.Size = new System.Drawing.Size(40, 94);
            this.groupBox_cx_8.TabIndex = 75;
            this.groupBox_cx_8.TabStop = false;
            // 
            // radioButton_cx_8_0
            // 
            this.radioButton_cx_8_0.AutoSize = true;
            this.radioButton_cx_8_0.Checked = true;
            this.radioButton_cx_8_0.Location = new System.Drawing.Point(9, 52);
            this.radioButton_cx_8_0.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_cx_8_0.Name = "radioButton_cx_8_0";
            this.radioButton_cx_8_0.Size = new System.Drawing.Size(21, 20);
            this.radioButton_cx_8_0.TabIndex = 1;
            this.radioButton_cx_8_0.TabStop = true;
            this.radioButton_cx_8_0.UseVisualStyleBackColor = true;
            this.radioButton_cx_8_0.CheckedChanged += new System.EventHandler(this.radio_cx_click);
            // 
            // radioButton_cx_8_1
            // 
            this.radioButton_cx_8_1.AutoSize = true;
            this.radioButton_cx_8_1.Location = new System.Drawing.Point(9, 23);
            this.radioButton_cx_8_1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_cx_8_1.Name = "radioButton_cx_8_1";
            this.radioButton_cx_8_1.Size = new System.Drawing.Size(21, 20);
            this.radioButton_cx_8_1.TabIndex = 0;
            this.radioButton_cx_8_1.UseVisualStyleBackColor = true;
            this.radioButton_cx_8_1.CheckedChanged += new System.EventHandler(this.radio_cx_click);
            // 
            // groupBox_cx_6
            // 
            this.groupBox_cx_6.Controls.Add(this.radioButton_cx_6_0);
            this.groupBox_cx_6.Controls.Add(this.radioButton_cx_6_1);
            this.groupBox_cx_6.Location = new System.Drawing.Point(648, 409);
            this.groupBox_cx_6.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_cx_6.Name = "groupBox_cx_6";
            this.groupBox_cx_6.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_cx_6.Size = new System.Drawing.Size(40, 94);
            this.groupBox_cx_6.TabIndex = 85;
            this.groupBox_cx_6.TabStop = false;
            // 
            // radioButton_cx_6_0
            // 
            this.radioButton_cx_6_0.AutoSize = true;
            this.radioButton_cx_6_0.Checked = true;
            this.radioButton_cx_6_0.Location = new System.Drawing.Point(9, 52);
            this.radioButton_cx_6_0.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_cx_6_0.Name = "radioButton_cx_6_0";
            this.radioButton_cx_6_0.Size = new System.Drawing.Size(21, 20);
            this.radioButton_cx_6_0.TabIndex = 1;
            this.radioButton_cx_6_0.TabStop = true;
            this.radioButton_cx_6_0.UseVisualStyleBackColor = true;
            this.radioButton_cx_6_0.CheckedChanged += new System.EventHandler(this.radio_cx_click);
            // 
            // radioButton_cx_6_1
            // 
            this.radioButton_cx_6_1.AutoSize = true;
            this.radioButton_cx_6_1.Location = new System.Drawing.Point(9, 23);
            this.radioButton_cx_6_1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_cx_6_1.Name = "radioButton_cx_6_1";
            this.radioButton_cx_6_1.Size = new System.Drawing.Size(21, 20);
            this.radioButton_cx_6_1.TabIndex = 0;
            this.radioButton_cx_6_1.UseVisualStyleBackColor = true;
            this.radioButton_cx_6_1.CheckedChanged += new System.EventHandler(this.radio_cx_click);
            // 
            // groupBox_cx_12
            // 
            this.groupBox_cx_12.Controls.Add(this.radioButton_cx_12_0);
            this.groupBox_cx_12.Controls.Add(this.radioButton_cx_12_1);
            this.groupBox_cx_12.Location = new System.Drawing.Point(324, 409);
            this.groupBox_cx_12.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_cx_12.Name = "groupBox_cx_12";
            this.groupBox_cx_12.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_cx_12.Size = new System.Drawing.Size(40, 94);
            this.groupBox_cx_12.TabIndex = 74;
            this.groupBox_cx_12.TabStop = false;
            // 
            // radioButton_cx_12_0
            // 
            this.radioButton_cx_12_0.AutoSize = true;
            this.radioButton_cx_12_0.Checked = true;
            this.radioButton_cx_12_0.Location = new System.Drawing.Point(9, 52);
            this.radioButton_cx_12_0.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_cx_12_0.Name = "radioButton_cx_12_0";
            this.radioButton_cx_12_0.Size = new System.Drawing.Size(21, 20);
            this.radioButton_cx_12_0.TabIndex = 1;
            this.radioButton_cx_12_0.TabStop = true;
            this.radioButton_cx_12_0.UseVisualStyleBackColor = true;
            this.radioButton_cx_12_0.CheckedChanged += new System.EventHandler(this.radio_cx_click);
            // 
            // radioButton_cx_12_1
            // 
            this.radioButton_cx_12_1.AutoSize = true;
            this.radioButton_cx_12_1.Location = new System.Drawing.Point(9, 23);
            this.radioButton_cx_12_1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_cx_12_1.Name = "radioButton_cx_12_1";
            this.radioButton_cx_12_1.Size = new System.Drawing.Size(21, 20);
            this.radioButton_cx_12_1.TabIndex = 0;
            this.radioButton_cx_12_1.UseVisualStyleBackColor = true;
            this.radioButton_cx_12_1.CheckedChanged += new System.EventHandler(this.radio_cx_click);
            // 
            // groupBox_cx_5
            // 
            this.groupBox_cx_5.Controls.Add(this.radioButton_cx_5_0);
            this.groupBox_cx_5.Controls.Add(this.radioButton_cx_5_1);
            this.groupBox_cx_5.Location = new System.Drawing.Point(698, 409);
            this.groupBox_cx_5.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_cx_5.Name = "groupBox_cx_5";
            this.groupBox_cx_5.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_cx_5.Size = new System.Drawing.Size(40, 94);
            this.groupBox_cx_5.TabIndex = 86;
            this.groupBox_cx_5.TabStop = false;
            // 
            // radioButton_cx_5_0
            // 
            this.radioButton_cx_5_0.AutoSize = true;
            this.radioButton_cx_5_0.Checked = true;
            this.radioButton_cx_5_0.Location = new System.Drawing.Point(9, 52);
            this.radioButton_cx_5_0.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_cx_5_0.Name = "radioButton_cx_5_0";
            this.radioButton_cx_5_0.Size = new System.Drawing.Size(21, 20);
            this.radioButton_cx_5_0.TabIndex = 1;
            this.radioButton_cx_5_0.TabStop = true;
            this.radioButton_cx_5_0.UseVisualStyleBackColor = true;
            this.radioButton_cx_5_0.CheckedChanged += new System.EventHandler(this.radio_cx_click);
            // 
            // radioButton_cx_5_1
            // 
            this.radioButton_cx_5_1.AutoSize = true;
            this.radioButton_cx_5_1.Location = new System.Drawing.Point(9, 23);
            this.radioButton_cx_5_1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_cx_5_1.Name = "radioButton_cx_5_1";
            this.radioButton_cx_5_1.Size = new System.Drawing.Size(21, 20);
            this.radioButton_cx_5_1.TabIndex = 0;
            this.radioButton_cx_5_1.UseVisualStyleBackColor = true;
            this.radioButton_cx_5_1.CheckedChanged += new System.EventHandler(this.radio_cx_click);
            // 
            // groupBox_cx_11
            // 
            this.groupBox_cx_11.Controls.Add(this.radioButton_cx_11_0);
            this.groupBox_cx_11.Controls.Add(this.radioButton_cx_11_1);
            this.groupBox_cx_11.Location = new System.Drawing.Point(374, 409);
            this.groupBox_cx_11.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_cx_11.Name = "groupBox_cx_11";
            this.groupBox_cx_11.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_cx_11.Size = new System.Drawing.Size(40, 94);
            this.groupBox_cx_11.TabIndex = 72;
            this.groupBox_cx_11.TabStop = false;
            // 
            // radioButton_cx_11_0
            // 
            this.radioButton_cx_11_0.AutoSize = true;
            this.radioButton_cx_11_0.Checked = true;
            this.radioButton_cx_11_0.Location = new System.Drawing.Point(9, 52);
            this.radioButton_cx_11_0.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_cx_11_0.Name = "radioButton_cx_11_0";
            this.radioButton_cx_11_0.Size = new System.Drawing.Size(21, 20);
            this.radioButton_cx_11_0.TabIndex = 1;
            this.radioButton_cx_11_0.TabStop = true;
            this.radioButton_cx_11_0.UseVisualStyleBackColor = true;
            this.radioButton_cx_11_0.CheckedChanged += new System.EventHandler(this.radio_cx_click);
            // 
            // radioButton_cx_11_1
            // 
            this.radioButton_cx_11_1.AutoSize = true;
            this.radioButton_cx_11_1.Location = new System.Drawing.Point(9, 23);
            this.radioButton_cx_11_1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_cx_11_1.Name = "radioButton_cx_11_1";
            this.radioButton_cx_11_1.Size = new System.Drawing.Size(21, 20);
            this.radioButton_cx_11_1.TabIndex = 0;
            this.radioButton_cx_11_1.UseVisualStyleBackColor = true;
            this.radioButton_cx_11_1.CheckedChanged += new System.EventHandler(this.radio_cx_click);
            // 
            // groupBox_cx_7
            // 
            this.groupBox_cx_7.Controls.Add(this.radioButton_cx_7_0);
            this.groupBox_cx_7.Controls.Add(this.radioButton_cx_7_1);
            this.groupBox_cx_7.Location = new System.Drawing.Point(598, 409);
            this.groupBox_cx_7.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_cx_7.Name = "groupBox_cx_7";
            this.groupBox_cx_7.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_cx_7.Size = new System.Drawing.Size(40, 94);
            this.groupBox_cx_7.TabIndex = 77;
            this.groupBox_cx_7.TabStop = false;
            // 
            // radioButton_cx_7_0
            // 
            this.radioButton_cx_7_0.AutoSize = true;
            this.radioButton_cx_7_0.Checked = true;
            this.radioButton_cx_7_0.Location = new System.Drawing.Point(9, 52);
            this.radioButton_cx_7_0.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_cx_7_0.Name = "radioButton_cx_7_0";
            this.radioButton_cx_7_0.Size = new System.Drawing.Size(21, 20);
            this.radioButton_cx_7_0.TabIndex = 1;
            this.radioButton_cx_7_0.TabStop = true;
            this.radioButton_cx_7_0.UseVisualStyleBackColor = true;
            this.radioButton_cx_7_0.CheckedChanged += new System.EventHandler(this.radio_cx_click);
            // 
            // radioButton_cx_7_1
            // 
            this.radioButton_cx_7_1.AutoSize = true;
            this.radioButton_cx_7_1.Location = new System.Drawing.Point(9, 23);
            this.radioButton_cx_7_1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_cx_7_1.Name = "radioButton_cx_7_1";
            this.radioButton_cx_7_1.Size = new System.Drawing.Size(21, 20);
            this.radioButton_cx_7_1.TabIndex = 0;
            this.radioButton_cx_7_1.UseVisualStyleBackColor = true;
            this.radioButton_cx_7_1.CheckedChanged += new System.EventHandler(this.radio_cx_click);
            // 
            // groupBox_cx_10
            // 
            this.groupBox_cx_10.Controls.Add(this.radioButton_cx_10_0);
            this.groupBox_cx_10.Controls.Add(this.radioButton_cx_10_1);
            this.groupBox_cx_10.Location = new System.Drawing.Point(423, 409);
            this.groupBox_cx_10.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_cx_10.Name = "groupBox_cx_10";
            this.groupBox_cx_10.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_cx_10.Size = new System.Drawing.Size(40, 94);
            this.groupBox_cx_10.TabIndex = 71;
            this.groupBox_cx_10.TabStop = false;
            // 
            // radioButton_cx_10_0
            // 
            this.radioButton_cx_10_0.AutoSize = true;
            this.radioButton_cx_10_0.Checked = true;
            this.radioButton_cx_10_0.Location = new System.Drawing.Point(9, 52);
            this.radioButton_cx_10_0.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_cx_10_0.Name = "radioButton_cx_10_0";
            this.radioButton_cx_10_0.Size = new System.Drawing.Size(21, 20);
            this.radioButton_cx_10_0.TabIndex = 1;
            this.radioButton_cx_10_0.TabStop = true;
            this.radioButton_cx_10_0.UseVisualStyleBackColor = true;
            this.radioButton_cx_10_0.CheckedChanged += new System.EventHandler(this.radio_cx_click);
            // 
            // radioButton_cx_10_1
            // 
            this.radioButton_cx_10_1.AutoSize = true;
            this.radioButton_cx_10_1.Location = new System.Drawing.Point(9, 23);
            this.radioButton_cx_10_1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_cx_10_1.Name = "radioButton_cx_10_1";
            this.radioButton_cx_10_1.Size = new System.Drawing.Size(21, 20);
            this.radioButton_cx_10_1.TabIndex = 0;
            this.radioButton_cx_10_1.UseVisualStyleBackColor = true;
            this.radioButton_cx_10_1.CheckedChanged += new System.EventHandler(this.radio_cx_click);
            // 
            // groupBox_cx_14
            // 
            this.groupBox_cx_14.Controls.Add(this.radioButton_cx_14_0);
            this.groupBox_cx_14.Controls.Add(this.radioButton_cx_14_1);
            this.groupBox_cx_14.Location = new System.Drawing.Point(225, 409);
            this.groupBox_cx_14.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_cx_14.Name = "groupBox_cx_14";
            this.groupBox_cx_14.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_cx_14.Size = new System.Drawing.Size(40, 94);
            this.groupBox_cx_14.TabIndex = 70;
            this.groupBox_cx_14.TabStop = false;
            // 
            // radioButton_cx_14_0
            // 
            this.radioButton_cx_14_0.AutoSize = true;
            this.radioButton_cx_14_0.Checked = true;
            this.radioButton_cx_14_0.Location = new System.Drawing.Point(9, 52);
            this.radioButton_cx_14_0.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_cx_14_0.Name = "radioButton_cx_14_0";
            this.radioButton_cx_14_0.Size = new System.Drawing.Size(21, 20);
            this.radioButton_cx_14_0.TabIndex = 1;
            this.radioButton_cx_14_0.TabStop = true;
            this.radioButton_cx_14_0.UseVisualStyleBackColor = true;
            this.radioButton_cx_14_0.CheckedChanged += new System.EventHandler(this.radio_cx_click);
            // 
            // radioButton_cx_14_1
            // 
            this.radioButton_cx_14_1.AutoSize = true;
            this.radioButton_cx_14_1.Location = new System.Drawing.Point(9, 23);
            this.radioButton_cx_14_1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_cx_14_1.Name = "radioButton_cx_14_1";
            this.radioButton_cx_14_1.Size = new System.Drawing.Size(21, 20);
            this.radioButton_cx_14_1.TabIndex = 0;
            this.radioButton_cx_14_1.UseVisualStyleBackColor = true;
            this.radioButton_cx_14_1.CheckedChanged += new System.EventHandler(this.radio_cx_click);
            // 
            // groupBox_cx_13
            // 
            this.groupBox_cx_13.Controls.Add(this.radioButton_cx_13_0);
            this.groupBox_cx_13.Controls.Add(this.radioButton_cx_13_1);
            this.groupBox_cx_13.Location = new System.Drawing.Point(274, 409);
            this.groupBox_cx_13.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_cx_13.Name = "groupBox_cx_13";
            this.groupBox_cx_13.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_cx_13.Size = new System.Drawing.Size(40, 94);
            this.groupBox_cx_13.TabIndex = 69;
            this.groupBox_cx_13.TabStop = false;
            // 
            // radioButton_cx_13_0
            // 
            this.radioButton_cx_13_0.AutoSize = true;
            this.radioButton_cx_13_0.Checked = true;
            this.radioButton_cx_13_0.Location = new System.Drawing.Point(9, 52);
            this.radioButton_cx_13_0.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_cx_13_0.Name = "radioButton_cx_13_0";
            this.radioButton_cx_13_0.Size = new System.Drawing.Size(21, 20);
            this.radioButton_cx_13_0.TabIndex = 1;
            this.radioButton_cx_13_0.TabStop = true;
            this.radioButton_cx_13_0.UseVisualStyleBackColor = true;
            this.radioButton_cx_13_0.CheckedChanged += new System.EventHandler(this.radio_cx_click);
            // 
            // radioButton_cx_13_1
            // 
            this.radioButton_cx_13_1.AutoSize = true;
            this.radioButton_cx_13_1.Location = new System.Drawing.Point(9, 23);
            this.radioButton_cx_13_1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_cx_13_1.Name = "radioButton_cx_13_1";
            this.radioButton_cx_13_1.Size = new System.Drawing.Size(21, 20);
            this.radioButton_cx_13_1.TabIndex = 0;
            this.radioButton_cx_13_1.UseVisualStyleBackColor = true;
            this.radioButton_cx_13_1.CheckedChanged += new System.EventHandler(this.radio_cx_click);
            // 
            // groupBox_cx_15
            // 
            this.groupBox_cx_15.Controls.Add(this.radioButton_cx_15_0);
            this.groupBox_cx_15.Controls.Add(this.radioButton_cx_15_1);
            this.groupBox_cx_15.Location = new System.Drawing.Point(176, 409);
            this.groupBox_cx_15.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_cx_15.Name = "groupBox_cx_15";
            this.groupBox_cx_15.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_cx_15.Size = new System.Drawing.Size(40, 94);
            this.groupBox_cx_15.TabIndex = 68;
            this.groupBox_cx_15.TabStop = false;
            // 
            // radioButton_cx_15_0
            // 
            this.radioButton_cx_15_0.AutoSize = true;
            this.radioButton_cx_15_0.Checked = true;
            this.radioButton_cx_15_0.Location = new System.Drawing.Point(9, 52);
            this.radioButton_cx_15_0.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_cx_15_0.Name = "radioButton_cx_15_0";
            this.radioButton_cx_15_0.Size = new System.Drawing.Size(21, 20);
            this.radioButton_cx_15_0.TabIndex = 1;
            this.radioButton_cx_15_0.TabStop = true;
            this.radioButton_cx_15_0.UseVisualStyleBackColor = true;
            this.radioButton_cx_15_0.CheckedChanged += new System.EventHandler(this.radio_cx_click);
            // 
            // radioButton_cx_15_1
            // 
            this.radioButton_cx_15_1.AutoSize = true;
            this.radioButton_cx_15_1.Location = new System.Drawing.Point(9, 23);
            this.radioButton_cx_15_1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_cx_15_1.Name = "radioButton_cx_15_1";
            this.radioButton_cx_15_1.Size = new System.Drawing.Size(21, 20);
            this.radioButton_cx_15_1.TabIndex = 0;
            this.radioButton_cx_15_1.UseVisualStyleBackColor = true;
            this.radioButton_cx_15_1.CheckedChanged += new System.EventHandler(this.radio_cx_click);
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(147, 462);
            this.label39.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(18, 20);
            this.label39.TabIndex = 67;
            this.label39.Text = "0";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(147, 432);
            this.label40.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(18, 20);
            this.label40.TabIndex = 66;
            this.label40.Text = "1";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(742, 900);
            this.label17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(30, 20);
            this.label17.TabIndex = 152;
            this.label17.Text = "inL";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(402, 900);
            this.label20.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(33, 20);
            this.label20.TabIndex = 151;
            this.label20.Text = "inH";
            // 
            // label_inh_wartosc
            // 
            this.label_inh_wartosc.AutoSize = true;
            this.label_inh_wartosc.BackColor = System.Drawing.SystemColors.ControlDark;
            this.label_inh_wartosc.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_inh_wartosc.Location = new System.Drawing.Point(436, 858);
            this.label_inh_wartosc.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_inh_wartosc.Name = "label_inh_wartosc";
            this.label_inh_wartosc.Size = new System.Drawing.Size(151, 33);
            this.label_inh_wartosc.TabIndex = 150;
            this.label_inh_wartosc.Text = "00000000";
            // 
            // label_inl_wartosc
            // 
            this.label_inl_wartosc.AutoSize = true;
            this.label_inl_wartosc.BackColor = System.Drawing.SystemColors.ControlDark;
            this.label_inl_wartosc.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_inl_wartosc.Location = new System.Drawing.Point(592, 858);
            this.label_inl_wartosc.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_inl_wartosc.Name = "label_inl_wartosc";
            this.label_inl_wartosc.Size = new System.Drawing.Size(151, 33);
            this.label_inl_wartosc.TabIndex = 149;
            this.label_inl_wartosc.Text = "00000000";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(994, 831);
            this.label32.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(40, 20);
            this.label32.TabIndex = 147;
            this.label32.Text = "0-bit";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(994, 783);
            this.label38.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(18, 20);
            this.label38.TabIndex = 146;
            this.label38.Text = "0";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(994, 754);
            this.label41.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(18, 20);
            this.label41.TabIndex = 145;
            this.label41.Text = "1";
            // 
            // groupBox_in_1
            // 
            this.groupBox_in_1.Controls.Add(this.radioButton_in_1_0);
            this.groupBox_in_1.Controls.Add(this.radioButton_in_1_1);
            this.groupBox_in_1.Location = new System.Drawing.Point(896, 731);
            this.groupBox_in_1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_in_1.Name = "groupBox_in_1";
            this.groupBox_in_1.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_in_1.Size = new System.Drawing.Size(40, 94);
            this.groupBox_in_1.TabIndex = 136;
            this.groupBox_in_1.TabStop = false;
            // 
            // radioButton_in_1_0
            // 
            this.radioButton_in_1_0.AutoSize = true;
            this.radioButton_in_1_0.Checked = true;
            this.radioButton_in_1_0.Location = new System.Drawing.Point(9, 52);
            this.radioButton_in_1_0.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_in_1_0.Name = "radioButton_in_1_0";
            this.radioButton_in_1_0.Size = new System.Drawing.Size(21, 20);
            this.radioButton_in_1_0.TabIndex = 1;
            this.radioButton_in_1_0.TabStop = true;
            this.radioButton_in_1_0.UseVisualStyleBackColor = true;
            this.radioButton_in_1_0.CheckedChanged += new System.EventHandler(this.radio_in_click);
            // 
            // radioButton_in_1_1
            // 
            this.radioButton_in_1_1.AutoSize = true;
            this.radioButton_in_1_1.Location = new System.Drawing.Point(9, 23);
            this.radioButton_in_1_1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_in_1_1.Name = "radioButton_in_1_1";
            this.radioButton_in_1_1.Size = new System.Drawing.Size(21, 20);
            this.radioButton_in_1_1.TabIndex = 0;
            this.radioButton_in_1_1.UseVisualStyleBackColor = true;
            this.radioButton_in_1_1.CheckedChanged += new System.EventHandler(this.radio_in_click);
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label42.Location = new System.Drawing.Point(417, 695);
            this.label42.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(313, 29);
            this.label42.TabIndex = 138;
            this.label42.Text = "Argument natychmiastowy";
            // 
            // groupBox_in_0
            // 
            this.groupBox_in_0.Controls.Add(this.radioButton_in_0_0);
            this.groupBox_in_0.Controls.Add(this.radioButton_in_0_1);
            this.groupBox_in_0.Location = new System.Drawing.Point(945, 731);
            this.groupBox_in_0.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_in_0.Name = "groupBox_in_0";
            this.groupBox_in_0.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_in_0.Size = new System.Drawing.Size(40, 94);
            this.groupBox_in_0.TabIndex = 139;
            this.groupBox_in_0.TabStop = false;
            // 
            // radioButton_in_0_0
            // 
            this.radioButton_in_0_0.AutoSize = true;
            this.radioButton_in_0_0.Checked = true;
            this.radioButton_in_0_0.Location = new System.Drawing.Point(9, 52);
            this.radioButton_in_0_0.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_in_0_0.Name = "radioButton_in_0_0";
            this.radioButton_in_0_0.Size = new System.Drawing.Size(21, 20);
            this.radioButton_in_0_0.TabIndex = 1;
            this.radioButton_in_0_0.TabStop = true;
            this.radioButton_in_0_0.UseVisualStyleBackColor = true;
            this.radioButton_in_0_0.CheckedChanged += new System.EventHandler(this.radio_in_click);
            // 
            // radioButton_in_0_1
            // 
            this.radioButton_in_0_1.AutoSize = true;
            this.radioButton_in_0_1.Location = new System.Drawing.Point(9, 23);
            this.radioButton_in_0_1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_in_0_1.Name = "radioButton_in_0_1";
            this.radioButton_in_0_1.Size = new System.Drawing.Size(21, 20);
            this.radioButton_in_0_1.TabIndex = 0;
            this.radioButton_in_0_1.UseVisualStyleBackColor = true;
            this.radioButton_in_0_1.CheckedChanged += new System.EventHandler(this.radio_in_click);
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(112, 831);
            this.label43.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(49, 20);
            this.label43.TabIndex = 137;
            this.label43.Text = "15-bit";
            // 
            // groupBox_in_4
            // 
            this.groupBox_in_4.Controls.Add(this.radioButton_in_4_0);
            this.groupBox_in_4.Controls.Add(this.radioButton_in_4_1);
            this.groupBox_in_4.Location = new System.Drawing.Point(747, 731);
            this.groupBox_in_4.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_in_4.Name = "groupBox_in_4";
            this.groupBox_in_4.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_in_4.Size = new System.Drawing.Size(40, 94);
            this.groupBox_in_4.TabIndex = 140;
            this.groupBox_in_4.TabStop = false;
            // 
            // radioButton_in_4_0
            // 
            this.radioButton_in_4_0.AutoSize = true;
            this.radioButton_in_4_0.Checked = true;
            this.radioButton_in_4_0.Location = new System.Drawing.Point(9, 52);
            this.radioButton_in_4_0.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_in_4_0.Name = "radioButton_in_4_0";
            this.radioButton_in_4_0.Size = new System.Drawing.Size(21, 20);
            this.radioButton_in_4_0.TabIndex = 1;
            this.radioButton_in_4_0.TabStop = true;
            this.radioButton_in_4_0.UseVisualStyleBackColor = true;
            this.radioButton_in_4_0.CheckedChanged += new System.EventHandler(this.radio_in_click);
            // 
            // radioButton_in_4_1
            // 
            this.radioButton_in_4_1.AutoSize = true;
            this.radioButton_in_4_1.Location = new System.Drawing.Point(9, 23);
            this.radioButton_in_4_1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_in_4_1.Name = "radioButton_in_4_1";
            this.radioButton_in_4_1.Size = new System.Drawing.Size(21, 20);
            this.radioButton_in_4_1.TabIndex = 0;
            this.radioButton_in_4_1.UseVisualStyleBackColor = true;
            this.radioButton_in_4_1.CheckedChanged += new System.EventHandler(this.radio_in_click);
            // 
            // groupBox_in_3
            // 
            this.groupBox_in_3.Controls.Add(this.radioButton_in_3_0);
            this.groupBox_in_3.Controls.Add(this.radioButton_in_3_1);
            this.groupBox_in_3.Location = new System.Drawing.Point(796, 731);
            this.groupBox_in_3.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_in_3.Name = "groupBox_in_3";
            this.groupBox_in_3.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_in_3.Size = new System.Drawing.Size(40, 94);
            this.groupBox_in_3.TabIndex = 141;
            this.groupBox_in_3.TabStop = false;
            // 
            // radioButton_in_3_0
            // 
            this.radioButton_in_3_0.AutoSize = true;
            this.radioButton_in_3_0.Checked = true;
            this.radioButton_in_3_0.Location = new System.Drawing.Point(9, 52);
            this.radioButton_in_3_0.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_in_3_0.Name = "radioButton_in_3_0";
            this.radioButton_in_3_0.Size = new System.Drawing.Size(21, 20);
            this.radioButton_in_3_0.TabIndex = 1;
            this.radioButton_in_3_0.TabStop = true;
            this.radioButton_in_3_0.UseVisualStyleBackColor = true;
            this.radioButton_in_3_0.CheckedChanged += new System.EventHandler(this.radio_in_click);
            // 
            // radioButton_in_3_1
            // 
            this.radioButton_in_3_1.AutoSize = true;
            this.radioButton_in_3_1.Location = new System.Drawing.Point(9, 23);
            this.radioButton_in_3_1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_in_3_1.Name = "radioButton_in_3_1";
            this.radioButton_in_3_1.Size = new System.Drawing.Size(21, 20);
            this.radioButton_in_3_1.TabIndex = 0;
            this.radioButton_in_3_1.UseVisualStyleBackColor = true;
            this.radioButton_in_3_1.CheckedChanged += new System.EventHandler(this.radio_in_click);
            // 
            // groupBox_in_9
            // 
            this.groupBox_in_9.Controls.Add(this.radioButton_in_9_0);
            this.groupBox_in_9.Controls.Add(this.radioButton_in_9_1);
            this.groupBox_in_9.Location = new System.Drawing.Point(472, 731);
            this.groupBox_in_9.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_in_9.Name = "groupBox_in_9";
            this.groupBox_in_9.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_in_9.Size = new System.Drawing.Size(40, 94);
            this.groupBox_in_9.TabIndex = 131;
            this.groupBox_in_9.TabStop = false;
            // 
            // radioButton_in_9_0
            // 
            this.radioButton_in_9_0.AutoSize = true;
            this.radioButton_in_9_0.Checked = true;
            this.radioButton_in_9_0.Location = new System.Drawing.Point(9, 52);
            this.radioButton_in_9_0.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_in_9_0.Name = "radioButton_in_9_0";
            this.radioButton_in_9_0.Size = new System.Drawing.Size(21, 20);
            this.radioButton_in_9_0.TabIndex = 1;
            this.radioButton_in_9_0.TabStop = true;
            this.radioButton_in_9_0.UseVisualStyleBackColor = true;
            this.radioButton_in_9_0.CheckedChanged += new System.EventHandler(this.radio_in_click);
            // 
            // radioButton_in_9_1
            // 
            this.radioButton_in_9_1.AutoSize = true;
            this.radioButton_in_9_1.Location = new System.Drawing.Point(9, 23);
            this.radioButton_in_9_1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_in_9_1.Name = "radioButton_in_9_1";
            this.radioButton_in_9_1.Size = new System.Drawing.Size(21, 20);
            this.radioButton_in_9_1.TabIndex = 0;
            this.radioButton_in_9_1.UseVisualStyleBackColor = true;
            this.radioButton_in_9_1.CheckedChanged += new System.EventHandler(this.radio_in_click);
            // 
            // groupBox_in_2
            // 
            this.groupBox_in_2.Controls.Add(this.radioButton_in_2_0);
            this.groupBox_in_2.Controls.Add(this.radioButton_in_2_1);
            this.groupBox_in_2.Location = new System.Drawing.Point(846, 731);
            this.groupBox_in_2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_in_2.Name = "groupBox_in_2";
            this.groupBox_in_2.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_in_2.Size = new System.Drawing.Size(40, 94);
            this.groupBox_in_2.TabIndex = 142;
            this.groupBox_in_2.TabStop = false;
            // 
            // radioButton_in_2_0
            // 
            this.radioButton_in_2_0.AutoSize = true;
            this.radioButton_in_2_0.Checked = true;
            this.radioButton_in_2_0.Location = new System.Drawing.Point(9, 52);
            this.radioButton_in_2_0.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_in_2_0.Name = "radioButton_in_2_0";
            this.radioButton_in_2_0.Size = new System.Drawing.Size(21, 20);
            this.radioButton_in_2_0.TabIndex = 1;
            this.radioButton_in_2_0.TabStop = true;
            this.radioButton_in_2_0.UseVisualStyleBackColor = true;
            this.radioButton_in_2_0.CheckedChanged += new System.EventHandler(this.radio_in_click);
            // 
            // radioButton_in_2_1
            // 
            this.radioButton_in_2_1.AutoSize = true;
            this.radioButton_in_2_1.Location = new System.Drawing.Point(9, 23);
            this.radioButton_in_2_1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_in_2_1.Name = "radioButton_in_2_1";
            this.radioButton_in_2_1.Size = new System.Drawing.Size(21, 20);
            this.radioButton_in_2_1.TabIndex = 0;
            this.radioButton_in_2_1.UseVisualStyleBackColor = true;
            this.radioButton_in_2_1.CheckedChanged += new System.EventHandler(this.radio_in_click);
            // 
            // groupBox_in_8
            // 
            this.groupBox_in_8.Controls.Add(this.radioButton_in_8_0);
            this.groupBox_in_8.Controls.Add(this.radioButton_in_8_1);
            this.groupBox_in_8.Location = new System.Drawing.Point(522, 731);
            this.groupBox_in_8.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_in_8.Name = "groupBox_in_8";
            this.groupBox_in_8.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_in_8.Size = new System.Drawing.Size(40, 94);
            this.groupBox_in_8.TabIndex = 133;
            this.groupBox_in_8.TabStop = false;
            // 
            // radioButton_in_8_0
            // 
            this.radioButton_in_8_0.AutoSize = true;
            this.radioButton_in_8_0.Checked = true;
            this.radioButton_in_8_0.Location = new System.Drawing.Point(9, 52);
            this.radioButton_in_8_0.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_in_8_0.Name = "radioButton_in_8_0";
            this.radioButton_in_8_0.Size = new System.Drawing.Size(21, 20);
            this.radioButton_in_8_0.TabIndex = 1;
            this.radioButton_in_8_0.TabStop = true;
            this.radioButton_in_8_0.UseVisualStyleBackColor = true;
            this.radioButton_in_8_0.CheckedChanged += new System.EventHandler(this.radio_in_click);
            // 
            // radioButton_in_8_1
            // 
            this.radioButton_in_8_1.AutoSize = true;
            this.radioButton_in_8_1.Location = new System.Drawing.Point(9, 23);
            this.radioButton_in_8_1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_in_8_1.Name = "radioButton_in_8_1";
            this.radioButton_in_8_1.Size = new System.Drawing.Size(21, 20);
            this.radioButton_in_8_1.TabIndex = 0;
            this.radioButton_in_8_1.UseVisualStyleBackColor = true;
            this.radioButton_in_8_1.CheckedChanged += new System.EventHandler(this.radio_in_click);
            // 
            // groupBox_in_6
            // 
            this.groupBox_in_6.Controls.Add(this.radioButton_in_6_0);
            this.groupBox_in_6.Controls.Add(this.radioButton_in_6_1);
            this.groupBox_in_6.Location = new System.Drawing.Point(648, 731);
            this.groupBox_in_6.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_in_6.Name = "groupBox_in_6";
            this.groupBox_in_6.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_in_6.Size = new System.Drawing.Size(40, 94);
            this.groupBox_in_6.TabIndex = 143;
            this.groupBox_in_6.TabStop = false;
            // 
            // radioButton_in_6_0
            // 
            this.radioButton_in_6_0.AutoSize = true;
            this.radioButton_in_6_0.Checked = true;
            this.radioButton_in_6_0.Location = new System.Drawing.Point(9, 52);
            this.radioButton_in_6_0.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_in_6_0.Name = "radioButton_in_6_0";
            this.radioButton_in_6_0.Size = new System.Drawing.Size(21, 20);
            this.radioButton_in_6_0.TabIndex = 1;
            this.radioButton_in_6_0.TabStop = true;
            this.radioButton_in_6_0.UseVisualStyleBackColor = true;
            this.radioButton_in_6_0.CheckedChanged += new System.EventHandler(this.radio_in_click);
            // 
            // radioButton_in_6_1
            // 
            this.radioButton_in_6_1.AutoSize = true;
            this.radioButton_in_6_1.Location = new System.Drawing.Point(9, 23);
            this.radioButton_in_6_1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_in_6_1.Name = "radioButton_in_6_1";
            this.radioButton_in_6_1.Size = new System.Drawing.Size(21, 20);
            this.radioButton_in_6_1.TabIndex = 0;
            this.radioButton_in_6_1.UseVisualStyleBackColor = true;
            this.radioButton_in_6_1.CheckedChanged += new System.EventHandler(this.radio_in_click);
            // 
            // groupBox_in_12
            // 
            this.groupBox_in_12.Controls.Add(this.radioButton_in_12_0);
            this.groupBox_in_12.Controls.Add(this.radioButton_in_12_1);
            this.groupBox_in_12.Location = new System.Drawing.Point(324, 731);
            this.groupBox_in_12.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_in_12.Name = "groupBox_in_12";
            this.groupBox_in_12.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_in_12.Size = new System.Drawing.Size(40, 94);
            this.groupBox_in_12.TabIndex = 132;
            this.groupBox_in_12.TabStop = false;
            // 
            // radioButton_in_12_0
            // 
            this.radioButton_in_12_0.AutoSize = true;
            this.radioButton_in_12_0.Checked = true;
            this.radioButton_in_12_0.Location = new System.Drawing.Point(9, 52);
            this.radioButton_in_12_0.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_in_12_0.Name = "radioButton_in_12_0";
            this.radioButton_in_12_0.Size = new System.Drawing.Size(21, 20);
            this.radioButton_in_12_0.TabIndex = 1;
            this.radioButton_in_12_0.TabStop = true;
            this.radioButton_in_12_0.UseVisualStyleBackColor = true;
            this.radioButton_in_12_0.CheckedChanged += new System.EventHandler(this.radio_in_click);
            // 
            // radioButton_in_12_1
            // 
            this.radioButton_in_12_1.AutoSize = true;
            this.radioButton_in_12_1.Location = new System.Drawing.Point(9, 23);
            this.radioButton_in_12_1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_in_12_1.Name = "radioButton_in_12_1";
            this.radioButton_in_12_1.Size = new System.Drawing.Size(21, 20);
            this.radioButton_in_12_1.TabIndex = 0;
            this.radioButton_in_12_1.UseVisualStyleBackColor = true;
            this.radioButton_in_12_1.CheckedChanged += new System.EventHandler(this.radio_in_click);
            // 
            // groupBox_in_5
            // 
            this.groupBox_in_5.Controls.Add(this.radioButton_in_5_0);
            this.groupBox_in_5.Controls.Add(this.radioButton_in_5_1);
            this.groupBox_in_5.Location = new System.Drawing.Point(698, 731);
            this.groupBox_in_5.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_in_5.Name = "groupBox_in_5";
            this.groupBox_in_5.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_in_5.Size = new System.Drawing.Size(40, 94);
            this.groupBox_in_5.TabIndex = 144;
            this.groupBox_in_5.TabStop = false;
            // 
            // radioButton_in_5_0
            // 
            this.radioButton_in_5_0.AutoSize = true;
            this.radioButton_in_5_0.Checked = true;
            this.radioButton_in_5_0.Location = new System.Drawing.Point(9, 52);
            this.radioButton_in_5_0.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_in_5_0.Name = "radioButton_in_5_0";
            this.radioButton_in_5_0.Size = new System.Drawing.Size(21, 20);
            this.radioButton_in_5_0.TabIndex = 1;
            this.radioButton_in_5_0.TabStop = true;
            this.radioButton_in_5_0.UseVisualStyleBackColor = true;
            this.radioButton_in_5_0.CheckedChanged += new System.EventHandler(this.radio_in_click);
            // 
            // radioButton_in_5_1
            // 
            this.radioButton_in_5_1.AutoSize = true;
            this.radioButton_in_5_1.Location = new System.Drawing.Point(9, 23);
            this.radioButton_in_5_1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_in_5_1.Name = "radioButton_in_5_1";
            this.radioButton_in_5_1.Size = new System.Drawing.Size(21, 20);
            this.radioButton_in_5_1.TabIndex = 0;
            this.radioButton_in_5_1.UseVisualStyleBackColor = true;
            this.radioButton_in_5_1.CheckedChanged += new System.EventHandler(this.radio_in_click);
            // 
            // groupBox_in_11
            // 
            this.groupBox_in_11.Controls.Add(this.radioButton_in_11_0);
            this.groupBox_in_11.Controls.Add(this.radioButton_in_11_1);
            this.groupBox_in_11.Location = new System.Drawing.Point(374, 731);
            this.groupBox_in_11.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_in_11.Name = "groupBox_in_11";
            this.groupBox_in_11.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_in_11.Size = new System.Drawing.Size(40, 94);
            this.groupBox_in_11.TabIndex = 130;
            this.groupBox_in_11.TabStop = false;
            // 
            // radioButton_in_11_0
            // 
            this.radioButton_in_11_0.AutoSize = true;
            this.radioButton_in_11_0.Checked = true;
            this.radioButton_in_11_0.Location = new System.Drawing.Point(9, 52);
            this.radioButton_in_11_0.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_in_11_0.Name = "radioButton_in_11_0";
            this.radioButton_in_11_0.Size = new System.Drawing.Size(21, 20);
            this.radioButton_in_11_0.TabIndex = 1;
            this.radioButton_in_11_0.TabStop = true;
            this.radioButton_in_11_0.UseVisualStyleBackColor = true;
            this.radioButton_in_11_0.CheckedChanged += new System.EventHandler(this.radio_in_click);
            // 
            // radioButton_in_11_1
            // 
            this.radioButton_in_11_1.AutoSize = true;
            this.radioButton_in_11_1.Location = new System.Drawing.Point(9, 23);
            this.radioButton_in_11_1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_in_11_1.Name = "radioButton_in_11_1";
            this.radioButton_in_11_1.Size = new System.Drawing.Size(21, 20);
            this.radioButton_in_11_1.TabIndex = 0;
            this.radioButton_in_11_1.UseVisualStyleBackColor = true;
            this.radioButton_in_11_1.CheckedChanged += new System.EventHandler(this.radio_in_click);
            // 
            // groupBox_in_7
            // 
            this.groupBox_in_7.Controls.Add(this.radioButton_in_7_0);
            this.groupBox_in_7.Controls.Add(this.radioButton_in_7_1);
            this.groupBox_in_7.Location = new System.Drawing.Point(598, 731);
            this.groupBox_in_7.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_in_7.Name = "groupBox_in_7";
            this.groupBox_in_7.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_in_7.Size = new System.Drawing.Size(40, 94);
            this.groupBox_in_7.TabIndex = 135;
            this.groupBox_in_7.TabStop = false;
            // 
            // radioButton_in_7_0
            // 
            this.radioButton_in_7_0.AutoSize = true;
            this.radioButton_in_7_0.Checked = true;
            this.radioButton_in_7_0.Location = new System.Drawing.Point(9, 52);
            this.radioButton_in_7_0.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_in_7_0.Name = "radioButton_in_7_0";
            this.radioButton_in_7_0.Size = new System.Drawing.Size(21, 20);
            this.radioButton_in_7_0.TabIndex = 1;
            this.radioButton_in_7_0.TabStop = true;
            this.radioButton_in_7_0.UseVisualStyleBackColor = true;
            this.radioButton_in_7_0.CheckedChanged += new System.EventHandler(this.radio_in_click);
            // 
            // radioButton_in_7_1
            // 
            this.radioButton_in_7_1.AutoSize = true;
            this.radioButton_in_7_1.Location = new System.Drawing.Point(9, 23);
            this.radioButton_in_7_1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_in_7_1.Name = "radioButton_in_7_1";
            this.radioButton_in_7_1.Size = new System.Drawing.Size(21, 20);
            this.radioButton_in_7_1.TabIndex = 0;
            this.radioButton_in_7_1.UseVisualStyleBackColor = true;
            this.radioButton_in_7_1.CheckedChanged += new System.EventHandler(this.radio_in_click);
            // 
            // groupBox_in_10
            // 
            this.groupBox_in_10.Controls.Add(this.radioButton_in_10_0);
            this.groupBox_in_10.Controls.Add(this.radioButton_in_10_1);
            this.groupBox_in_10.Location = new System.Drawing.Point(423, 731);
            this.groupBox_in_10.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_in_10.Name = "groupBox_in_10";
            this.groupBox_in_10.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_in_10.Size = new System.Drawing.Size(40, 94);
            this.groupBox_in_10.TabIndex = 129;
            this.groupBox_in_10.TabStop = false;
            // 
            // radioButton_in_10_0
            // 
            this.radioButton_in_10_0.AutoSize = true;
            this.radioButton_in_10_0.Checked = true;
            this.radioButton_in_10_0.Location = new System.Drawing.Point(9, 52);
            this.radioButton_in_10_0.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_in_10_0.Name = "radioButton_in_10_0";
            this.radioButton_in_10_0.Size = new System.Drawing.Size(21, 20);
            this.radioButton_in_10_0.TabIndex = 1;
            this.radioButton_in_10_0.TabStop = true;
            this.radioButton_in_10_0.UseVisualStyleBackColor = true;
            this.radioButton_in_10_0.CheckedChanged += new System.EventHandler(this.radio_in_click);
            // 
            // radioButton_in_10_1
            // 
            this.radioButton_in_10_1.AutoSize = true;
            this.radioButton_in_10_1.Location = new System.Drawing.Point(9, 23);
            this.radioButton_in_10_1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_in_10_1.Name = "radioButton_in_10_1";
            this.radioButton_in_10_1.Size = new System.Drawing.Size(21, 20);
            this.radioButton_in_10_1.TabIndex = 0;
            this.radioButton_in_10_1.UseVisualStyleBackColor = true;
            this.radioButton_in_10_1.CheckedChanged += new System.EventHandler(this.radio_in_click);
            // 
            // groupBox_in_14
            // 
            this.groupBox_in_14.Controls.Add(this.radioButton_in_14_0);
            this.groupBox_in_14.Controls.Add(this.radioButton_in_14_1);
            this.groupBox_in_14.Location = new System.Drawing.Point(225, 731);
            this.groupBox_in_14.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_in_14.Name = "groupBox_in_14";
            this.groupBox_in_14.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_in_14.Size = new System.Drawing.Size(40, 94);
            this.groupBox_in_14.TabIndex = 128;
            this.groupBox_in_14.TabStop = false;
            // 
            // radioButton_in_14_0
            // 
            this.radioButton_in_14_0.AutoSize = true;
            this.radioButton_in_14_0.Checked = true;
            this.radioButton_in_14_0.Location = new System.Drawing.Point(9, 52);
            this.radioButton_in_14_0.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_in_14_0.Name = "radioButton_in_14_0";
            this.radioButton_in_14_0.Size = new System.Drawing.Size(21, 20);
            this.radioButton_in_14_0.TabIndex = 1;
            this.radioButton_in_14_0.TabStop = true;
            this.radioButton_in_14_0.UseVisualStyleBackColor = true;
            this.radioButton_in_14_0.CheckedChanged += new System.EventHandler(this.radio_in_click);
            // 
            // radioButton_in_14_1
            // 
            this.radioButton_in_14_1.AutoSize = true;
            this.radioButton_in_14_1.Location = new System.Drawing.Point(9, 23);
            this.radioButton_in_14_1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_in_14_1.Name = "radioButton_in_14_1";
            this.radioButton_in_14_1.Size = new System.Drawing.Size(21, 20);
            this.radioButton_in_14_1.TabIndex = 0;
            this.radioButton_in_14_1.UseVisualStyleBackColor = true;
            this.radioButton_in_14_1.CheckedChanged += new System.EventHandler(this.radio_in_click);
            // 
            // groupBox_in_13
            // 
            this.groupBox_in_13.Controls.Add(this.radioButton_in_13_0);
            this.groupBox_in_13.Controls.Add(this.radioButton_in_13_1);
            this.groupBox_in_13.Location = new System.Drawing.Point(274, 731);
            this.groupBox_in_13.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_in_13.Name = "groupBox_in_13";
            this.groupBox_in_13.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_in_13.Size = new System.Drawing.Size(40, 94);
            this.groupBox_in_13.TabIndex = 127;
            this.groupBox_in_13.TabStop = false;
            // 
            // radioButton_in_13_0
            // 
            this.radioButton_in_13_0.AutoSize = true;
            this.radioButton_in_13_0.Checked = true;
            this.radioButton_in_13_0.Location = new System.Drawing.Point(9, 52);
            this.radioButton_in_13_0.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_in_13_0.Name = "radioButton_in_13_0";
            this.radioButton_in_13_0.Size = new System.Drawing.Size(21, 20);
            this.radioButton_in_13_0.TabIndex = 1;
            this.radioButton_in_13_0.TabStop = true;
            this.radioButton_in_13_0.UseVisualStyleBackColor = true;
            this.radioButton_in_13_0.CheckedChanged += new System.EventHandler(this.radio_in_click);
            // 
            // radioButton_in_13_1
            // 
            this.radioButton_in_13_1.AutoSize = true;
            this.radioButton_in_13_1.Location = new System.Drawing.Point(9, 23);
            this.radioButton_in_13_1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_in_13_1.Name = "radioButton_in_13_1";
            this.radioButton_in_13_1.Size = new System.Drawing.Size(21, 20);
            this.radioButton_in_13_1.TabIndex = 0;
            this.radioButton_in_13_1.UseVisualStyleBackColor = true;
            this.radioButton_in_13_1.CheckedChanged += new System.EventHandler(this.radio_in_click);
            // 
            // groupBox_in_15
            // 
            this.groupBox_in_15.Controls.Add(this.radioButton_in_15_0);
            this.groupBox_in_15.Controls.Add(this.radioButton_in_15_1);
            this.groupBox_in_15.Location = new System.Drawing.Point(176, 731);
            this.groupBox_in_15.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_in_15.Name = "groupBox_in_15";
            this.groupBox_in_15.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox_in_15.Size = new System.Drawing.Size(40, 94);
            this.groupBox_in_15.TabIndex = 126;
            this.groupBox_in_15.TabStop = false;
            // 
            // radioButton_in_15_0
            // 
            this.radioButton_in_15_0.AutoSize = true;
            this.radioButton_in_15_0.Checked = true;
            this.radioButton_in_15_0.Location = new System.Drawing.Point(9, 52);
            this.radioButton_in_15_0.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_in_15_0.Name = "radioButton_in_15_0";
            this.radioButton_in_15_0.Size = new System.Drawing.Size(21, 20);
            this.radioButton_in_15_0.TabIndex = 1;
            this.radioButton_in_15_0.TabStop = true;
            this.radioButton_in_15_0.UseVisualStyleBackColor = true;
            this.radioButton_in_15_0.CheckedChanged += new System.EventHandler(this.radio_in_click);
            // 
            // radioButton_in_15_1
            // 
            this.radioButton_in_15_1.AutoSize = true;
            this.radioButton_in_15_1.Location = new System.Drawing.Point(9, 23);
            this.radioButton_in_15_1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton_in_15_1.Name = "radioButton_in_15_1";
            this.radioButton_in_15_1.Size = new System.Drawing.Size(21, 20);
            this.radioButton_in_15_1.TabIndex = 0;
            this.radioButton_in_15_1.UseVisualStyleBackColor = true;
            this.radioButton_in_15_1.CheckedChanged += new System.EventHandler(this.radio_in_click);
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(147, 783);
            this.label45.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(18, 20);
            this.label45.TabIndex = 125;
            this.label45.Text = "0";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(147, 754);
            this.label46.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(18, 20);
            this.label46.TabIndex = 124;
            this.label46.Text = "1";
            // 
            // comboBox_instrukcja
            // 
            this.comboBox_instrukcja.FormattingEnabled = true;
            this.comboBox_instrukcja.Items.AddRange(new object[] {
            "MOV",
            "ADD",
            "SUB"});
            this.comboBox_instrukcja.Location = new System.Drawing.Point(1265, 731);
            this.comboBox_instrukcja.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.comboBox_instrukcja.Name = "comboBox_instrukcja";
            this.comboBox_instrukcja.Size = new System.Drawing.Size(180, 28);
            this.comboBox_instrukcja.TabIndex = 153;
            this.comboBox_instrukcja.Text = "Instrukcja";
            // 
            // comboBox_arg1
            // 
            this.comboBox_arg1.FormattingEnabled = true;
            this.comboBox_arg1.Items.AddRange(new object[] {
            "AX",
            "AH",
            "AL",
            "BX",
            "BH",
            "BL",
            "CX",
            "CH",
            "CL",
            "DX",
            "DH",
            "DL"});
            this.comboBox_arg1.Location = new System.Drawing.Point(1265, 797);
            this.comboBox_arg1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.comboBox_arg1.Name = "comboBox_arg1";
            this.comboBox_arg1.Size = new System.Drawing.Size(180, 28);
            this.comboBox_arg1.TabIndex = 154;
            this.comboBox_arg1.Text = "1. argument";
            // 
            // comboBox_arg2
            // 
            this.comboBox_arg2.FormattingEnabled = true;
            this.comboBox_arg2.Items.AddRange(new object[] {
            "AX",
            "AH",
            "AL",
            "BX",
            "BH",
            "BL",
            "CX",
            "CH",
            "CL",
            "DX",
            "DH",
            "DL",
            "Argument natychmiastowy"});
            this.comboBox_arg2.Location = new System.Drawing.Point(1265, 858);
            this.comboBox_arg2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.comboBox_arg2.Name = "comboBox_arg2";
            this.comboBox_arg2.Size = new System.Drawing.Size(180, 28);
            this.comboBox_arg2.TabIndex = 155;
            this.comboBox_arg2.Text = "2. argument";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(1511, 774);
            this.button1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(207, 72);
            this.button1.TabIndex = 156;
            this.button1.Text = "Wykonaj rozkaz";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(1522, 859);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(186, 40);
            this.button2.TabIndex = 157;
            this.button2.Text = "Wyswietl kod";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1924, 1050);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.comboBox_arg2);
            this.Controls.Add(this.comboBox_arg1);
            this.Controls.Add(this.comboBox_instrukcja);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label_inh_wartosc);
            this.Controls.Add(this.label_inl_wartosc);
            this.Controls.Add(this.label32);
            this.Controls.Add(this.label38);
            this.Controls.Add(this.label41);
            this.Controls.Add(this.groupBox_in_1);
            this.Controls.Add(this.label42);
            this.Controls.Add(this.groupBox_in_0);
            this.Controls.Add(this.label43);
            this.Controls.Add(this.groupBox_in_4);
            this.Controls.Add(this.groupBox_in_3);
            this.Controls.Add(this.groupBox_in_9);
            this.Controls.Add(this.groupBox_in_2);
            this.Controls.Add(this.groupBox_in_8);
            this.Controls.Add(this.groupBox_in_6);
            this.Controls.Add(this.groupBox_in_12);
            this.Controls.Add(this.groupBox_in_5);
            this.Controls.Add(this.groupBox_in_11);
            this.Controls.Add(this.groupBox_in_7);
            this.Controls.Add(this.groupBox_in_10);
            this.Controls.Add(this.groupBox_in_14);
            this.Controls.Add(this.groupBox_in_13);
            this.Controls.Add(this.groupBox_in_15);
            this.Controls.Add(this.label45);
            this.Controls.Add(this.label46);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label_dh_wartosc);
            this.Controls.Add(this.label_dl_wartosc);
            this.Controls.Add(this.button_dx);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.groupBox_dx_1);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.groupBox_dx_0);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.groupBox_dx_4);
            this.Controls.Add(this.label_dx);
            this.Controls.Add(this.groupBox_dx_3);
            this.Controls.Add(this.groupBox_dx_9);
            this.Controls.Add(this.groupBox_dx_2);
            this.Controls.Add(this.groupBox_dx_8);
            this.Controls.Add(this.groupBox_dx_6);
            this.Controls.Add(this.groupBox_dx_12);
            this.Controls.Add(this.groupBox_dx_5);
            this.Controls.Add(this.groupBox_dx_11);
            this.Controls.Add(this.groupBox_dx_7);
            this.Controls.Add(this.groupBox_dx_10);
            this.Controls.Add(this.groupBox_dx_14);
            this.Controls.Add(this.groupBox_dx_13);
            this.Controls.Add(this.groupBox_dx_15);
            this.Controls.Add(this.label27);
            this.Controls.Add(this.label28);
            this.Controls.Add(this.label29);
            this.Controls.Add(this.label30);
            this.Controls.Add(this.label_ch_wartosc);
            this.Controls.Add(this.label_cl_wartosc);
            this.Controls.Add(this.button_cx);
            this.Controls.Add(this.label33);
            this.Controls.Add(this.label34);
            this.Controls.Add(this.label35);
            this.Controls.Add(this.groupBox_cx_1);
            this.Controls.Add(this.label36);
            this.Controls.Add(this.groupBox_cx_0);
            this.Controls.Add(this.label37);
            this.Controls.Add(this.groupBox_cx_4);
            this.Controls.Add(this.label_cx);
            this.Controls.Add(this.groupBox_cx_3);
            this.Controls.Add(this.groupBox_cx_9);
            this.Controls.Add(this.groupBox_cx_2);
            this.Controls.Add(this.groupBox_cx_8);
            this.Controls.Add(this.groupBox_cx_6);
            this.Controls.Add(this.groupBox_cx_12);
            this.Controls.Add(this.groupBox_cx_5);
            this.Controls.Add(this.groupBox_cx_11);
            this.Controls.Add(this.groupBox_cx_7);
            this.Controls.Add(this.groupBox_cx_10);
            this.Controls.Add(this.groupBox_cx_14);
            this.Controls.Add(this.groupBox_cx_13);
            this.Controls.Add(this.groupBox_cx_15);
            this.Controls.Add(this.label39);
            this.Controls.Add(this.label40);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label_bh_wartosc);
            this.Controls.Add(this.label_bl_wartosc);
            this.Controls.Add(this.button_bx);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.groupBox_bx_1);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.groupBox_bx_0);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.groupBox_bx_4);
            this.Controls.Add(this.label_bx);
            this.Controls.Add(this.groupBox_bx_3);
            this.Controls.Add(this.groupBox_bx_9);
            this.Controls.Add(this.groupBox_bx_2);
            this.Controls.Add(this.groupBox_bx_8);
            this.Controls.Add(this.groupBox_bx_6);
            this.Controls.Add(this.groupBox_bx_12);
            this.Controls.Add(this.groupBox_bx_5);
            this.Controls.Add(this.groupBox_bx_11);
            this.Controls.Add(this.groupBox_bx_7);
            this.Controls.Add(this.groupBox_bx_10);
            this.Controls.Add(this.groupBox_bx_14);
            this.Controls.Add(this.groupBox_bx_13);
            this.Controls.Add(this.groupBox_bx_15);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label_ah_wartosc);
            this.Controls.Add(this.label_al_wartosc);
            this.Controls.Add(this.button_ax);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.groupBox_ax_1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.groupBox_ax_0);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.groupBox_ax_4);
            this.Controls.Add(this.label_ax);
            this.Controls.Add(this.groupBox_ax_3);
            this.Controls.Add(this.groupBox_ax_9);
            this.Controls.Add(this.groupBox_ax_2);
            this.Controls.Add(this.groupBox_ax_8);
            this.Controls.Add(this.groupBox_ax_6);
            this.Controls.Add(this.groupBox_ax_12);
            this.Controls.Add(this.groupBox_ax_5);
            this.Controls.Add(this.groupBox_ax_11);
            this.Controls.Add(this.groupBox_ax_7);
            this.Controls.Add(this.groupBox_ax_10);
            this.Controls.Add(this.groupBox_ax_14);
            this.Controls.Add(this.groupBox_ax_13);
            this.Controls.Add(this.groupBox_ax_15);
            this.Controls.Add(this.label_ax_0);
            this.Controls.Add(this.label_ax_1);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "Form1";
            this.Text = "Symulator mikroprocesora";
            this.groupBox_ax_15.ResumeLayout(false);
            this.groupBox_ax_15.PerformLayout();
            this.groupBox_ax_10.ResumeLayout(false);
            this.groupBox_ax_10.PerformLayout();
            this.groupBox_ax_14.ResumeLayout(false);
            this.groupBox_ax_14.PerformLayout();
            this.groupBox_ax_8.ResumeLayout(false);
            this.groupBox_ax_8.PerformLayout();
            this.groupBox_ax_12.ResumeLayout(false);
            this.groupBox_ax_12.PerformLayout();
            this.groupBox_ax_11.ResumeLayout(false);
            this.groupBox_ax_11.PerformLayout();
            this.groupBox_ax_9.ResumeLayout(false);
            this.groupBox_ax_9.PerformLayout();
            this.groupBox_ax_13.ResumeLayout(false);
            this.groupBox_ax_13.PerformLayout();
            this.groupBox_ax_1.ResumeLayout(false);
            this.groupBox_ax_1.PerformLayout();
            this.groupBox_ax_0.ResumeLayout(false);
            this.groupBox_ax_0.PerformLayout();
            this.groupBox_ax_4.ResumeLayout(false);
            this.groupBox_ax_4.PerformLayout();
            this.groupBox_ax_3.ResumeLayout(false);
            this.groupBox_ax_3.PerformLayout();
            this.groupBox_ax_2.ResumeLayout(false);
            this.groupBox_ax_2.PerformLayout();
            this.groupBox_ax_6.ResumeLayout(false);
            this.groupBox_ax_6.PerformLayout();
            this.groupBox_ax_5.ResumeLayout(false);
            this.groupBox_ax_5.PerformLayout();
            this.groupBox_ax_7.ResumeLayout(false);
            this.groupBox_ax_7.PerformLayout();
            this.groupBox_bx_1.ResumeLayout(false);
            this.groupBox_bx_1.PerformLayout();
            this.groupBox_bx_0.ResumeLayout(false);
            this.groupBox_bx_0.PerformLayout();
            this.groupBox_bx_4.ResumeLayout(false);
            this.groupBox_bx_4.PerformLayout();
            this.groupBox_bx_3.ResumeLayout(false);
            this.groupBox_bx_3.PerformLayout();
            this.groupBox_bx_9.ResumeLayout(false);
            this.groupBox_bx_9.PerformLayout();
            this.groupBox_bx_2.ResumeLayout(false);
            this.groupBox_bx_2.PerformLayout();
            this.groupBox_bx_8.ResumeLayout(false);
            this.groupBox_bx_8.PerformLayout();
            this.groupBox_bx_6.ResumeLayout(false);
            this.groupBox_bx_6.PerformLayout();
            this.groupBox_bx_12.ResumeLayout(false);
            this.groupBox_bx_12.PerformLayout();
            this.groupBox_bx_5.ResumeLayout(false);
            this.groupBox_bx_5.PerformLayout();
            this.groupBox_bx_11.ResumeLayout(false);
            this.groupBox_bx_11.PerformLayout();
            this.groupBox_bx_7.ResumeLayout(false);
            this.groupBox_bx_7.PerformLayout();
            this.groupBox_bx_10.ResumeLayout(false);
            this.groupBox_bx_10.PerformLayout();
            this.groupBox_bx_14.ResumeLayout(false);
            this.groupBox_bx_14.PerformLayout();
            this.groupBox_bx_13.ResumeLayout(false);
            this.groupBox_bx_13.PerformLayout();
            this.groupBox_bx_15.ResumeLayout(false);
            this.groupBox_bx_15.PerformLayout();
            this.groupBox_dx_1.ResumeLayout(false);
            this.groupBox_dx_1.PerformLayout();
            this.groupBox_dx_0.ResumeLayout(false);
            this.groupBox_dx_0.PerformLayout();
            this.groupBox_dx_4.ResumeLayout(false);
            this.groupBox_dx_4.PerformLayout();
            this.groupBox_dx_3.ResumeLayout(false);
            this.groupBox_dx_3.PerformLayout();
            this.groupBox_dx_9.ResumeLayout(false);
            this.groupBox_dx_9.PerformLayout();
            this.groupBox_dx_2.ResumeLayout(false);
            this.groupBox_dx_2.PerformLayout();
            this.groupBox_dx_8.ResumeLayout(false);
            this.groupBox_dx_8.PerformLayout();
            this.groupBox_dx_6.ResumeLayout(false);
            this.groupBox_dx_6.PerformLayout();
            this.groupBox_dx_12.ResumeLayout(false);
            this.groupBox_dx_12.PerformLayout();
            this.groupBox_dx_5.ResumeLayout(false);
            this.groupBox_dx_5.PerformLayout();
            this.groupBox_dx_11.ResumeLayout(false);
            this.groupBox_dx_11.PerformLayout();
            this.groupBox_dx_7.ResumeLayout(false);
            this.groupBox_dx_7.PerformLayout();
            this.groupBox_dx_10.ResumeLayout(false);
            this.groupBox_dx_10.PerformLayout();
            this.groupBox_dx_14.ResumeLayout(false);
            this.groupBox_dx_14.PerformLayout();
            this.groupBox_dx_13.ResumeLayout(false);
            this.groupBox_dx_13.PerformLayout();
            this.groupBox_dx_15.ResumeLayout(false);
            this.groupBox_dx_15.PerformLayout();
            this.groupBox_cx_1.ResumeLayout(false);
            this.groupBox_cx_1.PerformLayout();
            this.groupBox_cx_0.ResumeLayout(false);
            this.groupBox_cx_0.PerformLayout();
            this.groupBox_cx_4.ResumeLayout(false);
            this.groupBox_cx_4.PerformLayout();
            this.groupBox_cx_3.ResumeLayout(false);
            this.groupBox_cx_3.PerformLayout();
            this.groupBox_cx_9.ResumeLayout(false);
            this.groupBox_cx_9.PerformLayout();
            this.groupBox_cx_2.ResumeLayout(false);
            this.groupBox_cx_2.PerformLayout();
            this.groupBox_cx_8.ResumeLayout(false);
            this.groupBox_cx_8.PerformLayout();
            this.groupBox_cx_6.ResumeLayout(false);
            this.groupBox_cx_6.PerformLayout();
            this.groupBox_cx_12.ResumeLayout(false);
            this.groupBox_cx_12.PerformLayout();
            this.groupBox_cx_5.ResumeLayout(false);
            this.groupBox_cx_5.PerformLayout();
            this.groupBox_cx_11.ResumeLayout(false);
            this.groupBox_cx_11.PerformLayout();
            this.groupBox_cx_7.ResumeLayout(false);
            this.groupBox_cx_7.PerformLayout();
            this.groupBox_cx_10.ResumeLayout(false);
            this.groupBox_cx_10.PerformLayout();
            this.groupBox_cx_14.ResumeLayout(false);
            this.groupBox_cx_14.PerformLayout();
            this.groupBox_cx_13.ResumeLayout(false);
            this.groupBox_cx_13.PerformLayout();
            this.groupBox_cx_15.ResumeLayout(false);
            this.groupBox_cx_15.PerformLayout();
            this.groupBox_in_1.ResumeLayout(false);
            this.groupBox_in_1.PerformLayout();
            this.groupBox_in_0.ResumeLayout(false);
            this.groupBox_in_0.PerformLayout();
            this.groupBox_in_4.ResumeLayout(false);
            this.groupBox_in_4.PerformLayout();
            this.groupBox_in_3.ResumeLayout(false);
            this.groupBox_in_3.PerformLayout();
            this.groupBox_in_9.ResumeLayout(false);
            this.groupBox_in_9.PerformLayout();
            this.groupBox_in_2.ResumeLayout(false);
            this.groupBox_in_2.PerformLayout();
            this.groupBox_in_8.ResumeLayout(false);
            this.groupBox_in_8.PerformLayout();
            this.groupBox_in_6.ResumeLayout(false);
            this.groupBox_in_6.PerformLayout();
            this.groupBox_in_12.ResumeLayout(false);
            this.groupBox_in_12.PerformLayout();
            this.groupBox_in_5.ResumeLayout(false);
            this.groupBox_in_5.PerformLayout();
            this.groupBox_in_11.ResumeLayout(false);
            this.groupBox_in_11.PerformLayout();
            this.groupBox_in_7.ResumeLayout(false);
            this.groupBox_in_7.PerformLayout();
            this.groupBox_in_10.ResumeLayout(false);
            this.groupBox_in_10.PerformLayout();
            this.groupBox_in_14.ResumeLayout(false);
            this.groupBox_in_14.PerformLayout();
            this.groupBox_in_13.ResumeLayout(false);
            this.groupBox_in_13.PerformLayout();
            this.groupBox_in_15.ResumeLayout(false);
            this.groupBox_in_15.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label_ax_1;
        private System.Windows.Forms.Label label_ax_0;
        private System.Windows.Forms.GroupBox groupBox_ax_15;
        private System.Windows.Forms.RadioButton radioButton_ax_15_0;
        private System.Windows.Forms.RadioButton radioButton_ax_15_1;
        private System.Windows.Forms.GroupBox groupBox_ax_10;
        private System.Windows.Forms.RadioButton radioButton_ax_10_0;
        private System.Windows.Forms.RadioButton radioButton_ax_10_1;
        private System.Windows.Forms.GroupBox groupBox_ax_14;
        private System.Windows.Forms.RadioButton radioButton_ax_14_0;
        private System.Windows.Forms.RadioButton radioButton_ax_14_1;
        private System.Windows.Forms.GroupBox groupBox_ax_8;
        private System.Windows.Forms.RadioButton radioButton_ax_8_0;
        private System.Windows.Forms.RadioButton radioButton_ax_8_1;
        private System.Windows.Forms.GroupBox groupBox_ax_12;
        private System.Windows.Forms.RadioButton radioButton_ax_12_0;
        private System.Windows.Forms.RadioButton radioButton_ax_12_1;
        private System.Windows.Forms.GroupBox groupBox_ax_11;
        private System.Windows.Forms.RadioButton radioButton_ax_11_0;
        private System.Windows.Forms.RadioButton radioButton_ax_11_1;
        private System.Windows.Forms.GroupBox groupBox_ax_9;
        private System.Windows.Forms.RadioButton radioButton_ax_9_0;
        private System.Windows.Forms.RadioButton radioButton_ax_9_1;
        private System.Windows.Forms.GroupBox groupBox_ax_13;
        private System.Windows.Forms.RadioButton radioButton_ax_13_0;
        private System.Windows.Forms.RadioButton radioButton_ax_13_1;
        private System.Windows.Forms.Label label_ax;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox_ax_1;
        private System.Windows.Forms.RadioButton radioButton_ax_1_0;
        private System.Windows.Forms.RadioButton radioButton_ax_1_1;
        private System.Windows.Forms.GroupBox groupBox_ax_0;
        private System.Windows.Forms.RadioButton radioButton_ax_0_0;
        private System.Windows.Forms.RadioButton radioButton_ax_0_1;
        private System.Windows.Forms.GroupBox groupBox_ax_4;
        private System.Windows.Forms.RadioButton radioButton_ax_4_0;
        private System.Windows.Forms.RadioButton radioButton_ax_4_1;
        private System.Windows.Forms.GroupBox groupBox_ax_3;
        private System.Windows.Forms.RadioButton radioButton_ax_3_0;
        private System.Windows.Forms.RadioButton radioButton_ax_3_1;
        private System.Windows.Forms.GroupBox groupBox_ax_2;
        private System.Windows.Forms.RadioButton radioButton_ax_2_0;
        private System.Windows.Forms.RadioButton radioButton_ax_2_1;
        private System.Windows.Forms.GroupBox groupBox_ax_6;
        private System.Windows.Forms.RadioButton radioButton_ax_6_0;
        private System.Windows.Forms.RadioButton radioButton_ax_6_1;
        private System.Windows.Forms.GroupBox groupBox_ax_5;
        private System.Windows.Forms.RadioButton radioButton_ax_5_0;
        private System.Windows.Forms.RadioButton radioButton_ax_5_1;
        private System.Windows.Forms.GroupBox groupBox_ax_7;
        private System.Windows.Forms.RadioButton radioButton_ax_7_0;
        private System.Windows.Forms.RadioButton radioButton_ax_7_1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button button_ax;
        private System.Windows.Forms.Label label_al_wartosc;
        private System.Windows.Forms.Label label_ah_wartosc;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label_bh_wartosc;
        private System.Windows.Forms.Label label_bl_wartosc;
        private System.Windows.Forms.Button button_bx;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.GroupBox groupBox_bx_1;
        private System.Windows.Forms.RadioButton radioButton_bx_1_0;
        private System.Windows.Forms.RadioButton radioButton_bx_1_1;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.GroupBox groupBox_bx_0;
        private System.Windows.Forms.RadioButton radioButton_bx_0_0;
        private System.Windows.Forms.RadioButton radioButton_bx_0_1;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.GroupBox groupBox_bx_4;
        private System.Windows.Forms.RadioButton radioButton_bx_4_0;
        private System.Windows.Forms.RadioButton radioButton_bx_4_1;
        private System.Windows.Forms.Label label_bx;
        private System.Windows.Forms.GroupBox groupBox_bx_3;
        private System.Windows.Forms.RadioButton radioButton_bx_3_0;
        private System.Windows.Forms.RadioButton radioButton_bx_3_1;
        private System.Windows.Forms.GroupBox groupBox_bx_9;
        private System.Windows.Forms.RadioButton radioButton_bx_9_0;
        private System.Windows.Forms.RadioButton radioButton_bx_9_1;
        private System.Windows.Forms.GroupBox groupBox_bx_2;
        private System.Windows.Forms.RadioButton radioButton_bx_2_0;
        private System.Windows.Forms.RadioButton radioButton_bx_2_1;
        private System.Windows.Forms.GroupBox groupBox_bx_8;
        private System.Windows.Forms.RadioButton radioButton_bx_8_0;
        private System.Windows.Forms.RadioButton radioButton_bx_8_1;
        private System.Windows.Forms.GroupBox groupBox_bx_6;
        private System.Windows.Forms.RadioButton radioButton_bx_6_0;
        private System.Windows.Forms.RadioButton radioButton_bx_6_1;
        private System.Windows.Forms.GroupBox groupBox_bx_12;
        private System.Windows.Forms.RadioButton radioButton_bx_12_0;
        private System.Windows.Forms.RadioButton radioButton_bx_12_1;
        private System.Windows.Forms.GroupBox groupBox_bx_5;
        private System.Windows.Forms.RadioButton radioButton_bx_5_0;
        private System.Windows.Forms.RadioButton radioButton_bx_5_1;
        private System.Windows.Forms.GroupBox groupBox_bx_11;
        private System.Windows.Forms.RadioButton radioButton_bx_11_0;
        private System.Windows.Forms.RadioButton radioButton_bx_11_1;
        private System.Windows.Forms.GroupBox groupBox_bx_7;
        private System.Windows.Forms.RadioButton radioButton_bx_7_0;
        private System.Windows.Forms.RadioButton radioButton_bx_7_1;
        private System.Windows.Forms.GroupBox groupBox_bx_10;
        private System.Windows.Forms.RadioButton radioButton_bx_10_0;
        private System.Windows.Forms.RadioButton radioButton_bx_10_1;
        private System.Windows.Forms.GroupBox groupBox_bx_14;
        private System.Windows.Forms.RadioButton radioButton_bx_14_0;
        private System.Windows.Forms.RadioButton radioButton_bx_14_1;
        private System.Windows.Forms.GroupBox groupBox_bx_13;
        private System.Windows.Forms.RadioButton radioButton_bx_13_0;
        private System.Windows.Forms.RadioButton radioButton_bx_13_1;
        private System.Windows.Forms.GroupBox groupBox_bx_15;
        private System.Windows.Forms.RadioButton radioButton_bx_15_0;
        private System.Windows.Forms.RadioButton radioButton_bx_15_1;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label_dh_wartosc;
        private System.Windows.Forms.Label label_dl_wartosc;
        private System.Windows.Forms.Button button_dx;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.GroupBox groupBox_dx_1;
        private System.Windows.Forms.RadioButton radioButton_dx_1_0;
        private System.Windows.Forms.RadioButton radioButton_dx_1_1;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.GroupBox groupBox_dx_0;
        private System.Windows.Forms.RadioButton radioButton_dx_0_0;
        private System.Windows.Forms.RadioButton radioButton_dx_0_1;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.GroupBox groupBox_dx_4;
        private System.Windows.Forms.RadioButton radioButton_dx_4_0;
        private System.Windows.Forms.RadioButton radioButton_dx_4_1;
        private System.Windows.Forms.Label label_dx;
        private System.Windows.Forms.GroupBox groupBox_dx_3;
        private System.Windows.Forms.RadioButton radioButton_dx_3_0;
        private System.Windows.Forms.RadioButton radioButton_dx_3_1;
        private System.Windows.Forms.GroupBox groupBox_dx_9;
        private System.Windows.Forms.RadioButton radioButton_dx_9_0;
        private System.Windows.Forms.RadioButton radioButton_dx_9_1;
        private System.Windows.Forms.GroupBox groupBox_dx_2;
        private System.Windows.Forms.RadioButton radioButton_dx_2_0;
        private System.Windows.Forms.RadioButton radioButton_dx_2_1;
        private System.Windows.Forms.GroupBox groupBox_dx_8;
        private System.Windows.Forms.RadioButton radioButton_dx_8_0;
        private System.Windows.Forms.RadioButton radioButton_dx_8_1;
        private System.Windows.Forms.GroupBox groupBox_dx_6;
        private System.Windows.Forms.RadioButton radioButton_dx_6_0;
        private System.Windows.Forms.RadioButton radioButton_dx_6_1;
        private System.Windows.Forms.GroupBox groupBox_dx_12;
        private System.Windows.Forms.RadioButton radioButton_dx_12_0;
        private System.Windows.Forms.RadioButton radioButton_dx_12_1;
        private System.Windows.Forms.GroupBox groupBox_dx_5;
        private System.Windows.Forms.RadioButton radioButton_dx_5_0;
        private System.Windows.Forms.RadioButton radioButton_dx_5_1;
        private System.Windows.Forms.GroupBox groupBox_dx_11;
        private System.Windows.Forms.RadioButton radioButton_dx_11_0;
        private System.Windows.Forms.RadioButton radioButton_dx_11_1;
        private System.Windows.Forms.GroupBox groupBox_dx_7;
        private System.Windows.Forms.RadioButton radioButton_dx_7_0;
        private System.Windows.Forms.RadioButton radioButton_dx_7_1;
        private System.Windows.Forms.GroupBox groupBox_dx_10;
        private System.Windows.Forms.RadioButton radioButton_dx_10_0;
        private System.Windows.Forms.RadioButton radioButton_dx_10_1;
        private System.Windows.Forms.GroupBox groupBox_dx_14;
        private System.Windows.Forms.RadioButton radioButton_dx_14_0;
        private System.Windows.Forms.RadioButton radioButton_dx_14_1;
        private System.Windows.Forms.GroupBox groupBox_dx_13;
        private System.Windows.Forms.RadioButton radioButton_dx_13_0;
        private System.Windows.Forms.RadioButton radioButton_dx_13_1;
        private System.Windows.Forms.GroupBox groupBox_dx_15;
        private System.Windows.Forms.RadioButton radioButton_dx_15_0;
        private System.Windows.Forms.RadioButton radioButton_dx_15_1;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label_ch_wartosc;
        private System.Windows.Forms.Label label_cl_wartosc;
        private System.Windows.Forms.Button button_cx;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.GroupBox groupBox_cx_1;
        private System.Windows.Forms.RadioButton radioButton_cx_1_0;
        private System.Windows.Forms.RadioButton radioButton_cx_1_1;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.GroupBox groupBox_cx_0;
        private System.Windows.Forms.RadioButton radioButton_cx_0_0;
        private System.Windows.Forms.RadioButton radioButton_cx_0_1;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.GroupBox groupBox_cx_4;
        private System.Windows.Forms.RadioButton radioButton_cx_4_0;
        private System.Windows.Forms.RadioButton radioButton_cx_4_1;
        private System.Windows.Forms.Label label_cx;
        private System.Windows.Forms.GroupBox groupBox_cx_3;
        private System.Windows.Forms.RadioButton radioButton_cx_3_0;
        private System.Windows.Forms.RadioButton radioButton_cx_3_1;
        private System.Windows.Forms.GroupBox groupBox_cx_9;
        private System.Windows.Forms.RadioButton radioButton_cx_9_0;
        private System.Windows.Forms.RadioButton radioButton_cx_9_1;
        private System.Windows.Forms.GroupBox groupBox_cx_2;
        private System.Windows.Forms.RadioButton radioButton_cx_2_0;
        private System.Windows.Forms.RadioButton radioButton_cx_2_1;
        private System.Windows.Forms.GroupBox groupBox_cx_8;
        private System.Windows.Forms.RadioButton radioButton_cx_8_0;
        private System.Windows.Forms.RadioButton radioButton_cx_8_1;
        private System.Windows.Forms.GroupBox groupBox_cx_6;
        private System.Windows.Forms.RadioButton radioButton_cx_6_0;
        private System.Windows.Forms.RadioButton radioButton_cx_6_1;
        private System.Windows.Forms.GroupBox groupBox_cx_12;
        private System.Windows.Forms.RadioButton radioButton_cx_12_0;
        private System.Windows.Forms.RadioButton radioButton_cx_12_1;
        private System.Windows.Forms.GroupBox groupBox_cx_5;
        private System.Windows.Forms.RadioButton radioButton_cx_5_0;
        private System.Windows.Forms.RadioButton radioButton_cx_5_1;
        private System.Windows.Forms.GroupBox groupBox_cx_11;
        private System.Windows.Forms.RadioButton radioButton_cx_11_0;
        private System.Windows.Forms.RadioButton radioButton_cx_11_1;
        private System.Windows.Forms.GroupBox groupBox_cx_7;
        private System.Windows.Forms.RadioButton radioButton_cx_7_0;
        private System.Windows.Forms.RadioButton radioButton_cx_7_1;
        private System.Windows.Forms.GroupBox groupBox_cx_10;
        private System.Windows.Forms.RadioButton radioButton_cx_10_0;
        private System.Windows.Forms.RadioButton radioButton_cx_10_1;
        private System.Windows.Forms.GroupBox groupBox_cx_14;
        private System.Windows.Forms.RadioButton radioButton_cx_14_0;
        private System.Windows.Forms.RadioButton radioButton_cx_14_1;
        private System.Windows.Forms.GroupBox groupBox_cx_13;
        private System.Windows.Forms.RadioButton radioButton_cx_13_0;
        private System.Windows.Forms.RadioButton radioButton_cx_13_1;
        private System.Windows.Forms.GroupBox groupBox_cx_15;
        private System.Windows.Forms.RadioButton radioButton_cx_15_0;
        private System.Windows.Forms.RadioButton radioButton_cx_15_1;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label_inh_wartosc;
        private System.Windows.Forms.Label label_inl_wartosc;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.GroupBox groupBox_in_1;
        private System.Windows.Forms.RadioButton radioButton_in_1_0;
        private System.Windows.Forms.RadioButton radioButton_in_1_1;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.GroupBox groupBox_in_0;
        private System.Windows.Forms.RadioButton radioButton_in_0_0;
        private System.Windows.Forms.RadioButton radioButton_in_0_1;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.GroupBox groupBox_in_4;
        private System.Windows.Forms.RadioButton radioButton_in_4_0;
        private System.Windows.Forms.RadioButton radioButton_in_4_1;
        private System.Windows.Forms.GroupBox groupBox_in_3;
        private System.Windows.Forms.RadioButton radioButton_in_3_0;
        private System.Windows.Forms.RadioButton radioButton_in_3_1;
        private System.Windows.Forms.GroupBox groupBox_in_9;
        private System.Windows.Forms.RadioButton radioButton_in_9_0;
        private System.Windows.Forms.RadioButton radioButton_in_9_1;
        private System.Windows.Forms.GroupBox groupBox_in_2;
        private System.Windows.Forms.RadioButton radioButton_in_2_0;
        private System.Windows.Forms.RadioButton radioButton_in_2_1;
        private System.Windows.Forms.GroupBox groupBox_in_8;
        private System.Windows.Forms.RadioButton radioButton_in_8_0;
        private System.Windows.Forms.RadioButton radioButton_in_8_1;
        private System.Windows.Forms.GroupBox groupBox_in_6;
        private System.Windows.Forms.RadioButton radioButton_in_6_0;
        private System.Windows.Forms.RadioButton radioButton_in_6_1;
        private System.Windows.Forms.GroupBox groupBox_in_12;
        private System.Windows.Forms.RadioButton radioButton_in_12_0;
        private System.Windows.Forms.RadioButton radioButton_in_12_1;
        private System.Windows.Forms.GroupBox groupBox_in_5;
        private System.Windows.Forms.RadioButton radioButton_in_5_0;
        private System.Windows.Forms.RadioButton radioButton_in_5_1;
        private System.Windows.Forms.GroupBox groupBox_in_11;
        private System.Windows.Forms.RadioButton radioButton_in_11_0;
        private System.Windows.Forms.RadioButton radioButton_in_11_1;
        private System.Windows.Forms.GroupBox groupBox_in_7;
        private System.Windows.Forms.RadioButton radioButton_in_7_0;
        private System.Windows.Forms.RadioButton radioButton_in_7_1;
        private System.Windows.Forms.GroupBox groupBox_in_10;
        private System.Windows.Forms.RadioButton radioButton_in_10_0;
        private System.Windows.Forms.RadioButton radioButton_in_10_1;
        private System.Windows.Forms.GroupBox groupBox_in_14;
        private System.Windows.Forms.RadioButton radioButton_in_14_0;
        private System.Windows.Forms.RadioButton radioButton_in_14_1;
        private System.Windows.Forms.GroupBox groupBox_in_13;
        private System.Windows.Forms.RadioButton radioButton_in_13_0;
        private System.Windows.Forms.RadioButton radioButton_in_13_1;
        private System.Windows.Forms.GroupBox groupBox_in_15;
        private System.Windows.Forms.RadioButton radioButton_in_15_0;
        private System.Windows.Forms.RadioButton radioButton_in_15_1;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.ComboBox comboBox_instrukcja;
        private System.Windows.Forms.ComboBox comboBox_arg1;
        private System.Windows.Forms.ComboBox comboBox_arg2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
    }
}

