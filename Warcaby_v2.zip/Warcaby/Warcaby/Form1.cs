﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Warcaby
{
    public partial class Start : Form
    {
        public Start()
        {
            InitializeComponent();
        }

        private void Start_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(this.comboBoxgracza1.Text != this.comboBoxgracza2.Text)
            {
                if (this.comboBoxgracza1.Text != "Kolor gracza 1" && this.comboBoxgracza2.Text != "Kolor gracza 2" && this.comboBoxczas.Text != "Czas")
                {
                    czas_rozgrywki = this.comboBoxczas.Text;
                    kolor_gracza1 = this.comboBoxgracza1.Text;
                    kolor_gracza2 = this.comboBoxgracza2.Text;
                    switch (this.comboBoxczas.Text)
                    {
                        case "3 minuty":
                            czas_gracza1_minuty = 3;
                            czas_gracza2_minuty = 3;
                            dodanie_sekund = 0;
                            break;
                        case "3 | 2":
                            czas_gracza1_minuty = 3;
                            czas_gracza2_minuty = 3;
                            dodanie_sekund = 2;
                            break;
                        case "5 | 5":
                            czas_gracza1_minuty = 5;
                            czas_gracza2_minuty = 5;
                            dodanie_sekund = 5;
                            break;
                        case "5 minut":
                            czas_gracza1_minuty = 5;
                            czas_gracza2_minuty = 5;
                            dodanie_sekund = 0;
                            break;
                        case "5 | 2":
                            czas_gracza1_minuty = 5;
                            czas_gracza2_minuty = 5;
                            dodanie_sekund = 2;
                            break;
                        case "10 minut":
                            czas_gracza1_minuty = 10;
                            czas_gracza2_minuty = 10;
                            dodanie_sekund = 0;
                            break;
                        case "15 | 10":
                            czas_gracza1_minuty = 15;
                            czas_gracza2_minuty = 15;
                            dodanie_sekund = 10;
                            break;
                        default:
                            break;
                    }
                    czas_gracza1_sekundy = 0;
                    czas_gracza2_sekundy = 0;
                    this.gra = new Form2();
                    this.gra.Show();
                }
                else
                {
                    MessageBox.Show("Nie wszystkie ustawienia zostały wybrane. Wybierz ustawienia gry i spróbuj ponownie");
                }
            }
            else
            {
                MessageBox.Show("Wybrano te same kolory żetonów obu graczy. Wybierz inne kolory i spróbuj ponownie"); ;
            }
            //this.gra = new Form2();
            //this.gra.Show();
        }
    }

    
}
