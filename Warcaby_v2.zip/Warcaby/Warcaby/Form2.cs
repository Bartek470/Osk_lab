﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Warcaby
{
    public partial class Form2 : Form
    {
        
        public Form2()
        {
            InitializeComponent();

            List<PictureBox> pictureBoxes = new List<PictureBox>(){ this.pictureBox1, this.pictureBox2, this.pictureBox3, this.pictureBox4, this.pictureBox5, this.pictureBox6, this.pictureBox7, this.pictureBox8, this.pictureBox9, this.pictureBox10, this.pictureBox11, this.pictureBox12,
                pictureBox13, this.pictureBox14, this.pictureBox15, this.pictureBox16, this.pictureBox17, this.pictureBox18, this.pictureBox19, this.pictureBox20, this.pictureBox21, this.pictureBox22, this.pictureBox23, this.pictureBox24,
                pictureBox25, this.pictureBox26, this.pictureBox27, this.pictureBox28, this.pictureBox29, this.pictureBox30, this.pictureBox31, this.pictureBox32, this.pictureBox33, this.pictureBox34, this.pictureBox35, this.pictureBox36,
                pictureBox37, this.pictureBox38, this.pictureBox39, this.pictureBox40, this.pictureBox41, this.pictureBox42, this.pictureBox43, this.pictureBox44, this.pictureBox45, this.pictureBox46, this.pictureBox47, this.pictureBox48,
                pictureBox49, this.pictureBox50, this.pictureBox51, this.pictureBox52, this.pictureBox53, this.pictureBox54, this.pictureBox55, this.pictureBox56, this.pictureBox57, this.pictureBox58, this.pictureBox59, this.pictureBox60,
                pictureBox61, this.pictureBox62, this.pictureBox63, this.pictureBox64};
            //PictureBox[] pictureBoxes = new PictureBox[64];
            int[,] board;
            const int BoardSize = 8;
            int wybrany_wiersz = -1;
            int wybrana_kolumna = -1;
            bool czyja_kolej = true;
            this.label_wybrany_czas.Text += Start.czas_rozgrywki;
            this.label_kolor_gracza1.Text += Start.kolor_gracza1;
            this.label_kolor_grazca2.Text += Start.kolor_gracza2;
            

            if (Start.czas_gracza1_minuty < 10)
            {
                if (Start.czas_gracza1_sekundy >= 10)
                {
                    this.label_czas_gracza1.Text += "0" + Start.czas_gracza1_minuty.ToString() + ":" + Start.czas_gracza1_sekundy.ToString();
                }
                else
                {
                    this.label_czas_gracza1.Text += "0" + Start.czas_gracza1_minuty.ToString() + ":0" + Start.czas_gracza1_sekundy.ToString();
                }
            }
            else
            {
                if (Start.czas_gracza1_sekundy >= 10)
                {
                    this.label_czas_gracza1.Text += Start.czas_gracza1_minuty.ToString() + ":" + Start.czas_gracza1_sekundy.ToString();
                }
                else
                {
                    this.label_czas_gracza1.Text += Start.czas_gracza1_minuty.ToString() + ":0" + Start.czas_gracza1_sekundy.ToString();
                }
            }
            if (Start.czas_gracza2_minuty < 10)
            {
                if (Start.czas_gracza2_sekundy >= 10)
                {
                    this.label_czas_gracza2.Text += "0" + Start.czas_gracza2_minuty.ToString() + ":" + Start.czas_gracza2_sekundy.ToString();
                }
                else
                {
                    this.label_czas_gracza2.Text += "0" + Start.czas_gracza2_minuty.ToString() + ":0" + Start.czas_gracza2_sekundy.ToString();
                }
            }
            else
            {
                if (Start.czas_gracza2_sekundy >= 10)
                {
                    this.label_czas_gracza2.Text += Start.czas_gracza2_minuty.ToString() + ":" + Start.czas_gracza2_sekundy.ToString();
                }
                else
                {
                    this.label_czas_gracza2.Text += Start.czas_gracza2_minuty.ToString() + ":0" + Start.czas_gracza2_sekundy.ToString();
                }
            }
            RozstawZetony(Start.kolor_gracza1, Start.kolor_gracza2, pictureBoxes);
            foreach (PictureBox pictureBox in pictureBoxes)
            {
                pictureBox.MouseClick += (sender, e) => przycisk_MouseClick(sender, e, pictureBoxes);
            }
            board = new int[BoardSize, BoardSize];
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            
        }

        private void pictureBox40_Click(object sender, EventArgs e)
        {

        }

        private void RozstawZetony(String kolor_gracza1, String kolor_gracza2, List<PictureBox> pictureBoxes)
        {
            int indeks_x = 0;
            int indeks_y = 0;
            switch (kolor_gracza1)
            {
                case "Czarny":
                    for (int i = 0; i < pictureBoxes.Count; i++)
                    {
                        indeks_x = i % 8;
                        indeks_y = i / 8;
                        if ((indeks_x + indeks_y) % 2 == 1 && indeks_y <= 2)
                        {
                            pictureBoxes[i].Image = Properties.Resources.czarny_zeton;
                        }
                    }
                    break;
                case "Różowy":
                    for (int i = 0; i < pictureBoxes.Count; i++)
                    {
                        indeks_x = i % 8;
                        indeks_y = i / 8;
                        if ((indeks_x + indeks_y) % 2 == 1 && indeks_y <= 2)
                        {
                            pictureBoxes[i].Image = Properties.Resources.rozowy_zeton;
                        }
                    }
                    break;
                case "Zielony":
                    for (int i = 0; i < pictureBoxes.Count; i++)
                    {
                        indeks_x = i % 8;
                        indeks_y = i / 8;
                        if ((indeks_x + indeks_y) % 2 == 1 && indeks_y <= 2)
                        {
                            pictureBoxes[i].Image = Properties.Resources.zielony_zeton;
                        }
                    }
                    break;
                case "Biały":
                    for (int i = 0; i < pictureBoxes.Count; i++)
                    {
                        indeks_x = i % 8;
                        indeks_y = i / 8;
                        if ((indeks_x + indeks_y) % 2 == 1 && indeks_y <= 2)
                        {
                            pictureBoxes[i].Image = Properties.Resources.bialy_zeton;
                        }
                    }
                    break;
                case "Niebieski":
                    for (int i = 0; i < pictureBoxes.Count; i++)
                    {
                        indeks_x = i % 8;
                        indeks_y = i / 8;
                        if ((indeks_x + indeks_y) % 2 == 1 && indeks_y <= 2)
                        {
                            pictureBoxes[i].Image = Properties.Resources.niebieski_zeton;
                        }
                    }
                    break;
            }
            switch (kolor_gracza2)
            {
                case "Czarny":
                    for (int i = 0; i < pictureBoxes.Count; i++)
                    {
                        indeks_x = i % 8;
                        indeks_y = i / 8;
                        if ((indeks_x + indeks_y) % 2 == 1 && indeks_y >= 5)
                        {
                            pictureBoxes[i].Image = Properties.Resources.czarny_zeton;
                        }
                    }
                    break;
                case "Różowy":
                    for (int i = 0; i < pictureBoxes.Count; i++)
                    {
                        indeks_x = i % 8;
                        indeks_y = i / 8;
                        if ((indeks_x + indeks_y) % 2 == 1 && indeks_y >= 5)
                        {
                            pictureBoxes[i].Image = Properties.Resources.rozowy_zeton;
                        }
                    }
                    break;
                case "Zielony":
                    for (int i = 0; i < pictureBoxes.Count; i++)
                    {
                        indeks_x = i % 8;
                        indeks_y = i / 8;
                        if ((indeks_x + indeks_y) % 2 == 1 && indeks_y >= 5)
                        {
                            pictureBoxes[i].Image = Properties.Resources.zielony_zeton;
                        }
                    }
                    break;
                case "Biały":
                    for (int i = 0; i < pictureBoxes.Count; i++)
                    {
                        indeks_x = i % 8;
                        indeks_y = i / 8;
                        if ((indeks_x + indeks_y) % 2 == 1 && indeks_y >= 5)
                        {
                            pictureBoxes[i].Image = Properties.Resources.bialy_zeton;
                        }
                    }
                    break;
                case "Niebieski":
                    for (int i = 0; i < pictureBoxes.Count; i++)
                    {
                        indeks_x = i % 8;
                        indeks_y = i / 8;
                        if ((indeks_x + indeks_y) % 2 == 1 && indeks_y >= 5)
                        {
                            pictureBoxes[i].Image = Properties.Resources.niebieski_zeton;
                        }
                    }
                    break;
            }
        }
        private void przycisk_MouseClick(object sender, EventArgs e, List<PictureBox> pictureBoxes)
        {
            PictureBox clickedSquare = sender as PictureBox;
            int indeks = pictureBoxes.IndexOf(clickedSquare);
            int indeks_x = indeks % 8; //poziomo, col
            int indeks_y = indeks / 8; //pionowo, row
            
            if (wybrany_wiersz==-1 && wybrana_kolumna == -1)
            {
                if((czyja_kolej && board[indeks_y,indeks_x]==1) ||(!czyja_kolej && board[indeks_y, indeks_x] == 2)){
                    wybrany_wiersz = indeks_y;
                    wybrana_kolumna = indeks_x;
                    clickedSquare.BackColor = Color.Yellow;
                }
            }
            else
            {
                if (IsValidMove(wybrany_wiersz, wybrana_kolumna, indeks_y, indeks_x))
                {
                    MovePice(wybrany_wiersz, wybrana_kolumna, indeks_y, indeks_x, pictureBoxes);
                    wybrany_wiersz = -1;
                    wybrana_kolumna = -1;
                    czyja_kolej = !czyja_kolej;
                }
                else
                {
                    MessageBox.Show("niepoprwany ruch");
                }
            }
        }
        private bool IsValidMove(int fromY,int fromX,int toY,int toX)
        {
            if (board[toY, toX] != 0)
                return false;
            if (Math.Abs(toY - fromY) != Math.Abs(toX - fromX))
                return false;
            if (Math.Abs(toY - fromY) != 1)
                return false;
            if ((czyja_kolej && toY <= fromY) || (!czyja_kolej && toY >= fromY))
                return false;
            if (Math.Abs(toY - fromY) == 2)
            {
                int enemyY = (fromY + toY) / 2;
                int enemyX = (fromX + toX) / 2;
                if (board[enemyY, enemyX] == 0 || (czyja_kolej && board[enemyY, enemyX] == 1) || (!czyja_kolej && board[enemyY, enemyX] == 2))
                    return false;
            }
            return true;
        }
        private void MovePice(int fromY, int fromX, int toY, int toX,List<PictureBox> pictureBoxes)
        {
            board[toY, toX] = board[fromY, fromX];
            board[fromY, fromX] = 0;
            pictureBoxes[toY * 8 + toX].Image = pictureBoxes[fromY * 8 + fromX].Image;
            pictureBoxes[fromY * 8 + fromX].Image = null;
            if (Math.Abs(toY - fromY) == 2)
            {
                int enemyY = (fromY + toY) / 2;
                int enemyX = (fromX + toX) / 2;
                board[enemyY, enemyX] = 0;
                pictureBoxes[enemyY * 8 + enemyX].Image = null;
            }
        }
    }
}
